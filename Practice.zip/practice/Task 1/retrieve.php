<?php $con=mysqli_connect("localhost","root","","its_mine");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <form>
    <table border="1" align="center"  >
		<tr>
			<td><strong>Id</strong></td>   
			<td><strong>Name</strong></td>  
			<td><strong>Class</strong></td>   
			<td><strong>Phone Number</strong></td>   
		</tr>
        <?php
  		$sql_qry = "SELECT * FROM `demo` ORDER BY `demo`.`ID` ASC ";
		$res=mysqli_query($con, $sql_qry);  
  		while($row=mysqli_fetch_array($res))
  		{ ?>
 		<tr>
			<td><?php echo $row['ID'];  ?></td>   
			<td><?php echo $row['Name'];  ?></td>     
			<td><?php echo $row['Class'];  ?></td>  
			<td><?php echo $row['Phone_No.'];  ?></td> 
		</tr>
		<?php
			}
		?>
		<input type="submit" value="Retrieve" onclick="retrieve()" style="margin-left: 40%;">
</table>
	</form>        
    
</head>
<body>
    
    
</body>
</html>