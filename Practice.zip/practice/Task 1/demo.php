<?php $con=mysqli_connect("localhost","root","","its_mine");                               
if(!empty($_REQUEST['mode']))
{  
	$rec_name = $_REQUEST['username'];
	$rec_class = $_REQUEST['class'];
	$rec_phno = $_REQUEST['ph_no']; 	
	$sql_con="INSERT INTO `demo` SET 
					`Name`= '$rec_name', 
					`Class`= '$rec_class', 
					`Phone_No.`= '$rec_phno'";  
	$res=mysqli_query($con, $sql_con);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form name="sampleform" id="sampleform" method="POST" action="" onSubmit="return checking();">	
<input type="hidden" name="mode" value="1" />
<table align="center">					
					<tr>
						<td>Name</td>
						<td><input type="text" name="username" id="name" value=""  /></td>
					</tr>															
					<tr>
						<td>Class</td>
						<td>
								<select name="class" id="class" >
									<option value="">-- Select --</option>
									<option value="one">Class 1</option>
									<option value="two">Class 2</option>
									<option value="three">Class 3</option>
                                    <option value="four">Class 4</option>
                                    <option value="five">Class 5</option>
								</select>
						</td>
					</tr>
                    <tr>
						<td>Phone Number</td>
						<td><input type="number" name="ph_no" id="ph_no" value=""  /></td>
					</tr>																															
					<tr>
						<td>&nbsp;</td>
						<td>
							<input type="submit" name="" value="SAVE" />
					    </td>
					</tr>
</table>
</form>						
</body>
</html>