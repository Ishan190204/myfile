<?php $con=mysqli_connect("localhost","root","","task_5");
if(!empty($_REQUEST['mode']))
{  
	$rec_fname = $_REQUEST['fname']; 	
    $rec_lname = $_REQUEST['lname'];        
    $rec_skills =$_REQUEST['skills']; 
    $rec_github=$_REQUEST['github'];  
    $uploadlocation="uploaded/";  
	$fetchFileName = $_FILES['image']['name'];
	$rand_variable = rand(11111, 99999);  
	$new_file=$rand_variable."_".$fetchFileName; 
    if(is_uploaded_file($_FILES['image']['tmp_name']))
	{
			@move_uploaded_file($_FILES['image']['tmp_name'],$uploadlocation.$new_file);
	}
    $uploadpdf="pdf_file/";
    if (isset($_FILES['pdf']['name']))
        {
          $file_name = $_FILES['pdf']['name'];
          $file_tmp = $_FILES['pdf']['tmp_name'];
         @move_uploaded_file($file_tmp,$uploadpdf.$file_name);
        }
 
    $sql_con="INSERT INTO `cv` SET 
                    `fname`= '$rec_fname', 
                    `lname`= '$rec_lname', 
                    `skills`= '$rec_skills', 
                    `github`= '$rec_github',
                    `image`= '$new_file',
                    `pdf`= '$file_name'";  
    $res=mysqli_query($con, $sql_con);
    if($res)	
	{
		@header("Location: b.php?");
		exit();
	}	

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <form align="center" name="sampleform" id="sampleform" method="POST" action="" enctype="multipart/form-data" >
    <input type="hidden" name="mode" value="1" />
        <h4>PROFILE</h4>
         <label>First name</label>
         <input type="text" id="fname" name="fname"><div>&nbsp;</div>
         <label>Last name</label>
         <input type="text" id="lname" name="lname"><div>&nbsp;</div>
         <label>Skills</label>
         <select name="skills" id="skills" class="selectpicker">
            <option value="">Select your skils</option>
            <option value="css">css</option>
            <option value="js">Java script</option>
            <option value="php">Php</option>
         </select><div>&nbsp;</div>  
         <label>Github</label> 
         <input type="text" id="github" name="github"><div>&nbsp;</div>
         <label>Image</label>
         <input type="file" accept="image/*" onchange="previewImage(event)" id="image" name="image"><br>
         <img id="preview" alt="Preview Image"><br><div>&nbsp;</div>
         <label>Upload pdf</label>
         <input type="file" id="pdf" name="pdf" onchange="file(event)"><div>&nbsp;</div>       
                <embed  id="file"
                       src=""
                       width="250"
                       height="200"><br><div>&nbsp;</div> 
         <button onclick="submit()" class="button">Submit</button>
    </form>
    <script src="script.js"></script>
</body>
</html>