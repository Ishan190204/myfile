<?php $con=mysqli_connect("localhost","root","","task_5");
$sql_qry = "SELECT * FROM `cv` WHERE id=(SELECT max(id) FROM `cv`)";
$res=mysqli_query($con, $sql_qry); 
$row=mysqli_fetch_array($res) ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Document</title>
</head>
<body>
    <div align="center">
        <img src="uploaded/<?php echo $row['image']; ?>" class="circular"><br><div>&nbsp;</div>
        <span>Name=<?php echo $row['fname']?></span>
        <span><?php echo $row['lname']?></span><br><div>&nbsp;</div>
        <span>Skill=<?php echo $row['skills']?></span><br><div>&nbsp;</div>
        <a href="pdf_file/<?php echo $row['pdf']?>" id="link">Download CV</a><div>&nbsp;</div>
        <a href="<?php echo $row['github']?>" id="link"><i class="fa-brands fa-github fa-2x"></i></a>
        
    </div>
</body>
</html>