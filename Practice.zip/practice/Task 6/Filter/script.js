
let boxes=document.getElementsByClassName('box');
function all_show(){
    let btns=document.getElementsByTagName('button');
    for(let i in btns){
        if(btns[i].classList)
        btns[i].classList.remove('active');
    }
    document.getElementsByClassName('all_btn')[0].classList.add('active');
    
    //alert("work");
   // console.log(boxes);
for(let i in boxes){
    //console.log(boxes[i]);
   if(boxes[i].classList)

    boxes[i].classList.add('view');
}
}
all_show() 
function filtered(value)
{
    let val=document.getElementsByClassName(value);
    let btns=document.getElementsByTagName('button');
    for(let i in btns){
        if(btns[i].classList)
        btns[i].classList.remove('active');
    }
    document.getElementsByClassName(value+'_btn')[0].classList.add('active');
    for(let i in boxes){
        if(boxes[i].classList)

        boxes[i].classList.remove('view');
    }
    for(let i in val){
        if(val[i].classList)

        val[i].classList.add('view');
    }
}
function search(value)
{
    
    for(let i in boxes){
        if(boxes[i].classList)
        {
        if(boxes[i].innerHTML.indexOf(value)!=-1)
        boxes[i].classList.add('view');
        else
        boxes[i].classList.remove('view');
        }
   
    }
}