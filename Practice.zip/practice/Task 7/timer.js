var num=document.getElementById("num");
var a;
const timer = ()=>{    
    
     let interval=setInterval(()=>{
        a--;
        document.getElementById('count').innerHTML=a;
        if(a <= 5)
        document.getElementById('count').style.color="red";
        if(a === 0){
            document.getElementById('count').style.color="blue";
            document.getElementById('count').innerHTML="Time's UP";
            clearInterval(interval)
    }
    },1000) 
    document.getElementById('count').innerHTML=num.value;
    a=num.value;
}

function next(){
    window.location.href="st.html";
}