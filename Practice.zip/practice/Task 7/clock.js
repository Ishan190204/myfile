
setInterval(()=>{
    document.getElementById('time').innerHTML=new Date().toLocaleTimeString();
       
},1000)
document.getElementById('day').innerHTML=new Date().toDateString();
function next(){
    window.location.href="timer.html";
}

