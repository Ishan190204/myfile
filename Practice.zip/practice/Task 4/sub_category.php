<?php $con=mysqli_connect("localhost","root","","Project");
if(!empty($_REQUEST['mode']))
{  
	$rec_category = $_REQUEST['category'];
	$rec_sub = $_REQUEST['sub']; 	
	$sql_con="INSERT INTO `sub_category` SET 
					`m_id`= '$rec_category',  
					`sub_name`= '$rec_sub'";  
	$res=mysqli_query($con, $sql_con);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="s.css">
    <title>Document</title>
</head>
<body>
<form name="sampleform" id="sampleform" method="POST" action="" >
    <input type="hidden" name="mode" value="1" />
        <h3> Sub Category Input Form</h3>
        <label>Main Category</label>
        <?php
  		$sql_qry = "SELECT * FROM `main_category`";
		$res=mysqli_query($con, $sql_qry);  
        ?>		
        <select name="category" id="category">
        <option value="">Select Any One</option>
        <?php 
        while($row=mysqli_fetch_array($res))
        { ?>              
               <option value="<?php echo $row['main_id'];  ?>"> <?php echo $row['main_name'];  ?></option>
               <?php
			}
		?>          
        </select>
              
        <label>Sub Category</label>
        <input type="text" name="sub" id="sub" class="sub">
        <button>Submit</button>
        
    </form>
</body>
</html>