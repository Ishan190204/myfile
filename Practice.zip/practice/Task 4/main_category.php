<?php $con=mysqli_connect("localhost","root","","Project");                               
if(!empty($_REQUEST['mode']))
{  
	$rec_name = $_REQUEST['main']; 	
	$sql_con="INSERT INTO `main_category` SET 
					`main_name`= '$rec_name'";  
	$res=mysqli_query($con, $sql_con);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="s.css">
    <title>Document</title>
</head>
<body>

    <form name="sampleform" id="sampleform" method="POST" action="" >
    <input type="hidden" name="mode" value="1" />
        <h3>Category Input Form</h3>
        <label>Main Category</label>
        <input type="text" name="main" id="main" class="main">
        <button onclick="category()">Submit</button>
        
    </form>
    <button onclick="next()">Next</button>
    <script>
        function next(){
            window.location.href="sub_category.php";
        }
    </script>

</body>
</html>