<?php $con=mysqli_connect("localhost","root","","its_mine");   
session_start();                            
if(!empty($_REQUEST['mode']))
{  
	$rec_username = $_REQUEST['username'];
	$rec_password = md5($_REQUEST['password']); 	
	$sql_con="INSERT INTO `demo2` SET 
					`username`= '$rec_username',  
					`password`= '$rec_password'";  
	$res=mysqli_query($con, $sql_con);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form>
<div align="center">
<input type="hidden" name="mode" value="1" >
        <h2>Register Form</h2>
        <label>Username</label>
        <input type="text" id="name" name="username" class="name"><br>
        <label>Password</label>
        <input type="password" id="pass" name="password" class="pass"><br>
        <input type="submit" value="Submit" name="">
    </div>
</form>
</body>
</html>