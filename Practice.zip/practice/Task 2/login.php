<?php 
$con=mysqli_connect("localhost","root","","its_mine");
    if(!empty($_REQUEST['mode']))
    {        
        session_start();
        $rec_name = $_REQUEST['name'];
	    $rec_pass = md5($_REQUEST['pass']);
        $sql_con="Select `username` from `demo2`";
        $sql_con1="Select `password` from `demo2`";
        $res=mysqli_query($con, $sql_con);
        $res1=mysqli_query($con, $sql_con1);
        if($res==$rec_name && $res1==$rec_pass)
        {
            @header("Location: done.php");
        }
        else
        {
            @header("Location: register.php");
        }
        //$_SESSION['username']=$_REQUEST['name'];
        //$_SESSION['password']=md5($_REQUEST['pass']);
        
    }
   // else
   // {
   //     @header("Location: register.php");
    //}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form>
    <div align="center">
        <h2>Login Form</h2>
        <label>Username</label>
        <input type="text" id="name" name="name" class="name"><br>
        <label>Password</label>
        <input type="password" id="pass" name="pass" class="pass"><br>
        <input type="submit" value="Submit" name="">
    </div>
</form>
</body>
</html>