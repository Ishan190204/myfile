<?php
$con=mysqli_connect("localhost","root","","cv");                               
if(!empty($_REQUEST['mode']))
{  
	$rec_fname = $_REQUEST['fname'];
    $rec_lname = $_REQUEST['lname'];
	$rec_email = $_REQUEST['email'];
	$rec_phone = $_REQUEST['phone']; 	
    $rec_date = $_REQUEST['date'];
    $rec_gender = $_REQUEST['gender'];
    $rec_exp = $_REQUEST['experience'];
    $rec_skill = $_REQUEST['skill'];
    $rec_job = $_REQUEST['job'];
	$sql_con="INSERT INTO `cv_details` SET 
					`applicant_name`= '$rec_fame', 
					`email_id`= '$rec_email',
                    `phone_no`= '$rec_phone',
                    `dob`= '$rec_date',
                    `gender`= '$rec_gender',
                    `experience`= '$rec_exp',
                    `skill_set`= '$rec_skill', 
					`applied_job_domain`= '$rec_job'";  
	$res=mysqli_query($con, $sql_con);
}
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.css">
        <link rel="stylesheet" href="register.css">
    </head>
    <body>
        <div class="nav">
            <div><img src="file .png" class="logo"></div>
            <div class="login">
                <a href="#">Already Registered? <span class="log">Login Here</span></a>
            </div>
        </div><div class="gap"></div><br>
        <div class="main">
            <div class="reg">
                <div class="text">
                    <p class="p1">Choose A Job You Love</p>
                    <p class="p2">Find Your Perfect Path</p>
                </div><div class="gap"></div>
                <div class="reg_form">
                    <form name="sampleform" id="sampleform" method="POST" action="">
                        <input type="hidden" name="mode" value="1" />
                        <label>Username</label><br>
                        <input type="text" class="box" id="first" name="fname">
                        <input type="text" class="box" id="last" name="lname"><div class="gap"></div>
                        <label>Email id</label><br>
                        <input type="email" class="box" id="mail" name="email"><div class="gap"></div>
                        <label>Phone</label><br>
                        <input type="number" class="box" id="phone" name="phone"><div class="gap"></div>
                        <label>Date Of Birth</label><br>
                        <input type="date" class="selec" name="date"><div class="gap"></div>
                        <select class="selec" name="gender">
                            <option class="selec">Gender</option>
                            <option class="selec">Male</option>
                            <option class="selec">Female</option>
                        </select>
                        <!--<button  class="dropbtn" onclick="drop()">Gender <i class="fa-solid fa-plus fa-sm"></i></button>
                        <div class="drop-content" id="Dropdown">
                            <p>Male</p>
                            <p>Female</p>
                        </div>-->
                        <div class="gap"></div>
                        <label>Work Status</label><br>
                        <input type="radio" id="f" name="experience" onclick="hide_exp()">Freshers
                        <input type="radio" id="e"  name="experience" onclick="show_exp()">Experienced<div class="gap"></div>
                        <div id="level">
                        <label>Level Of Experience</label>
                        <select class="selec">
                            <option class="selec">LEVEL</option>
                            <option class="selec">.....</option>
                            <option class="selec">.....</option>
                        </select>
                        </div>
                        <div class="gap"></div>
                        <label>Skill Set</label>
                        <select class="selec" name="skill">
                            <option class="selec">skill</option>
                            <option class="selec">HTML</option>
                            <option class="selec">CSS</option>
                            <option class="selec">JS</option>
                            <option class="selec">PHP</option>
                        </select><div class="gap"></div>
                        <label>Applied Job</label>
                        <select class="selec" name="job">
                            <option class="selec">applied job</option>
                            <option class="selec">Web Developer</option>
                            <option class="selec">Frontend Developer</option>
                            <option class="selec">Backend Developer</option>
                        </select><div class="gap"></div><div class="gap"></div>
                        <input type="submit" onclick="check()" class="button">
                    </form>
                </div>
            </div>
            <div class="pic">
                <img src="img3.jpg" class="picture">
            </div>
        </div><br><br><div class="gap"></div><hr>
        <div class="footer"></div>
        <script src="register.js"></script>
    </body>
</html>