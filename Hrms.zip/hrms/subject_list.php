<?php 
    include("conn.php");
    session_start();
    $sid=$_SESSION["student_id"] ;
    $sname=$_SESSION['student_name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($sname) || empty($sid))
    {
       @header("Location: index.php");
       exit();
    }
    $cur_mon=date("m",strtotime(date("Y-m-d")));
    $cur_month_str= date("F", mktime(0, 0, 0,$cur_mon, 1));
    $stud1_qry=mysqli_query($conn,"SELECT * FROM `teacher_student_map` INNER JOIN `student_master` on `teacher_student_map`.`student_id`= `student_master`.`student_id` INNER JOIN `staff_registration_master` on `staff_registration_master`.`user_id`= `teacher_student_map`.`teacher_id` INNER JOIN `subject_master` on `subject_master`.`subject_id`=`teacher_student_map`.`subject_id` where `teacher_student_map`.`student_id`='$sid' and `teacher_student_map`.`status`='Active' ");
 
    ?>
     
  <!DOCTYPE html>
<html lang="en">

    <head>
        <title>Subject List</title>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link href="https://fonts.googleapis.com/css?family=Roboto:300&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i&display=swap" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" rel="stylesheet">  
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="subject_list.css"/>
    </head>

<body>
    <div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
        <div class="nav">
                <div class="subNavs"><a href="student_dashboard.php">Home</a></div>
                <div class="subNavs"><a href="s_change_pass.php">Change Password</a></div>
                <div class="subNavs"><a href="s_timetable.php">Time table</a></div>
                <div class="subNavs"><a href="subject_list.php">Subject List</a></div>
        </div>
        <div class="welcome">
            <div><h2>Welcome <?php echo $sname ?></h2></div> 
            <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
        </div>
    </div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
    <div class="dropbtn"><a href="student_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="s_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="s_timetable.php">Timetable</a></div>
        <div class="dropbtn"><a href="subject_list.php">Subject List</a></div>
    </div>
</div>

<div class="container">
        
        <!-- Image Cards -->
        <div class="card-category-2">
            
            <span class="category-name">Subject List</span> <br/><br/>
           
            <ul>
            <?php while($arr=mysqli_fetch_array($stud1_qry)){ ?>
                <li>
                    <div class="img-card iCard-style1">
                        <div class="card-content">
                            <div class="card-image">
                                <span class="card-title"><?php echo $arr['subject_name']?></span>
                                <!-- <img src="https://www.dropbox.com/s/u330jm6faybxrvb/fog-3461451_640.jpg?raw=1"/> -->
                                <img src="images/books.jpeg">
                            </div>
                            
                            <div class="card-text">
                                <p>
                                    <?php echo $arr['name']?>
                               </p>
                            </div>
                            <?php 
                            $_SESSION['subject_id']=$arr['subject_id'] ;
                            $_SESSION['teacher_id']=$arr['teacher_id'] ;
                            $_SESSION['class_id']=$arr['class_id'] ;
                            ?>
                        </div>
                        
                        <div class="card-link">
                            <span>Attendence</span>
                            <a href="student_attendence.php?subj_id=<?php echo $_SESSION['subject_id'] ?>&tid=<?php echo $_SESSION['teacher_id'] ?>&search=<?php echo $cur_month_str; ?>"><i class="fa-solid fa-clipboard-user"></i></a>&nbsp;&nbsp;&nbsp;
                            <span>Messages</span>
                            <a href="student_message.php?subj_id=<?php echo $_SESSION['subject_id'] ?>&tid=<?php echo $_SESSION['teacher_id'] ?>&search=<?php echo $cur_month_str; ?>"><i class="fa-regular fa-message"></i></a>
                            
                        </div>
                    </div> 
                           
                </li>
                <?php } ?>
                <!--
                <li>
                    <div class="img-card iCard-style2">
                        <div class="card-content">
                            <div class="card-image">
                                <span class="card-caption">Image Caption</span>
                                <img src="https://www.dropbox.com/s/63v40eqeq9lgz3k/bald-eagle-2715461_640.jpg?raw=1"/>
                            </div>
                            
                            <span class="card-title">Card Title</span>
                            
                            <div class="card-text">
                                <p>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Image by <a href="https://pixabay.com/users/moonzigg-6341937/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2715461" style="text-decoration: none">moonzigg</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2715461" style="text-decoration: none">Pixabay</a>
                                </p>
                            </div>
                            
                        </div>
                        
                        <div class="card-link">
                            <a href="#" title="Read Full"><span>Read Full</span></a>
                        </div>
                    </div>                    
                </li>
                
                <li>
                    <div class="img-card iCard-style3">
                        <div class="card-content">
                            <div class="card-image">
                                <span class="card-title">World Map</span>
                                <img src="https://www.dropbox.com/s/tclqbz7o4u8e705/ipad-632394_640.jpg?raw=1"/>
                            </div>
                            
                            <div class="card-text">
                                <p>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Image by <a href="https://pixabay.com/users/FirmBee-663163/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=632394" style="text-decoration:none">William  Iven</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=632394" style="text-decoration:none">Pixabay</a>
                                </p>
                            </div>
                            
                        </div>
                        
                        <div class="card-link">
                            <a href="#" title="Read Full">
                                <span>Go To Link</span>
                            </a>
                        </div>
                    </div>                    
                </li>
    
                <li>
                    <div class="img-card iCard-style4">
                        <div class="card-content">
                            <div class="card-image">
                                <span class="card-caption">Image Caption</span>
                                <img src="https://www.dropbox.com/s/ldjzn4dwz13m3vb/pomegranate-3383814_640.jpg?raw=1"/>
                            </div>
        
                            <div class="card-title"><span>The Title</span></div>
                            <br/>
                            <div class="toggle" onclick="showText(this)">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
        
                            <div class="card-text">
                                <p>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Image by <a href="https://pixabay.com/users/megspl-8890573/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3383814" style="text-decoration: none">megspl</a> from <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3383814"style="text-decoration: none">Pixabay</a>
                                </p>
                            </div>
                            
                        </div>
                        
                        <div class="card-link">
                            <a href="#" title="Read Full">
                                <span>Read More Link</span>                        
                            </a>
                        </div>
                    </div>                    
                </li>-->
            </ul>

        </div>

        
        
        <!-- Image Overlay Cards -->
        <!-- Product & Shop Cards-->
</div>       
        <script src="ScriptCards.js"></script>
        <script>
            function show()
            {
                console.log("!!!");
                document.getElementById('dropLinks').style.visibility="visible";
            }
            function hide()
            {
                document.getElementById('dropLinks').style.visibility="hidden"; 
            }
        </script>
    </body>
</html>