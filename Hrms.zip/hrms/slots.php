<?php
    //To do admin check
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name1))
    {
       @header("Location: index.php");
       exit();
    }
    if(isset($_REQUEST['submit']))
    {
        if(isset($_REQUEST['slot-name']) && $_REQUEST['slot-name'] != "")
        {
            $slotName = $_REQUEST['slot-name'];
            $roomID = $_REQUEST['room-id'];
            $dayID = $_REQUEST['day-id'];
            $timeID = $_REQUEST['time-id'];
            echo $timeID;
            $query = "INSERT INTO `slot_master` (`slot_name`,  `room_id`, `day_id`, `time_id`) VALUES ('$slotName', '$roomID', '$dayID', '$timeID');";
            $res = mysqli_query($conn, $query);
            if($res)
            {
                header("Location: slots.php");
            }
        }
    }
    if(isset($_REQUEST['delete']))
    {
        $slotID = (int) $_REQUEST['slot-id'];
        $query = "DELETE FROM `slot_master` WHERE `slot_id` = '$slotID'";
        try
        {
            $res = mysqli_query($conn, $query);
            header("Location: slots.php");
        }
        catch(Exception $e)
        {
            echo("Something went wrong");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include("title.php"); ?>
        <link rel="stylesheet" href="style.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>

        

        <div class="container">
            <h2>Your Slots</h2>
            <p>Add or modify your slots here</p>
            <br>

            <div class="tableDiv">
                <form method="POST">
                    <h3>Add Slot</h3>
                    <div style="height: 8px;"></div>
                    <input class="font-12" type="text" placeholder="Enter slot name" name="slot-name">
                    <div style="height: 4px;"></div>
                    <div class="flex gap-8">
                        <div>
                            <label for="room-id">Select Room</label>
                            <br>
                            <select name="room-id">
                                <option value="">Select a room</option>
                                <?php
                                    $query = "SELECT * FROM `room_master`";
                                    $res = mysqli_query($conn, $query);
                                    while($ar = mysqli_fetch_array($res))
                                    {
                                ?>
                                        <option value="<?php echo $ar['room_id']; ?>">
                                            <?php echo $ar['room_name']; ?>
                                        </option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                        <div>
                            <label for="day-id">Select Day</label>
                            <br>
                            <select name="day-id">
                                <option value="">Select a day</option>
                                <?php
                                    $query = "SELECT * FROM `day_master`";
                                    $res = mysqli_query($conn, $query);
                                    while($ar = mysqli_fetch_array($res))
                                    {
                                ?>
                                        <option value="<?php echo $ar['day_id']; ?>">
                                            <?php echo $ar['day_name']; ?>
                                        </option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                        <div>
                            <label for="time-id">Select Time</label>
                            <br>
                            <select name="time-id">
                                <option value="">Select a time</option>
                                <?php
                                    $query = "SELECT `time_id`, TIME_FORMAT(`start_time`, '%h:%i %p') AS start_time, TIME_FORMAT(`end_time`, '%h:%i %p') AS end_time FROM `time_master`";
                                    $res = mysqli_query($conn, $query);
                                    while($ar = mysqli_fetch_array($res))
                                    {
                                ?>
                                        <option value="<?php echo $ar['time_id']; ?>">
                                            <?php echo $ar['start_time']; ?>
                                            —
                                            <?php echo $ar['end_time']; ?>
                                        </option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div style="height: 4px;"></div>
                    <input class="font-12" type="submit" name="submit">
                </form>
            </div>

            <br><br>

            <div class="tableDiv">
                <h3>Available Slots</h3>
                <div style="height: 8px;"></div>
                <table width="25%">
                    <thead>
                        <tr>
                            <td class="font-18">Slot Name</td>
                            <td class="font-18">Room</td>
                            <td class="font-18">Day</td>
                            <td class="font-18">Time</td>
                            <td class="font-18">Operations</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $query = "SELECT 
                                          sm.`slot_id`,
                                          sm.`slot_name`,
                                          sm.`activity`,
                                          rm.*,
                                          dm.*,
                                          tm.*
                                      FROM `slot_master` sm
                                      LEFT JOIN `room_master` rm ON sm.`room_id` = rm.`room_id`
                                      LEFT JOIN `day_master` dm ON sm.`day_id` = dm.`day_id`
                                      LEFT JOIN `time_master` tm ON sm.`time_id` = tm.`time_id`;";
                            $res = mysqli_query($conn, $query);
                            while($ar = mysqli_fetch_array($res))
                            {
                        ?>
                        <tr>
                            <form method="POST">
                                <td>
                                    <input class="pseudo-input font-16" type="hidden" value="<?php echo $ar['slot_id']; ?>" name="slot-id">
                                    <input class="pseudo-input font-16" type="text" value="<?php echo $ar['slot_name']; ?>" name="slot-name">
                                </td>
                                <td>
                                    <input class="pseudo-input font-16" type="hidden" value="<?php echo $ar['room_id']; ?>" name="room-id">
                                    <input class="pseudo-input font-16" type="text" value="<?php echo $ar['room_name']; ?>" name="room-name">
                                </td>
                                <td>
                                    <input class="pseudo-input font-16" type="hidden" value="<?php echo $ar['day_id']; ?>" name="day-id">
                                    <input class="pseudo-input font-16" type="text" value="<?php echo $ar['day_name']; ?>" name="day-name">
                                </td>
                                <td>
                                    <input class="pseudo-input font-16" type="hidden" value="<?php echo $ar['time_id']; ?>" name="time-id">
                                    <div class="flex gap-8">
                                        <div>
                                            <input class="pseudo-input font-16" type="time" value="<?php echo $ar['start_time']; ?>" name="start-time">
                                        </div>
                                        —
                                        <div>
                                            <input class="pseudo-input font-16" type="time" value="<?php echo $ar['end_time']; ?>" name="end-time">
                                        </div>
                                    </div>
                                </td>
                                <td><input type="submit" name="delete" value="Delete"></td>
                            </form>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script src="admin_dashboard.js"></script>
    </body>
</html>