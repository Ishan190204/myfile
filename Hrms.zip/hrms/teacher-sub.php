<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
      if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
      else
        {   
          $mspg  = ""; 
        } 
        if(!empty($_REQUEST['id']))
        {  
          $id = $_REQUEST['id'];  
          $Teacher_sql1 ="SELECT `user_id`,`name` from  `staff_registration_master`  where `user_type`='Te' and `user_status`='Yes' and `user_id`='$id'"  ;
          $Teach_set1=mysqli_query($conn,$Teacher_sql1);
          $tarr=mysqli_fetch_array($Teach_set1);
          if(!empty($tarr)){
            $tname=$tarr['name'];
          }
        } 
      
    
      
        
        $fetch_sub="SELECT `subject_name`,`subject_id` from `subject_master` where `status`='Active'";
     $st_sub=mysqli_query($conn,$fetch_sub);
    /* teacher*/  
    $Teacher_sql ="SELECT `user_id`,`name` from  `staff_registration_master`  where `user_type`='Te' and `user_status`='Yes'"  ;
    $Teach_set=mysqli_query($conn,$Teacher_sql);
    /* class*/
    $Class_sql ="SELECT `class_id`,`class_name` from  `class_master`  where  `status`='Active'"  ;
    $Class_set=mysqli_query($conn,$Class_sql);
    
        
    if(!empty($_REQUEST['mode']) && !empty($_REQUEST['add']))
    {  
        if(!empty( $_REQUEST['teacher_id'])){
            $teacher_id = $_REQUEST['teacher_id'];
        }
        elseif(!empty( $_REQUEST['teacher_id1'])){
            $teacher_id = $id;
        }
        $class_id= $_REQUEST['class_id'];
        $subject_id = $_REQUEST['subject_id'];
      
        $ts_insert="INSERT INTO `teacher_subject_map` SET 
        `teacher_id`= '$teacher_id',
        `class_id`= '$class_id',
        `subject_id`= '$subject_id' ";  
        $ts_sql=mysqli_query($conn, $ts_insert);

        if($ts_sql)
        {
        @header("Location:teacher-sub.php?id=$teacher_id&cid=$class_id&msg=added");
            exit(); 

        }
    }
    if(!empty($_REQUEST['mode']) && !empty($_REQUEST['submit']) )
    {  
        if(!empty( $_REQUEST['teacher_id'])){
            $teacher_id = $_REQUEST['teacher_id'];
        }
        elseif(!empty( $_REQUEST['teacher_id1'])){
            $teacher_id = $id;
        }
        $class_id= $_REQUEST['class_id'];
        $subject_id = $_REQUEST['subject_id'];
      
      $ts_insert="INSERT INTO `teacher_subject_map` SET 
                `teacher_id`= '$teacher_id',
                `class_id`= '$class_id',
                `subject_id`= '$subject_id' ";  
      $ts_sql=mysqli_query($conn, $ts_insert);
      
      if($ts_sql)
        {
          @header("Location:teacher-sub.php?msg=Inserted");
		      exit(); 

        }
    }

?> 

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Teacher-Subject</title>
        <link rel="stylesheet" href="teacher-sub.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>
  

        <div style="height:90px;"></div>
        <div class="superContainer">
            <div class="container">
                <div class="heading">Teacher-Subject <br>Form</div>
                <form class="form" enctype="multipart/form-data" method="post" name="task_assn_form" id="task_assn_form" onSubmit="return checking();">
                    <input type="hidden" name="mode" value="1">
                    <div class="inputContainer" <?php if(!empty($id)){ ?> style="display: none" <?php } ?>>
                        <label for="teacher_id">Teacher:</label>
                       <select class="inputSelect" name="teacher_id" id="teacher_id" >
                            <option value="">Select Teacher</option>
                            <?php  while($row=mysqli_fetch_array($Teach_set)){ ?>
                            <option value="<?php echo $row['user_id'] ?>" ><?php echo $row['name'] ;?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="inputContainer" <?php if(empty($id)){ ?> style="display: none" <?php } ?>>
                        <label>Class</label><input type="text" class="inputField" placeholder="Teacher Name" name="teacher_id1" id="teacher_id1" value="<?php if(!empty($tname)){ echo $tname ;}?>">
                    </div>
                    
                
                    <div class="inputContainer" >
                        <label for="class_id">Class:</label>
                       <select class="inputSelect" name="class_id" id="class_id"  >
                            <option value="">Class</option>        
                            <?php while($row2=mysqli_fetch_array($Class_set)){ ?>
                            <option value="<?php echo $row2['class_id'] ?>"><?php echo $row2['class_name'] ;?></option>
                                    <?php } 
                                   ?>
                        </select>
                    </div>
                    <div class="inputContainer">
                        <label for="subject_id">Subject:</label>
                        <select class="inputSelect" name="subject_id" id="subject_id" >
                            <option value="">Subject</option>
                            <?php while($row3=mysqli_fetch_array($st_sub)){ ?>
                            <option value="<?php echo $row3['subject_id'] ?>"  ><?php echo $row3['subject_name'] ;?></option>
                                    <?php } ?>
                        </select>
                    </div> 
                    <input type="submit" name="add" value="Add" class="assign-btn">                   
                    <div class="gap"></div> 
                <input type="submit" class="assign-btn" name="submit" value="Submit" >
                </form>
                <h4 align="center" style="color:red;font-weight:bold;"><?php echo $mspg;?></h4>
            </div>
        </div>
        <script src="teacher-sub.js"></script>
        
    </body>
</html>