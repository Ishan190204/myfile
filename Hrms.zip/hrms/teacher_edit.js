var tch_id = document.getElementById("teacher");
function teacher_chk(){
    window.location.href="teacher_edit.php?tch="+tch_id.value;
}

function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}