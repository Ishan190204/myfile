<?php 
    include("conn.php");
    session_start();
    $name=$_SESSION['name'];
    if(!empty($_REQUEST['tid'])){
    $tid=$_REQUEST['tid'];
    $class_id=$_REQUEST['cl'];
    $subject_id=$_REQUEST['sb'];
    }
    $stud_qry=mysqli_query($conn,"SELECT * FROM `teacher_student_map` INNER JOIN `student_master` on `teacher_student_map`.`student_id`= `student_master`.`student_id`  where `teacher_student_map`.`teacher_id`='$tid' and  `teacher_student_map`.`subject_id`='$subject_id' and `teacher_student_map`.`class_id`='$class_id' and `student_master`.`status`='Active' and `teacher_student_map`.`status`='Active' ");
 
$k=0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendence</title>
    
    <link rel="stylesheet" href="student.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dash">Teacher Dashboard</div>
    <div class="nav">
        <div class="subNavs"><a href="teacher_dashboard.php">Home</a></div>
        <div class="subNavs"><a href="student_list.php">Student-List</a></div>
        <div class="subNavs"><a href="attendence_table.php">Attendence</a></div>
    </div>
    <div class="welcome">
    <h2>Welcome <?php echo $name ?></h2> 
    <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>  
</div>

    <div class="container">
        <p align="center">Student List</p>
        
            <div class="top">
                <div>
                    Show
                    <select>
                        <option value="">1</option>
                        <option value="">2</option>
                        <option value="">3</option>
                        <option value="">4</option>
                        <option value="">5</option>
                        <option value="">6</option>
                        <option value="">7</option>
                        <option value="">8</option>
                        <option value="">9</option>
                        <option value="">10</option>
                    </select>
                    entries
                </div>
                <div >
                    Search <input type="search"  id="srch" onchange="filter(this.value)" >
                </div>
            </div>
            <form class="subform"  action="" name="attendenceform" id="attendenceform" method="post" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1" />

            <table border="1" align="center">
                <tr>
                    
                    <th>Id</th>
                    <th>Student Name</th>            
                </tr>
                <?php  while($arr=mysqli_fetch_array($stud_qry)){?> 
                <tr>
                    
                <td><?php echo ++$k; ?></td>
                    <td><?php echo $arr['student_name']; ?></td>
                    
                    
                </tr>
                
                <?php } ?>
                
            </table>
              </form>
        </div>
    </div>
    <script src="attendence_form.js"></script>
</body>
</html>
