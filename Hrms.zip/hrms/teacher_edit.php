<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
    $k=0;
    $fetch_teacher="SELECT * from `staff_registration_master` where `user_type`='Te'";
    $ft_res=mysqli_query($conn,$fetch_teacher);

    if(!empty($_REQUEST['tch']))
    {
        $tch_id = $_REQUEST['tch'];
        
        $table="SELECT `subject_master`.`subject_name`,`class_master`.`class_name`,`teacher_id`,`teacher_subject_map`.`subject_id`,`teacher_subject_map`.`class_id` from `teacher_subject_map` inner join `subject_master` on `teacher_subject_map`.`subject_id`=`subject_master`.`subject_id` inner join `class_master` on `teacher_subject_map`.`class_id`=`class_master`.`class_id` where `teacher_subject_map`.`teacher_id`='$tch_id' and `teacher_subject_map`.`status`='Active'";
        $table_res=mysqli_query($conn,$table);
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="teacher_edit.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div> 


        <div class="container">
        <p align="center">Teacher List</p>
        <div style="gap:10px" align="center">      
                        <select class="inputSelect" name="teacher" id="teacher" onchange="teacher_chk()">
                            <option value="">Select Teacher</option>
                            <?php while($row=mysqli_fetch_array($ft_res)){ ?>
                                <option value="<?php echo $row['user_id'] ?>" <?php if(!empty($tch_id) && $tch_id==$row['user_id']) echo "selected" ;?>><?php echo $row['name'] ?></option>
                                    <?php } ?>
                        </select>
        <div>
            <br>
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>Sl.No.</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Inactive</th>
                </tr>
                <?php if(!empty($tch_id)) {while($arr=mysqli_fetch_array($table_res)){ ?> 
                <tr>
                    <td><?php echo ++$k;  ?></td>
                    <td><?php echo $arr['class_name'];  ?></td>
                    <td><?php echo $arr['subject_name'];  ?></td>
                    
                    <td><a href="teacher_delete.php?tid=<?php echo $arr['teacher_id'] ?>&cl=<?php echo $arr['class_id'] ?>&sb=<?php echo $arr['subject_id'] ?>" >Delete</td>
                    </tr>
                <?php } }
                    ?>  
            </table>
            </div>
        </div>
    </div>
    <script src="teacher_edit.js"></script>      
</body>
 </html>       