
function st_checking()
{
    let mob = document.getElementById('phone').value;
    let  mobile = mob.trim();
    
        
    if(document.getElementById('student_name').value=='')
        {
            alert('Please enter student name!');
            document.st_register_form.student_name.focus();
            return false;
        }
    if(document.getElementById('class_id').value=='')
        {
            alert('Please select Class');
            document.st_register_form.class_id.focus();
            return false;
        }	
    if(mobile.length != 10 && document.getElementById('phone').value!='0')
        {
            alert('Please enter phone no!');
            document.st_register_form.phone.focus();
            return false;
        }
    if(document.getElementById('gender').value=='')
        {
            alert('Please select Gender');
            document.st_register_form.gender.focus();
            return false;
        }
    if(document.getElementById('admission_date').value=='')
        {
            alert('Please enter Admission date');
            document.st_register_form.admission_date.focus();
            return false;
        }		       
}
function st_loginchecking()
{
    
if(document.getElementById('student_name1').value=='')
        {
            alert('please enter student name!');
            document.st_loginform.student_name1.focus();
            return false;
        }	
if(document.getElementById('password1').value=='')
        {
            alert('Please enter password!');
            document.st_loginform.password1.focus();
            return false;
        }	

}
/*function changepage(val){
window.location.href='student_activity.php?cid='+val;
}*/

const elem=document.getElementById('user_description_type').cloneNode(true);
            const ogg=elem.options;
            console.log(ogg);
            document.getElementById('user_description_type').innerHTML='<option value=""> Please Select a User Description</option>';
            function userdesc_chk(vall){
                document.getElementById('user_description_type').innerHTML='<option value=""> Please Select a User Type</option>';
            
                for(let j of ogg)
                {
                if(j.dataset)
                console.log(j.dataset.value)
                if(j.dataset.value===vall)
                document.getElementById('user_description_type').innerHTML+=`<option value="${j.value}"> ${j.dataset.subb}</option>`; 
                }
            }

function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}