<?php 
    include("conn.php");
    session_start();
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    
    if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
    else
        {   
          $mspg  = ""; 
        } 
        /* for login validation*/ 
        $fetch_stud ="SELECT `student_name`,`password`,`student_id` from `student_master`"  ;
        $stud_descr1=mysqli_query($conn,$fetch_stud);
/* for register fetch from user description
    $fetch_userdesc ="SELECT `user_description_name` from `user_description` order by `user_description_id`"  ;
    $user_desc=mysqli_query($conn,$fetch_userdesc);
    $fetch_usertype="SELECT `user_description_name`,`user_description_type` from `user_description` order by `user_description_id`";
    $user_desctype=mysqli_query($conn,$fetch_usertype);*/
    $fetch_class="SELECT `class_name`,`class_id` from `class_master` order by `class_id`";
    $st_class=mysqli_query($conn,$fetch_class);
    if(!empty($_REQUEST['login']))
    {  
        $res_studname = $_REQUEST['student_name1'];
        $res_Password = $_REQUEST['password1'];
        
    
        
        $flag='0';
        while($arr=mysqli_fetch_array($stud_descr1)){
            if($res_studname===$arr['student_name'] and $res_Password===$arr['password']){
                $flag='1';
                $res_userid= $arr['student_id'];
                $res_name=$arr['student_name'];
        } 
      }
      if($flag==='1' and isset($res_userid)){
        $_SESSION["student_id"] = $res_userid;
        $_SESSION['student_name']=$res_name;
        @header("Location:student_dashboard.php?msg= login Successfull");
        exit();  
      }
      else{
        @header("Location:student-log-reg.php?msg=please enter valid username or password !");
        exit(); 
      }
    }
    if(!empty($_REQUEST['register']))
    {  
        $student_name = $_REQUEST['student_name'];
        $class = $_REQUEST['class_id'];
        $phone = $_REQUEST['phone'];
        $address = $_REQUEST['address'];
        $board = $_REQUEST['board'];
        $email = $_REQUEST['email'];
        $age = $_REQUEST['age'];
        $gender = $_REQUEST['gender'];
        $admission_date = $_REQUEST['admission_date'];
        $student_name1=ucwords($student_name);
      
      $sql_stud="INSERT INTO `student_master` SET 
                `student_name`= '$student_name1',
                `student_class`= '$class',
                `phone`= '$phone',
                `address`= '$address',
                `board`= '$board',
                `email`= '$email',
                `age`= '$age',
                `gender`= '$gender',
                `admission_date`= '$admission_date',
                `password`= '$phone',
                `status`='Active' ";  
      $res=mysqli_query($conn, $sql_stud);
      
      if($res)
        {
          @header("Location: student-log-reg.php?msg=Successfull registered");
		      exit();  		
        }
    }

?> 
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login/Registration</title>
        <link rel="stylesheet" href="log-reg.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    </head>
    <body>
        <div class="navbar">
            <div class="dashboard">
                <div class="dashlogo"><img src="images/NEW_LOGO__1___1_.png" class="logo"></div>
                <div class="dash">Shikhshaneer</div>
            </div>
            <div class="nav">
                <div class="subNavs"><a href="index.php">Home</a></div>
                <div class="subNavs"><a href="log-reg.php">Login/ Register</a></div>
                <div class="subNavs"><a href="student-log-reg.php">Student Login/Register</a></div>
            </div>   
        </div>
        <div class="drops">
            <img src="images/side-lines.svg" height="35" width="30" onclick="show()">
        </div> 
        <div id="dropLinks">
            <div class="closebtn">
                <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
            </div> 
            <div class="dropdown">
                <div class="dropbtn"><a href="index.php">Home</a></div>
                <div class="dropbtn"><a href="log-reg.php">Login/ Register</a></div>
                <div class="dropbtn"><a href="student-log-reg.php">Student Login/Register</a></div>
            </div>
        </div> 
        <div style="height:100px;"></div>
        <div class="wrapper">
            <div class="card-switch">
                <label class="switch">
                   <input type="checkbox" class="toggle">
                   <span class="slider"></span>
                   <span class="card-side"></span>
                   <div class="flip-card__inner">
                      <div class="flip-card__front">
                         <div class="title">Log in</div>
                         
                         <form class="flip-card__form" action="" name="st_loginform" id="st_loginform" method="post" onSubmit="return st_loginchecking();">
                            <input type="hidden" name="login" value="1" />
                            
                            <input class="flip-card__input" name="student_name1"  id="student_name1" placeholder="Student name" type="text" autofocus >
                            <input class="flip-card__input" name="password1" id="password1" placeholder="Password" type="password">
                            <button class="flip-card__btn">Login</button>
                            
                         </form>
                         <h4 align="center"style="color:red;"><?php echo $mspg ?></h4>
                      </div>

                      <div class="flip-card__back">
                         <div class="title">Student-Register</div>
                         <form class="flip-card__form" action="" name="st_register_form" id="st_register_form" method="post" onSubmit="return st_checking();">
                         <input type="hidden" name="register" value="1" />
                            <input class="flip-card__input" placeholder="Student name*" name="student_name" id="student_name" type="text" style="text-transform: capitalize;" >
                            
                            <select class="flip-card__select" name="class_id" id="class_id">
                                <option value="">Class*</option>
                                <?php while($row=mysqli_fetch_array($st_class)){ ?>
                                <option value="<?php echo $row['class_id'] ?>"><?php echo $row['class_name'] ?></option>
                                <?php } ?>     
                            </select>
                            <input class="flip-card__input" placeholder="Phone no*" type="number" name="phone" id="phone">
                            <input class="flip-card__input" placeholder="Address" type="text" name="address" id="address">
                            <select class="flip-card__select" name="board" id="board">
                                <option value="">Board-Type</option>
                                <option value="WBSSE">WBSSE</option>
                                <option value="ICSE">ICSE</option>
                                <option value="CBSE">CBSE</option>
                                <option value="ISC">ISC</option>     
                                <option value="Others">Others</option>     
                            </select>
                            <input class="flip-card__input" placeholder="Email" type="text" name="email" id="email">
                            <input class="flip-card__input" placeholder="Age" type="number" name="age" id="age">

                            <select class="flip-card__select" name="gender" id="gender">
                                <option value="">Gender*</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="others">Others</option>  
                            </select>
                            <input class="flip-card__input" placeholder="Admission-date*" type="date" name="admission_date" id="admission_date" value="<?php echo date("Y-m-d"); ?>" max="<?php echo date("Y-m-d"); ?>">
                                     
                            <button class="flip-card__btn">Register</button>
                         </form>
                      </div>
                   </div>
                </label>
            </div>
       </div>
        <script src="student-log-reg.js"></script>
    </body>

</html>