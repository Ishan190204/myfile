
const elem=document.getElementById('user_id').cloneNode(true);
const ogg=elem.options;
document.getElementById('user_id').innerHTML='<option value="">Select a usertype</option>';
function user_typechk(vall){
    document.getElementById('user_id').innerHTML='<option value="">Select user</option>';

    for(let j of ogg)
    {
    if(j.dataset)
    console.log(j.dataset.value)
    if(j.dataset.value===vall)
    document.getElementById('user_id').innerHTML+=`<option value="${j.value}"> ${j.dataset.subb}</option>`; 
    }
}

function checking()
{
    
        
        if(document.getElementById('user_type').value=='')
        {
            alert('Please enter user-type!');
            document.task_assn_form.user_type.focus();
            return false;
        }
if(document.getElementById('user_id').value=='')
        {
            alert('enter username!');
            document.task_assn_form.user_id.focus();
            return false;
        }	
if(document.getElementById('task_description').value=='')
        {
            alert('Please enter task!');
            document.task_assn_form.task_description.focus();
            return false;
        }	
        if(document.getElementById('task_assign_date').value=='')
        {
            alert('Please enter assign date!');
            document.task_assn_form.task_assign_date.focus();
            return false;
        }
        
        if(document.getElementById('start_date').value=='')
            {
                alert('Please enter start date!');
                document.task_assn_form.start_date.focus();
                return false;
            }  
            
            if(document.getElementById('end_date').value=='')
                {
                    alert('Please enter end date!');
                    document.task_assn_form.end_date.focus();
                    return false;
                }    
        if(document.getElementById('priority').value=='')
        {
            alert('Please enter priority!');
            document.task_assn_form.priority.focus();
            return false;
        }	
        
        /*if(document.getElementById('pdf').value=='')
            {
                alert('Please upload pdf!');
                document.task_assn_form.pdf.focus();
                return false;
            }	 */	
}
function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}
/*function changepage(val){
window.location.href='student_activity.php?cid='+val;
}*/

  
  /*function search(){
 if(document.getElementById('user_id').value!="")
    {
      window.location.href="task_assign.php?search=true&username="+document.getElementById('user_id').value.trim();
    }
  }*/
