<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
    if(empty($name1))
    {
       @header("Location: index.php");
       exit();
    }
    if(!empty($_SESSION["tid"]))
    {
        unset($_SESSION["tid"]);
    }
   
    $fetch_teacher="SELECT * from `staff_registration_master` where `user_type`='Te' and `user_status`='Yes' ";
    $ft_res=mysqli_query($conn,$fetch_teacher);
$k=0;
if(!empty($_REQUEST['tch']))
    {
        $tch_id = $_REQUEST['tch'];
        
        $fetch_teacher1="SELECT `staff_registration_master`.`name`,`class_master`.`class_name`,`subject_master`.`subject_name`,`teacher_subject_map`.`teacher_id`,`teacher_subject_map`.`class_id`,`teacher_subject_map`.`subject_id` from `teacher_subject_map` inner join `staff_registration_master` on `teacher_subject_map`.`teacher_id`=`staff_registration_master`.`user_id` inner join `class_master` on `teacher_subject_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_subject_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_subject_map`.`teacher_id`='$tch_id' ";
        $ft_res1=mysqli_query($conn,$fetch_teacher1);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Book Table</title>
    
    <link rel="stylesheet" href="admin_attendence.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>  

<div class="container">
        <p align="center">ATTENDENCE-REPORT</p>
        <div class="give_attendence" align="center"  <?php if(empty($tch_id)) { ?> style="display:none;" <?php } ?>><a href="admin_attendence_student.php?tid=<?php echo $tch_id ;?> " >Click here for give attendence</a></div>

        <div style="gap:10px" align="center">      
                        <select class="inputSelect" name="teacher" id="teacher" onchange="teacher_chk()">
                            <option value="">Select Teacher</option>
                            <?php while($row=mysqli_fetch_array($ft_res)){ ?>
                                <option value="<?php echo $row['user_id'] ?>" <?php if(!empty($tch_id) && $tch_id==$row['user_id']) echo "selected" ;?>><?php echo $row['name'] ?></option>
                                    <?php } ?>
                        </select>
        <div>
            <br>
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>ID</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Student List</th>
                    <th>Attendence List</th>
                </tr>
                <?php  if(!empty($tch_id)) {while($arr=mysqli_fetch_array($ft_res1)){?> 
                <tr>
                    <td><?php echo ++$k ;  ?></td>
                    <td><?php echo $arr['class_name'];  ?></td>
                    <td><?php echo $arr['subject_name'];  ?></td>
                    <td><div align="center"><button class="srch-btn"><a href="admin_student.php?tid=<?php echo $arr['teacher_id']; ?>&cl=<?php echo $arr['class_id']?>&sb=<?php echo $arr['subject_id']?>"><i class="fa-solid fa-clipboard-check"></i></button></div></td>
                    <td><div align="center"><button class="srch-btn"><a href="admin_atten_list.php?tid=<?php echo $arr['teacher_id']; ?>&cl=<?php echo $arr['class_id']?>&sb=<?php echo $arr['subject_id']?>"><i class="fa-solid fa-clipboard-user"></i></button></div></td>

                </tr>
                <?php } } ?>
                
            </table>
            </div>
        </div>
    </div>
    <script  src="admin_attendence.js">
    </script>
</body>
</html>
