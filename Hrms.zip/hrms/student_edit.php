<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    
    
      if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
      else
        {   
          $mspg  = ""; 
        } 
        if(!empty($_REQUEST['st_id']))
        {  
          $st_id = $_REQUEST['st_id']; 
          $cl_id = $_REQUEST['cl']; 
          $stud ="SELECT * from `student_master` where `status`='Active' and `student_id`='$st_id' "  ;
          $stud_qry=mysqli_query($conn,$stud);
          $st_ar=mysqli_fetch_array($stud_qry);
        } 
      else
        {   
          $st_id  = ""; 
        } 
      
    $st ="SELECT * from `class_master` where `status`='Active' "  ;
    $st_class=mysqli_query($conn,$st);

    
    if(!empty($_REQUEST['mode']))
    {  
        $student_name = $_REQUEST['student_name'];
        $class = $_REQUEST['class_id'];
        $phone = $_REQUEST['phone'];
        $address = $_REQUEST['address'];
        $board = $_REQUEST['board'];
        $email = $_REQUEST['email'];
        $age = $_REQUEST['age'];
        $gender = $_REQUEST['gender'];
        $admission_date = $_REQUEST['admission_date'];
      
      $sql_up="UPDATE `student_master` SET 
                `student_name`= '$student_name',
                `student_class`= '$class',
                `phone`= '$phone',
                `address`= '$address',
                `board`= '$board',
                `email`= '$email',
                `age`= '$age',
                `gender`= '$gender',
                `admission_date`= '$admission_date',
                `password`= '$phone' where `student_id`='$st_id' ";  
      $st_updt=mysqli_query($conn, $sql_up);
      
      if($st_updt)
        {
          @header("Location: student_list_status.php?msg=edited&class=$cl_id");
		      exit(); 

        }
    }

?> 

<!DOCTYPE html>
<html>
    <head>
        <title>Student Edit</title>
        <link rel="stylesheet" href="student_edit.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
       
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div>
      <div id="dropLinks">
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>



        <br><br>
    <div><p align="center" style="color:red;font-weight:bold;"><?php echo $mspg;?></p></div>
        <div class="superContainer">
            <div class="container">
                <div class="heading">Student Edit <br>Form</div>
                <form class="form" enctype="multipart/form-data" method="post" name="task_assn_form" id="task_assn_form" onSubmit="return checking();">
                    <input type="hidden" name="mode" value="1">
                    <div class="inputContainer">
                        <label>Student Name</label><input type="text" class="inputField" placeholder="Student name" name="student_name" id="student_name" value="<?php echo $st_ar['student_name'] ;?>">
                    </div>
                       
                    <div class="inputContainer">
                        <label for="class_id">Class</label>
                        <select class="inputSelect" name="class_id" id="class_id" >
                            <option value="">Class*</option>
                                <?php while($row=mysqli_fetch_array($st_class)){ ?>
                                <option value="<?php echo $row['class_id'] ?>"  <?php if($row['class_id']==$st_ar['student_class']) echo "selected" ?> ><?php echo $row['class_name'] ?></option>
                                <?php } ?> 
                        </select>
                    </div> 
                    <div class="inputContainer">
                        <label for="board">Board</label>
                        <select class="inputSelect"  name="board" id="board">
                        <option value="">Board-Type*</option>
                                <option value="WBSSE" <?php if($st_ar['board']=='WBSSE') echo "selected" ?> >WBSSE</option>
                                <option value="ICSE" <?php if($st_ar['board']=='ICSE') echo "selected" ?> >ICSE</option>
                                <option value="CBSE" <?php if($st_ar['board']=='CBSE') echo "selected" ?>>CBSE</option>
                                <option value="ISC" <?php if($st_ar['board']=='ISC') echo "selected" ?>>ISC</option>     
                                <option value="Others" <?php if($st_ar['board']=='Others') echo "selected" ?>>Others</option>
                        </select>        
                    </div>
                    <div class="inputContainer">
                        <label>Phone No.</label><input type="text" class="inputField" placeholder="Phone" name="phone" id="phone" value="<?php echo $st_ar['phone'] ;?>">
                    </div>
                    <div class="inputContainer">
                        <label>Address</label><input type="text" class="inputField" placeholder="Address" name="address" id="address" value="<?php echo $st_ar['address'] ;?>">
                    </div>
                   
                    <div class="inputContainer">
                        <label for="gender">Gender</label>
                        <select class="inputSelect"  name="gender" id="gender">
                        <option value="">Gender*</option>
                                <option value="male"<?php if($st_ar['gender']=='male') echo "selected" ?>>Male</option>
                                <option value="female" <?php if($st_ar['gender']=='female') echo "selected" ?>>Female</option>
                                <option value="others" <?php if($st_ar['gender']=='others') echo "selected" ?>>Others</option> 
                        </select>        
                    </div>
                    <div class="inputContainer">
                        <label>Email</label><input type="text" class="inputField" placeholder="Email" name="email" id="email" value="<?php echo $st_ar['email'] ;?>">
                    </div>
                    <div class="inputContainer">
                        <label>Age</label><input type="number" class="inputField" placeholder="Age" name="age" id="age" value="<?php echo $st_ar['age'] ;?>">
                    </div>
                    <div class="inputContainer">
                        <label>Admission Date</label><input type="date" class="inputField" name="admission_date" id="admission_date" value="<?php echo $st_ar['admission_date'] ;?>">
                    </div>
                   
                 
                    <div class="gap"></div> 
                <input type="submit" class="assign-btn" value="Edit">
                </form>
            </div>
        </div>
        <script src="student_edit.js"></script>
        <script>
            
            </script>
    </body>
</html>