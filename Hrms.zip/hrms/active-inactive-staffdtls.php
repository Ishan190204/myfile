<?php 
include("conn.php");
$id=$_REQUEST['userid'];
$fetch=mysqli_query($conn,"SELECT  `user_status` FROM `staff_registration_master` WHERE `user_id`='$id'");
$arr=mysqli_fetch_array($fetch);
if($arr['user_status']==='No'){
$data=mysqli_query($conn,"UPDATE  `staff_registration_master` SET `user_status`='Yes' WHERE `user_id`='$id'");
@header("Location: staff-details.php");
}
else{
$data=mysqli_query($conn,"UPDATE  `staff_registration_master` SET `user_status`='No' WHERE `user_id`='$id'");
@header("Location: staff-details.php");
}