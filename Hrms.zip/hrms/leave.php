<?php 
include("conn.php");
session_start();
$userid=$_SESSION["user_id"];
$name=$_SESSION["name"];
if(mysqli_connect_errno()){
    echo "failed to connect to mysql" . mysqli_connect_error();
}
if(empty($name) || empty($userid))
{
   @header("Location: index.php");
   exit();
}
if(isset($_REQUEST['msg'])){
    $mspg=$_REQUEST['msg'];
}
else{
    $mspg="";
}

$leave=mysqli_query($conn,"SELECT `leave_id`,`leave_type` from `leave_master`");
if(!empty($_REQUEST['mode']))
    {  
        $user_id=$userid;
        $leave_id = $_REQUEST['leave_id'];
        $leave_start_date = $_REQUEST['leave_start_date'];
        $leave_end_date = $_REQUEST['leave_end_date'];
        $reason = $_REQUEST['reason'];
        $leave_type=mysqli_query($conn,"SELECT `leave_type` from `leave_master` where `leave_id`='$leave_id' ");
        $type=mysqli_fetch_array($leave_type);
        $lt=$type['leave_type'];
        $leave_map=mysqli_query($conn,"SELECT `left_leave_balance` from `staff_leave_mapping` where `user_id`='$user_id' and `leave_id`='$leave_id' ");
        $leave_bal=mysqli_fetch_array($leave_map);
        if(isset($leave_bal)){
            $bal=$leave_bal['left_leave_balance'];
        }
        else{
            $bal=10;
        }

        $date1=date_create($leave_start_date);
        $date2=date_create($leave_end_date);
        $diff=date_diff($date1,$date2);
        $delay= $diff->format("%R%a");
         if($bal >= $delay){
            $dur=$delay;
            $sql_leave_req="INSERT INTO `leave_request` SET
                        `user_id`='$user_id',
                        `leave_id`= '$leave_id',
                        `leave_start_date`= '$leave_start_date',
                        `leave_end_date`= '$leave_end_date',
                        `duration`='$dur',
                        `reason`= '$reason',
                        `status`='Pending'";  
            $lev1=mysqli_query($conn, $sql_leave_req);
            
            if($lev1)
                {
                @header("Location:leave.php?msg=Successfully requsted for leave ");
                    exit(); 

                }
        }
        else{
            @header("Location:leave.php?msg=you have only $bal days left for $lt leave ");
                    exit(); 
        }
    }


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Request-Leave</title>
        <link rel="stylesheet" href="leave.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
<body>
<div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
            <div class="nav">
                <div class="subNavs"><a href="user_dashboard.php">Home</a></div>
                <div class="subNavs"><a href="u_change_pass.php">Change Password</a></div>
                <div class="subNavs"><a href="task-list.php">Task List</a></div>
                <div class="subNavs"><a href="leave.php">Request Leave</a></div>
                <div class="subNavs"><a href="leave-user-status.php">Leave Status</a></div>
        </div>
        <div class="welcome">
        <div><h2>Welcome <?php echo $name ?></h2> </div>
         <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
            
        </div>
    </div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="user_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="u_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="task-list.php">Task List</a></div>
        <div class="dropbtn"><a href="leave.php">Request Leave</a></div>
        <div class="dropbtn"><a href="leave-user-status.php">Leave Status</a></div>
    </div>
</div>
        
        <div class="leave-form">
            <h4 style="color:red; "><?php echo $mspg ?></h4>
            <div class="heading"><div class="sub-div"><p align="center">Request-Leave</p></div></div>
            <form action="" class="main-form" name="leave_req_form" id="leave_req_form" onSubmit="return checking();">
            <input type="hidden" name="mode" value="1">
                <div class="field"><input type="text" placeholder="Username" class="leave-fields" value="<?php echo $name ?>"></div>
                <div class="field">
                    <select class="leave-fields" name="leave_id" id="leave_id">
                            <option value="">Select Your Leave</option>
                        <?php while($row1=mysqli_fetch_array($leave)){?>
                            <option value="<?php echo $row1['leave_id'] ?>"><?php echo $row1['leave_type'] ?></option>
                            <?php } ?>
                    </select>
                </div>
                <div class="field"><label class="labels">Start Date</label><div class="gap"></div><input type="date" class="leave-fields" name="leave_start_date" id="leave_start_date" min="<?php echo date("Y-m-d") ?>"></div>
                <div class="field"><label class="labels">End Date</label><div class="gap"></div><input type="date" class="leave-fields" name="leave_end_date" id="leave_end_date" min="<?php echo date("Y-m-d") ?>"></div>
                <div class="field">
                    <fieldset class="text-field">
                        <legend>:Reason:</legend>
                        <textarea name="reason" rows="4" cols="20" class="text-area" name="reason" id="reason"></textarea>
                    </fieldset>
                </div>
                <div class="field"><input type="submit" class="submit-btn"></div>
            </form>
        </div>
        <br><br>
        <script>
            function show()
            {
                console.log("!!!");
                document.getElementById('dropLinks').style.visibility="visible";
            }
            function hide()
            {
                document.getElementById('dropLinks').style.visibility="hidden"; 
            }
        </script>
    </body>
</html>