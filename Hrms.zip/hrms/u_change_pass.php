<?php 
    include("conn.php");
    session_start();
    $userid=$_SESSION["user_id"];
    $name=$_SESSION['name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name) || empty($userid))
    {
       @header("Location: index.php");
       exit();
    }
    if(!empty($_REQUEST['msg']))
    {  
      $mspg = $_REQUEST['msg'];  
    } 
else
    {   
      $mspg  = ""; 
    }     
    $result = mysqli_query($conn, "SELECT * FROM `staff_registration_master` WHERE `user_id` = '$userid'");
    $row=mysqli_fetch_array($result);
    $pass = $row['password'];
    if(!empty($_REQUEST['mode']))
    {
        $newpass = $_REQUEST['change_pass'];
        if($newpass!== $pass)
        {
            mysqli_query($conn, "UPDATE `staff_registration_master` SET `password` = '$newpass' WHERE `user_id` = '$userid'");
            $mspg = "Password Changed Successfully!";
            @header("Location: u_change_pass.php?msg=Password Changed Successfully!");
            exit();
        }
        else
        {
            $mspg = "Please Give New Password";
            @header("Location: u_change_pass.php?msg=Please Give New Password!");
            exit();
        }
 
    }
    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="s_change_pass.css">
    <link rel="stylesheet" href="user_dashboard.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Staff Change Password</title>
</head>
<body>
<div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
        <div class="nav">
            <div class="subNavs"><a href="user_dashboard.php">Home</a></div>
            <div class="subNavs"><a href="u_change_pass.php">Change Password</a></div>
            <div class="subNavs"><a href="task-list.php">Task List</a></div>
            <div class="subNavs"><a href="leave.php">Request Leave</a></div>
            <div class="subNavs"><a href="leave-user-status.php">Leave Status</a></div>
        </div>
    <div class="welcome">
        <div><h2>Welcome <?php echo $name ?></h2> </div>
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>  
    </div>    
</div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="user_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="u_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="task-list.php">Task List</a></div>
        <div class="dropbtn"><a href="leave.php">Request Leave</a></div>
        <div class="dropbtn"><a href="leave-user-status.php">Leave Status</a></div>
    </div>
</div>
<div class="field">
            <div class="subfield">
                <form action="" class="field-form" name="changeform" id="changeform" method="post" onSubmit="return passchecking();">
                <input type="hidden" name="mode" value="1" />
                    <div><p align="center">Change Password</p></div>
                    <div class="Inputs"><label>New Password:</label>
                    <input type="text" class="inputField" name="change_pass" id="change_pass" ></div>
                    <div class="sub-btn"><input type="submit"></div>
                    <div><p align="center"><?php echo $mspg;?></p></div> 
                </form>
            </div>
       </div>

</body>
<script src="s_change_pass.js"></script>
 </html>       