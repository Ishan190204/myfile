<?php
    //To do admin check
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include("title.php"); ?>
        <link rel="stylesheet" href="style.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>

        

        <div class="container">
            <div style="height: 8px;"></div>
            <div class="tableDiv">
                <h2>Timetables</h2>
                <?php
                    $query = "SELECT * FROM `room_master`";
                    $resRooms = mysqli_query($conn, $query);
                    while($room = mysqli_fetch_array($resRooms))
                    {
                ?>
                        <div style="margin-top: 16px;">
                            <h3><?php echo $room['room_name']; ?></h3>
                            <table class="timetable" width="100%">
                                <thead>
                                    <tr>
                                        <th>Time Span</th>
                                        <?php
                                            $query = "SELECT * FROM `day_master`";
                                            $resDays = mysqli_query($conn, $query);
                                            $dayColumns = [];
                                            while($day = mysqli_fetch_array($resDays))
                                            {
                                                $dayName = $day['day_name'];
                                                $dayColumns[] = "MAX(CASE WHEN dm.day_name = '$dayName' THEN sm.slot_name ELSE \"\" END) AS `$dayName`";
                                        ?>
                                                <th><?php echo $day['day_name']; ?></th>
                                        <?php
                                            }
                                            $dayColumnsSQL = implode(", ", $dayColumns);
                                            $query = "SELECT
                                                          CONCAT(DATE_FORMAT(tm.`start_time`, '%h:%i %p'), ' - ', DATE_FORMAT(tm.`end_time`, '%h:%i %p')) AS time_span,
                                                        $dayColumnsSQL
                                                      FROM 
                                                          `slot_master` sm
                                                      JOIN 
                                                          `day_master` dm ON sm.`day_id` = dm.`day_id`
                                                      JOIN 
                                                          `time_master` tm ON sm.`time_id` = tm.`time_id`
                                                      WHERE
                                                          sm.`room_id` = '".$room['room_id']."'
                                                      GROUP BY 
                                                          time_span
                                                      ORDER BY 
                                                          tm.`start_time`";
                                            $res = mysqli_query($conn, $query);
                                        ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        while($row = mysqli_fetch_array($res))
                                        {
                                    ?>
                                            <tr>
                                                <td width="256px"><?php echo $row['time_span']; ?></td>
                                                <?php
                                                    mysqli_data_seek($resDays, 0);
                                                    while($day = mysqli_fetch_array($resDays))
                                                    {
                                                ?>
                                                        <td><?php echo $row[$day['day_name']]; ?></td>
                                                <?php
                                                    }
                                                ?>
                                            </tr>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                <?php
                    }
                ?>
            </div>
        </div>
        <script src="time_home.js"></script>
    </body>
</html>