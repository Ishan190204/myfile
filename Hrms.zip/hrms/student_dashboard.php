<?php 
    include("conn.php");
    session_start();
    $sid=$_SESSION["student_id"] ;
    $sname=$_SESSION['student_name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($sname) || empty($sid))
    {
       @header("Location: index.php");
       exit();
    }
    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="user_dashboard.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Student Dashboard</title>
</head>
<body>
<div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
        <div class="nav">
            <div class="subNavs"><a href="student_dashboard.php">Home</a></div>
            <div class="subNavs"><a href="s_change_pass.php">Change Password</a></div>
            <div class="subNavs"><a href="s_timetable.php">Time table</a></div>
            <div class="subNavs"><a href="subject_list.php">Subject List</a></div>
        </div>
        <div class="welcome">
        <div><h2>Welcome <?php echo $sname ?></h2> </div>
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
        </div>
</div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="student_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="s_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="s_timetable.php">Timetable</a></div>
        <div class="dropbtn"><a href="subject_list.php">Subject List</a></div>
    </div>
</div>
<script>
    function show()
    {
        console.log("!!!");
        document.getElementById('dropLinks').style.visibility="visible";
    }
    function hide()
    {
        document.getElementById('dropLinks').style.visibility="hidden"; 
    }
</script>
</body>
 </html>       