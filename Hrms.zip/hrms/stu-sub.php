<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    } 
    if(empty($name1))
    {
      @header("Location: index.php");
      exit();
    }
        $cls_qry=mysqli_query($conn," SELECT * from `class_master` where `status`='Active' ");
        $stu_qry=mysqli_query($conn," SELECT * from `student_master` where `status`='Active' ");
        $sub_qry=mysqli_query($conn," SELECT * from `subject_master` where `status`='Active' ");
        $tch_qry=mysqli_query($conn," SELECT * from `staff_registration_master` inner join `teacher_subject_map` on `staff_registration_master`.`user_id`=`teacher_subject_map`.`teacher_id`  where `user_type`='Te' and `user_status`='Yes' ");
        

      if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
      else
        {   
          $mspg  = ""; 
        } 
        if(!empty($_REQUEST['ad']))
        {  
          $st_id=$_SESSION['stuid'];
          $cl_id=$_SESSION['clsid'];
          $sb_id=$_SESSION['subjid'];
          $st=mysqli_query($conn,"SELECT * from `student_master` where `student_id`='$st_id'");
          $st_ar=mysqli_fetch_array($st);
          $cl=mysqli_query($conn,"SELECT * from `class_master` where `class_id`='$cl_id'");
          $cl_ar=mysqli_fetch_array($cl);
          $sub_qry=mysqli_query($conn," SELECT * from `subject_master` where `status`='Active' and `subject_id` not in(SELECT `subject_id` from `student_subject` where `stud_id`='$st_id' and `class_id`='$cl_id' and `status`='Active' )");
          $dt_qry=mysqli_query($conn,"SELECT `admission_date` from `student_master` where `student_id`='$st_id' ");
          $dt_row=mysqli_fetch_array($dt_qry);
          $ad_dt=$dt_row['admission_date'];
        } 
     
        

    
        
    if(!empty($_REQUEST['mode']) && !empty($_REQUEST['add']))
    {  
        if(!empty($_REQUEST['student_id'])){
            $student_id=$_REQUEST['student_id'];
        }else{
            $student_id=$_SESSION['stuid'];
        }
        if(!empty($_REQUEST['class_id'])){
            $class_id=$_REQUEST['class_id'];
        }else{
            $class_id=$_SESSION['clsid'];
        }
        $teacher_id=$_REQUEST['teacher_id'];
        
        $subject_id=$_REQUEST['subject_id'];
   
        $date=$_REQUEST['date'];
         
        $fet=mysqli_query($conn," SELECT count(*) as `cnt` from `student_subject` where `stud_id`='$student_id' and `class_id`='$class_id' and `subject_id`='$subject_id' and `status`='Active'");
        $ar=mysqli_fetch_array($fet);
        $fet_tc=mysqli_query($conn," SELECT count(*) as `cnt1` from `teacher_student_map` where `student_id`='$student_id' and `class_id`='$class_id' and `subject_id`='$subject_id' and `teacher_id`='$teacher_id' and `status`='Active' ");
        $ar1=mysqli_fetch_array($fet_tc);
        if($ar['cnt']===0 && $ar1['cnt1']===0)
        {
            $sql_stsub="INSERT INTO `student_subject` SET 
                        `stud_id`= '$student_id',
                        `class_id`= '$class_id',
                        `subject_id`= '$subject_id',
                        `date`='$date' ,
                        `sub_end_date`='0000-00-00',
                        `status`='Active' ";  
            $stu_sub=mysqli_query($conn, $sql_stsub);
            $sql_st_tc="INSERT INTO `teacher_student_map` SET 
                            `student_id`= '$student_id',
                            `class_id`= '$class_id',
                            `subject_id`= '$subject_id',
                            `teacher_id`='$teacher_id', 
                            `status`='Active',
                            `date`='$date'  ";  
            $stu_Tch=mysqli_query($conn, $sql_st_tc);
            
            if($stu_sub  && $stu_Tch)
                {
                    $_SESSION['stuid']=$student_id;
                    $_SESSION['clsid']=$class_id;
                    $_SESSION['subjid']=$subject_id;

                @header("Location: stu-sub.php?msg=Added&ad=1");
                    exit(); 

                }
        }
        else{
            @header("Location: stu-sub.php?msg=Already allocated the subject");
                    exit(); 

        }
    }
    if(!empty($_REQUEST['mode']) && !empty($_REQUEST['submit']))
    {  
         
        if(!empty($_REQUEST['student_id'])){
            $student_id=$_REQUEST['student_id'];
        }else{
            $student_id=$_SESSION['stuid'];
        }
        if(!empty($_REQUEST['class_id'])){
            $class_id=$_REQUEST['class_id'];
        }else{
            $class_id=$_SESSION['clsid'];
        }
            $subject_id=$_REQUEST['subject_id'];
            $teacher_id=$_REQUEST['teacher_id'];
            $date=$_REQUEST['date'];
        
        
            $fet=mysqli_query($conn," SELECT count(*) as `cnt` from `student_subject` where `stud_id`='$student_id' and `class_id`='$class_id' and `subject_id`='$subject_id' and `status`='Active' ");
            $ar=mysqli_fetch_array($fet);
            $fet_tc=mysqli_query($conn," SELECT count(*) as `cnt1` from `teacher_student_map` where `student_id`='$student_id' and `class_id`='$class_id' and `subject_id`='$subject_id' and `teacher_id`='$teacher_id' and `status`='Active' ");
            $ar1=mysqli_fetch_array($fet_tc);
            if($ar['cnt']== 0 && $ar1['cnt1']==0)
            {
                $sql_stsub="INSERT INTO `student_subject` SET 
                            `stud_id`= '$student_id',
                            `class_id`= '$class_id',
                            `subject_id`= '$subject_id',
                            `date`='$date',
                            `sub_end_date`='0000-00-00',
                            `status`='Active' ";  
                $stu_sub=mysqli_query($conn, $sql_stsub);
                
                $sql_st_tc="INSERT INTO `teacher_student_map` SET 
                            `student_id`= '$student_id',
                            `class_id`= '$class_id',
                            `subject_id`= '$subject_id',
                            `teacher_id`='$teacher_id' ,
                            `status`='Active',
                            `date`='$date'  ";  
                $stu_Tch=mysqli_query($conn, $sql_st_tc);
                
                if($stu_sub && $stu_Tch)
                    {
                    @header("Location: stu-sub.php?msg=Inserted");
                        exit(); 

                    }
            }
            else{
                @header("Location: stu-sub.php?msg=Already allocated the subject");
                        exit(); 

            }
    }

?> 

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Student-Subject-Teacher</title>
        <link rel="stylesheet" href="stu-sub.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>



         <br><br>
        <div><p align="center" style="color:red;font-weight:bold;"><?php echo $mspg; ?></p></div>
        <br><br>
        <div class="superContainer">
            <div class="container">
                <div class="heading">Student-Subject-Teacher<br>Form</div>
                <form class="form" enctype="multipart/form-data" method="post" name="task_assn_form" id="task_assn_form" onSubmit="return checking();">
                    <input type="hidden" name="mode" value="1">
                    <!-- class  -->
                    <div class="inputContainer" <?php if(empty($cl_id)) { ?> style="display:none" <?php } ?>>
                    <input type="hidden" id="cl_id" value="<?php if(!empty($cl_id)) { echo $cl_id; }?>">
                        <label>Class</label><input type="text" class="inputField"  name="class_id1" id="class_id1" value="<?php if(!empty($cl_id)){ echo $cl_ar['class_name'] ;} ?>">
                    </div>
                    
                    <div class="inputContainer" <?php if(!empty($_REQUEST['ad'])){ ?> style="display:none" <?php }  ?>>
                        <label for="class_id">Class</label>
                        <select class="inputSelect" name="class_id" id="class_id"  onchange="class_check(this.value)">
                            <option value="">Select Class</option>
                            <?php  while($row=mysqli_fetch_array($cls_qry)){ ?>
                            <option value="<?php echo $row['class_id'] ?>" ><?php echo $row['class_name'] ;?></option>
                                    <?php } ?>
                        </select>
                    </div>
                    <!-- student  -->
                    <div class="inputContainer" <?php if(empty($st_id)) { ?> style="display:none" <?php } ?>>
                        <label>Student Name</label><input type="text" class="inputField"  name="st_id1" id="st_id1" value="<?php if(!empty($st_id)){ echo $st_ar['student_name'] ;} ?>">
                    </div>
                    <div class="inputContainer" <?php if(!empty($_REQUEST['ad'])){ ?> style="display:none" <?php }  ?>>
                        <label for="student_id">Student</label>
                        <select class="inputSelect" name="student_id" id="student_id" onchange="date_chk(this.value)">
                            <option value="">Select Student</option>
                            
                            <?php while($ar=mysqli_fetch_array($stu_qry)){ ?>
                            <option value="<?php echo $ar['student_id'] ?>" data-value="<?php echo $ar['student_class'] ?>" data-date="<?php echo $ar['admission_date'] ?>" data-subb="<?php echo $ar['student_name'] ?>"><?php echo $ar['student_name'] ;?></option>
                                        <?php } ?>
                            
                        </select>
                    </div>
                     <!-- subject  -->

                    <div class="inputContainer">
                        <label for="subject_id">Subject</label>
                        <select class="inputSelect" name="subject_id" id="subject_id" onchange="teac_chk(this.value)" >
                            <option value="">Subject</option>
                            <?php  while($row3=mysqli_fetch_array($sub_qry)){ ?>
                            <option value="<?php echo $row3['subject_id'] ?>" ><?php echo $row3['subject_name'] ;?></option>
                                    <?php } ?>
                        </select>
                    </div> 
                    <div class="inputContainer">
                        <label for="teacher_id">Teacher</label>
                        <select class="inputSelect" name="teacher_id" id="teacher_id" >
                            <option value="">Teacher</option>
                            <?php  while($row4=mysqli_fetch_array($tch_qry)){ ?>
                            <option value="<?php echo $row4['teacher_id'] ?>" data-value="<?php echo $row4['subject_id'] ?>" data-cid="<?php echo $row4['class_id'] ?>" data-subb="<?php echo $row4['name'] ?>" ><?php echo $row4['name'] ;?></option>
                                    <?php } ?>
                        </select>
                    </div> 
                    <div class="inputContainer" >
                        <label>Date</label><input type="date" class="inputField" placeholder="Date" name="date" id="date" value="<?php echo date("Y-m-d"); ?>" max="<?php echo date("Y-m-d"); ?>" <?php if(!empty($ad_dt)){ ?> min=<?php echo $ad_dt ?> <?php } ?>>
                    </div>
                    <input type="submit" name="add" value="Add" class="assign-btn">                   
                    <div class="gap"></div> 
                <input type="submit" class="assign-btn" name="submit" value="Submit" >
                </form>
            </div>
        </div>
        <script src="stu-sub.js"></script>
        <script>
            
            </script>
    </body>
</html>