<?php 
    include("conn.php");
    session_start();
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    
    if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
    else
        {   
          $mspg  = ""; 
        } 
        /* for login validation*/ 
    $fetch_staff1 ="SELECT `user_name`,`password`,`user_id`,`name`,`user_type` from `staff_registration_master` where `user_type`!='Ad' and `user_status`='Yes' order by `user_id`"  ;
    $user_descr1=mysqli_query($conn,$fetch_staff1);
    
/* for register fetch from user description*/
    $fetch_userdesc ="SELECT `user_description_name` from `user_description` order by `user_description_id`"  ;
    $user_desc=mysqli_query($conn,$fetch_userdesc);
    $fetch_usertype="SELECT `user_description_name`,`user_description_type` from `user_description` order by `user_description_id`";
    $user_desctype=mysqli_query($conn,$fetch_usertype);
    if(!empty($_REQUEST['mode']))
    {  
        $res_username = $_REQUEST['username'];
        $res_Password = $_REQUEST['password1'];
        
        $flag='0';
        while($arr=mysqli_fetch_array($user_descr1)){
            if($res_username===$arr['user_name'] and $res_Password===$arr['password']){
                $flag='1';
                $res_userid= $arr['user_id'];
                $res_name=$arr['name'];
                $res_type=$arr['user_type'];
        } 
      }
      if($flag==='1' and isset($res_userid) and $res_type!=='Te'){
        $_SESSION["user_id"] = $res_userid;
        $_SESSION['name']=$res_name;
        @header("Location:user_dashboard.php?msg= login Successfull");
        exit();  
      }
      else if($flag==='1' and isset($res_userid) and $res_type==='Te'){
        $_SESSION["user_id"] = $res_userid;
        $_SESSION['name']=$res_name;
        @header("Location:teacher_dashboard.php?msg= login Successfull");
        exit();  
      }

      else{
        @header("Location:log-reg.php?msg=Please enter valid username or password !");
        exit(); 
      }
    }
    if(!empty($_REQUEST['register']))
    {  
        $res_username = $_REQUEST['user_name'];
        $res_name = $_REQUEST['name'];
        $res_Password = $_REQUEST['password'];
        $res_userdesc = $_REQUEST['user_description_name'];
        $res_usertype = $_REQUEST['user_description_type'];
        $res_phone = $_REQUEST['phone_no'];
        $res_name1=ucwords($res_name);
        
      $sql_con="INSERT INTO `staff_registration_master` SET 
                `name`= '$res_name1',
                `user_name`= '$res_username',
                `password`= '$res_Password',
                `user_description`= '$res_userdesc',
                `user_type`= '$res_usertype',
                `phone_no`= '$res_phone',
                `user_status`='No' ";  
      $res=mysqli_query($conn, $sql_con);
      
      if($res)
        {
          @header("Location: log-reg.php?msg=Successfull registered");
		      exit();  		
        }
    }

?> 
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login/Registration</title>
        <link rel="stylesheet" href="log-reg.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    </head>
    <body>
        <div class="navbar">
            <div class="dashboard">
                <div class="dashlogo"><img src="images/NEW_LOGO__1___1_.png" class="logo"></div>
                <div class="dash">Shikhshaneer</div>
            </div>
            <div class="nav">
                <div class="subNavs"><a href="index.php">Home</a></div>
                <div class="subNavs"><a href="log-reg.php">Login/ Register</a></div>
                <div class="subNavs"><a href="student-log-reg.php">Student Login/Register</a></div>
            </div>   
        </div>
        <div class="drops">
            <img src="images/side-lines.svg" height="35" width="30" onclick="show()">
        </div> 
        <div id="dropLinks">
            <div class="closebtn">
                <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
            </div> 
            <div class="dropdown">
                <div class="dropbtn"><a href="index.php">Home</a></div>
                <div class="dropbtn"><a href="log-reg.php">Login/ Register</a></div>
                <div class="dropbtn"><a href="student-log-reg.php">Student Login/Register</a></div>
            </div>
        </div> 
        <div style="height:100px;"></div>
        <div class="wrapper">
            <div class="card-switch">
                <label class="switch">
                   <input type="checkbox" class="toggle">
                   <span class="slider"></span>
                   <span class="card-side"></span>
                   <div class="flip-card__inner">
                      <div class="flip-card__front">
                         <div class="title">Log in</div>
                         
                         <form class="flip-card__form" action="" name="loginform" id="loginform" method="post" onSubmit="return loginchecking();">
                            <input type="hidden" name="mode" value="1" />
                            
                            <input class="flip-card__input" name="username"  id="username" placeholder="Username" type="text" autofocus >
                            <input class="flip-card__input" name="password1" id="password1" placeholder="Password" type="password">
                            <button class="flip-card__btn">Login</button>
                            
                            <table border="0" align="center"  >
                                <tr>
                                    <td style="color:#FF0000;">&nbsp;<a href="adminLogin.php" style="font-weight: bold;font-size: 20px;font-family: Arial, Helvetica, sans-serif;color: #033869;">Admin login</a></td>   			 
                                </tr>
                                
                            </table>
                            <h4 align="center"style="color:red;"><?php echo $mspg ?></h4>
                         </form>
                         
                      </div>

                      <div class="flip-card__back">
                         <div class="title">Register</div>
                         <form class="flip-card__form" action="" name="staff_register_form" id="staff_register_form" method="post" onSubmit="return checking();">
                         <input type="hidden" name="register" value="1" />
                            <input class="flip-card__input" placeholder="Name*" name="name" id="name" type="text" style="text-transform: capitalize;" >
                            <input class="flip-card__input" placeholder="Username*" name="user_name" id="user_name" type="text">
                            <input class="flip-card__input" placeholder="Password*" type="password" name="password" id="password">
                            <select class="flip-card__select" name="user_description_name" id="user_description_name" onchange="userdesc_chk(this.value)">
                                <option value="">User-Description*</option>
                                <?php while($user_desc_arr=mysqli_fetch_array($user_desc)){ ?>
                                <option value="<?php echo $user_desc_arr['user_description_name'] ?>"><?php echo $user_desc_arr['user_description_name'] ?></option>
                                    <?php } ?>
                            </select>
                            <select class="flip-card__select" name="user_description_type" id="user_description_type">
                                <option value="">User-Type</option>
                                <?php while($user_desc_arr1=mysqli_fetch_array($user_desctype)){ ?>
                                <option value="<?php echo $user_desc_arr1['user_description_type'] ?>" data-value="<?php echo $user_desc_arr1['user_description_name'] ?>" data-subb="<?php echo $user_desc_arr1['user_description_type']?>" ><?php echo $user_desc_arr1['user_description_type'] ?></option>
                                    <?php } ?>
                            </select>
                            <input type="number" class="flip-card__input" placeholder="Phone Number" name="phone_no" id="phone_no">
                            <button class="flip-card__btn">Register</button>
                            
                         </form>
                         
                      </div>
                   </div>
                </label>
            </div>
       </div>
        <script src="log-reg.js"></script>
    </body>
</html>