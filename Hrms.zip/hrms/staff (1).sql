-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2024 at 02:39 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `staff`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `a_id` int(255) NOT NULL,
  `student_id` int(255) NOT NULL,
  `teacher_id` int(200) NOT NULL,
  `class_id` int(200) NOT NULL,
  `subject_id` int(200) NOT NULL,
  `present` varchar(50) NOT NULL,
  `absent` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `remarks` varchar(5000) NOT NULL,
  `topic_covered` varchar(5000) NOT NULL,
  `month` varchar(50) NOT NULL,
  `year` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`a_id`, `student_id`, `teacher_id`, `class_id`, `subject_id`, `present`, `absent`, `date`, `remarks`, `topic_covered`, `month`, `year`) VALUES
(45, 2, 18, 4, 1, 'Y', 'N', '2024-08-06', 'sou', 'ses', 'August', '2024-'),
(46, 3, 18, 4, 1, 'Y', 'N', '2024-08-06', 'ram', 'ses', 'August', '2024-'),
(47, 2, 18, 4, 1, 'N', 'Y', '2024-08-07', 'sou', 'ses', 'August', '2024'),
(49, 2, 18, 4, 1, 'Y', 'N', '2024-08-08', 'ok', 'c++', 'August', '2024'),
(53, 3, 20, 1, 1, 'Y', 'N', '2024-08-01', 'good', 'sob complete', 'August', '2024'),
(63, 3, 20, 1, 1, 'Y', 'N', '2024-08-07', '', '', 'August', '2024'),
(64, 2, 20, 1, 1, 'N', 'Y', '2024-08-07', '', '', 'August', '2024'),
(65, 5, 20, 1, 1, 'Y', 'N', '2024-08-07', '', '', 'August', '2024'),
(66, 3, 20, 1, 1, 'Y', 'N', '2024-07-30', '', '', 'July', '2024'),
(67, 2, 20, 1, 1, 'Y', 'N', '2024-07-30', '', '', 'July', '2024'),
(68, 5, 20, 1, 1, 'Y', 'N', '2024-07-30', '', '', 'July', '2024'),
(69, 3, 20, 1, 1, 'Y', 'N', '2024-06-30', '', '', 'June', '2024'),
(70, 2, 20, 1, 1, 'Y', 'N', '2024-06-30', '', '', 'June', '2024'),
(71, 5, 20, 1, 1, 'N', 'Y', '2024-06-30', '', '', 'June', '2024'),
(72, 3, 20, 1, 3, 'Y', 'N', '2024-06-10', '', '', 'June', '2024'),
(73, 3, 20, 1, 3, 'Y', 'N', '2024-07-10', '', '', 'July', '2024'),
(74, 3, 20, 1, 1, 'N', 'Y', '2024-08-08', 'bad', 'sesh', 'August', '2024'),
(75, 2, 20, 1, 1, 'Y', 'N', '2024-08-08', 'good', 'sob', 'August', '2024'),
(76, 5, 20, 1, 1, 'N', 'Y', '2024-08-08', 'bad', 'sesh', 'August', '2024'),
(89, 3, 20, 1, 1, 'N', 'Y', '2024-08-10', '', '', 'August', '2024'),
(90, 2, 20, 1, 1, 'Y', 'N', '2024-08-10', '', '', 'August', '2024'),
(91, 5, 20, 1, 1, 'Y', 'N', '2024-07-29', '', '', 'July', '2024'),
(92, 6, 21, 5, 1, 'Y', 'N', '2024-08-06', '', '', 'August', '2024'),
(93, 3, 18, 4, 1, 'N', 'Y', '2024-08-11', '', '', 'August', '2024'),
(94, 5, 18, 4, 1, 'Y', 'N', '2024-08-11', '', '', 'August', '2024');

-- --------------------------------------------------------

--
-- Table structure for table `class_master`
--

CREATE TABLE `class_master` (
  `class_id` int(255) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_master`
--

INSERT INTO `class_master` (`class_id`, `class_name`, `status`) VALUES
(1, 'Class-1', 'Active'),
(2, 'Class-2', 'Active'),
(3, 'Class-3', 'Active'),
(4, 'Class-4', 'Active'),
(5, 'Class-5', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `expense_master`
--

CREATE TABLE `expense_master` (
  `expense_id` int(255) NOT NULL,
  `expense_category` varchar(50) NOT NULL,
  `user_id` int(255) NOT NULL,
  `user_description` varchar(255) NOT NULL,
  `expense_amount` bigint(100) NOT NULL,
  `expense_month` int(25) NOT NULL,
  `expense_date` date NOT NULL,
  `mode_of_payment` varchar(25) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `payment_type` varchar(25) NOT NULL,
  `amount_left` bigint(100) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense_master`
--

INSERT INTO `expense_master` (`expense_id`, `expense_category`, `user_id`, `user_description`, `expense_amount`, `expense_month`, `expense_date`, `mode_of_payment`, `transaction_id`, `payment_type`, `amount_left`, `note`) VALUES
(2, 'staff', 11, 'Admin', 563, 2024, '2024-07-24', 'cash', '', 'Fully Paid', 0, ''),
(3, 'staff', 13, 'Manager', 5000, 2024, '2024-07-27', 'cash', 'NA', 'Fully Paid', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `leave_master`
--

CREATE TABLE `leave_master` (
  `leave_id` int(255) NOT NULL,
  `leave_type` varchar(100) NOT NULL,
  `max_leave` varchar(100) NOT NULL,
  `no_of_leaves` int(255) NOT NULL,
  `carry_forward` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_master`
--

INSERT INTO `leave_master` (`leave_id`, `leave_type`, `max_leave`, `no_of_leaves`, `carry_forward`) VALUES
(1, 'Medical Leave', '40', 10, 'Y'),
(2, 'Occasional Leave', '40', 10, 'Y'),
(3, 'Seasonal Leave', '40', 10, 'Y'),
(4, 'Half Day Leave', '40', 10, 'Y'),
(5, 'Medical Leave', '10', 10, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `leave_request`
--

CREATE TABLE `leave_request` (
  `leave_request_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `leave_id` int(255) NOT NULL,
  `leave_start_date` date NOT NULL,
  `leave_end_date` date NOT NULL,
  `duration` int(200) NOT NULL,
  `reason` varchar(2000) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_request`
--

INSERT INTO `leave_request` (`leave_request_id`, `user_id`, `leave_id`, `leave_start_date`, `leave_end_date`, `duration`, `reason`, `status`) VALUES
(3, 13, 0, '2024-07-26', '2024-07-31', 5, 'fever', ''),
(4, 13, 2, '2024-07-26', '2024-07-27', 1, 'ichha hoeche', 'Approved'),
(5, 13, 1, '2024-07-27', '2024-07-31', 4, 'headache', 'Rejected'),
(6, 13, 2, '2024-07-29', '2024-08-01', 3, 'bye bye', 'Rejected'),
(7, 14, 1, '2024-07-28', '2024-07-30', 2, 'headache', 'Approved'),
(8, 14, 3, '2024-07-30', '2024-08-01', 2, 'travel', 'Approved'),
(9, 13, 1, '2024-07-27', '2024-07-29', 2, '', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `staff_leave_mapping`
--

CREATE TABLE `staff_leave_mapping` (
  `staff_leave_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `leave_id` int(255) NOT NULL,
  `total_leave_balance` int(200) NOT NULL,
  `left_leave_balance` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_leave_mapping`
--

INSERT INTO `staff_leave_mapping` (`staff_leave_id`, `user_id`, `leave_id`, `total_leave_balance`, `left_leave_balance`) VALUES
(2, 13, 2, 10, -1),
(3, 13, 1, 10, 4),
(4, 14, 1, 10, 8),
(5, 14, 3, 10, 8);

-- --------------------------------------------------------

--
-- Table structure for table `staff_registration_master`
--

CREATE TABLE `staff_registration_master` (
  `user_id` int(200) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_description` varchar(5000) NOT NULL,
  `user_type` varchar(12) NOT NULL,
  `phone_no` bigint(10) NOT NULL,
  `user_status` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_registration_master`
--

INSERT INTO `staff_registration_master` (`user_id`, `user_name`, `name`, `password`, `user_description`, `user_type`, `phone_no`, `user_status`) VALUES
(11, 'subh', 'Subham Patra ', 'subh123', 'Admin', 'Ad', 1478523690, 'Yes'),
(12, 'ishan', 'Ishan Bhowmick', 'ish123', 'Admin', 'Ad', 7890777456, 'Yes'),
(13, 'rohit', 'Rohit Saha', 'ro123', 'Manager', 'Ma', 7980453888, 'Yes'),
(14, 'sattwik', 'Sattwik Panja', 'sat123', 'Co-ordinator', 'Co', 8798822200, 'Yes'),
(18, 'Kushal12', 'Kushal', 'Kush123', 'Teacher', 'Te', 9311090110, 'Yes'),
(20, 'Tri123', 'Trideep', 'Tri123', 'Teacher', 'Te', 9876543210, 'Yes'),
(21, 'pri', 'Priya', 'pri', 'Teacher', 'Te', 1234512345, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `student_master`
--

CREATE TABLE `student_master` (
  `student_id` int(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `student_class` int(100) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `board` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `age` int(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `admission_date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_master`
--

INSERT INTO `student_master` (`student_id`, `student_name`, `student_class`, `phone`, `address`, `board`, `email`, `age`, `gender`, `admission_date`, `status`, `password`) VALUES
(2, 'Souvik', 2, 1236547890, '', 'CBSE', '', 7, 'male', '2024-07-30', 'Active', '1236547890'),
(3, 'ram', 1, 7980340947, '', 'CBSE', '', 6, 'male', '2024-07-30', 'Active', '7980340947'),
(4, 'rahul', 4, 7980340941, 'BE-1/15,Deshbandhu Nagar,Block-B,1st Floor ,Baguiati', 'CBSE', '', 0, 'male', '2024-08-15', 'Active', '7980340941'),
(5, 'shyam', 1, 7980340947, 'faridabad', 'WBSSE', '', 0, 'Gender', '0000-00-00', 'Active', '7980340947'),
(6, 'deb', 5, 9876543210, '', 'WBSSE', '', 5, 'male', '2024-08-06', 'Active', '9876543210');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `stud_sub_id` int(255) NOT NULL,
  `stud_id` int(100) NOT NULL,
  `subject_id` int(200) NOT NULL,
  `class_id` int(20) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_subject`
--

INSERT INTO `student_subject` (`stud_sub_id`, `stud_id`, `subject_id`, `class_id`, `date`) VALUES
(48, 2, 5, 2, '2024-08-09'),
(56, 3, 1, 1, '2024-08-09'),
(57, 3, 2, 1, '2024-08-09'),
(58, 3, 5, 1, '2024-08-09'),
(59, 3, 3, 1, '2024-08-09'),
(70, 2, 1, 2, '2024-08-09'),
(71, 2, 3, 2, '2024-08-09'),
(72, 4, 1, 4, '2024-08-09'),
(73, 4, 2, 4, '2024-08-09'),
(74, 4, 3, 4, '2024-08-09'),
(75, 4, 4, 4, '2024-08-09'),
(76, 4, 5, 4, '2024-08-09'),
(77, 5, 2, 1, '2024-08-09'),
(78, 5, 1, 1, '2024-08-09'),
(79, 5, 4, 1, '2024-08-09'),
(80, 5, 5, 1, '2024-08-09'),
(81, 2, 4, 1, '2024-08-09'),
(82, 3, 4, 1, '2024-08-09'),
(83, 3, 6, 1, '2024-08-08'),
(84, 3, 0, 1, '2024-08-09'),
(106, 6, 4, 5, '2024-08-11'),
(107, 6, 2, 5, '2024-08-11'),
(109, 6, 1, 5, '2024-08-11'),
(110, 6, 3, 5, '2024-08-11'),
(115, 6, 5, 5, '2024-08-11'),
(116, 6, 6, 5, '2024-08-11');

-- --------------------------------------------------------

--
-- Table structure for table `subject_master`
--

CREATE TABLE `subject_master` (
  `subject_id` int(255) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject_master`
--

INSERT INTO `subject_master` (`subject_id`, `subject_name`, `status`) VALUES
(1, 'Physics', 'Active'),
(2, 'Computer', 'Active'),
(3, 'Maths', 'Active'),
(4, 'Chemistry', 'Active'),
(5, 'Biology', 'Active'),
(6, 'Bengali', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `task_assign`
--

CREATE TABLE `task_assign` (
  `task_id` int(200) NOT NULL,
  `user_type` varchar(200) NOT NULL,
  `user_id` int(200) NOT NULL,
  `task_description` varchar(5000) NOT NULL,
  `task_assign_date` date NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `actual_start_date` date NOT NULL,
  `actual_end_date` date NOT NULL,
  `delay` varchar(200) NOT NULL,
  `priority` varchar(200) NOT NULL,
  `task_status` char(20) NOT NULL,
  `pdf` varchar(255) NOT NULL,
  `status` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task_assign`
--

INSERT INTO `task_assign` (`task_id`, `user_type`, `user_id`, `task_description`, `task_assign_date`, `start_date`, `end_date`, `actual_start_date`, `actual_end_date`, `delay`, `priority`, `task_status`, `pdf`, `status`) VALUES
(30, 'Co', 14, 'Money Management', '2024-07-18', '2024-07-18', '2024-07-24', '2024-07-18', '2024-07-30', '6', '2', 'Completed', '', 'Inactive'),
(31, 'Ma', 13, 'Testing Should be Done', '2024-07-18', '2024-07-19', '2024-07-25', '2024-07-20', '2024-07-25', '0', '1', 'Completed', '11700121005_Subham Patra.pdf', 'Active'),
(32, 'Ad', 11, 'Use Java Script', '2024-07-18', '2024-07-18', '2024-07-21', '2024-07-18', '2024-07-26', '5', '1', 'Assigned', '', 'Active'),
(33, 'Ma', 13, 'Style Management', '2024-07-18', '2024-07-18', '2024-07-25', '2024-07-18', '2024-07-20', '0', '3', 'Completed', '', 'Active'),
(34, 'Ma', 13, 'database', '2024-07-19', '2024-07-20', '2024-07-25', '2024-07-21', '2024-08-01', '7', '1', 'In progress', '', 'Active'),
(35, 'Co', 14, 'data management', '2024-07-20', '2024-07-20', '2024-07-25', '2024-07-20', '2024-07-25', '0', '2', 'In progress', '', 'Active'),
(36, 'Ma', 13, 'design', '2024-07-21', '2024-07-22', '2024-07-25', '2024-07-22', '2024-07-26', '1', '2', 'In progress', '', 'Active'),
(37, 'Co', 14, 'finance dept logical design', '2024-07-22', '2024-07-22', '2024-07-24', '2024-07-22', '2024-07-24', '0', '3', 'Assigned', '', 'Active'),
(38, 'Co', 14, 'database of finance', '2024-07-21', '2024-07-21', '2024-07-21', '2024-07-21', '2024-07-24', '3', '1', 'Assigned', '', 'Active'),
(39, 'Co', 14, 'kaj kor', '2024-09-03', '2024-08-03', '2024-08-12', '2024-08-03', '2024-08-12', '0', '1', 'Assigned', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_student_map`
--

CREATE TABLE `teacher_student_map` (
  `tch_student_id` int(255) NOT NULL,
  `teacher_id` int(100) NOT NULL,
  `student_id` int(200) NOT NULL,
  `subject_id` int(200) NOT NULL,
  `class_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_student_map`
--

INSERT INTO `teacher_student_map` (`tch_student_id`, `teacher_id`, `student_id`, `subject_id`, `class_id`) VALUES
(13, 20, 3, 1, 1),
(14, 20, 3, 3, 1),
(16, 20, 3, 5, 1),
(17, 20, 4, 1, 4),
(18, 20, 4, 3, 4),
(27, 20, 4, 4, 4),
(28, 18, 4, 5, 4),
(30, 18, 5, 2, 1),
(31, 18, 5, 4, 1),
(35, 20, 2, 1, 1),
(36, 20, 5, 1, 1),
(37, 20, 3, 2, 1),
(40, 18, 6, 4, 5),
(41, 18, 6, 2, 5),
(43, 21, 6, 1, 5),
(44, 18, 6, 3, 5),
(49, 18, 6, 5, 5),
(50, 18, 6, 6, 5),
(51, 18, 3, 1, 4),
(52, 18, 5, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subject_map`
--

CREATE TABLE `teacher_subject_map` (
  `ts_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(100) NOT NULL,
  `class_id` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_subject_map`
--

INSERT INTO `teacher_subject_map` (`ts_id`, `teacher_id`, `subject_id`, `class_id`) VALUES
(24, 20, 1, 1),
(25, 20, 2, 1),
(26, 20, 2, 3),
(27, 20, 3, 3),
(28, 20, 3, 4),
(30, 18, 4, 2),
(31, 20, 3, 1),
(32, 20, 5, 1),
(33, 20, 1, 4),
(34, 18, 1, 4),
(35, 18, 2, 4),
(36, 18, 4, 1),
(39, 18, 4, 5),
(40, 18, 1, 3),
(41, 18, 5, 4),
(42, 20, 4, 4),
(43, 21, 1, 5),
(44, 18, 2, 5),
(45, 18, 3, 5),
(47, 21, 5, 5),
(48, 18, 5, 5),
(49, 18, 6, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user_description`
--

CREATE TABLE `user_description` (
  `user_description_id` int(200) NOT NULL,
  `user_description_name` varchar(5000) NOT NULL,
  `user_description_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_description`
--

INSERT INTO `user_description` (`user_description_id`, `user_description_name`, `user_description_type`) VALUES
(10, 'Admin', 'Ad'),
(11, 'Manager', 'Ma'),
(12, 'Co-ordinator', 'Co'),
(13, 'Developer', 'De'),
(18, 'Teacher', 'Te');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `class_master`
--
ALTER TABLE `class_master`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `expense_master`
--
ALTER TABLE `expense_master`
  ADD PRIMARY KEY (`expense_id`);

--
-- Indexes for table `leave_master`
--
ALTER TABLE `leave_master`
  ADD PRIMARY KEY (`leave_id`);

--
-- Indexes for table `leave_request`
--
ALTER TABLE `leave_request`
  ADD PRIMARY KEY (`leave_request_id`),
  ADD KEY `leave_request_ibfk_1` (`leave_id`),
  ADD KEY `leave_request_ibfk_2` (`user_id`);

--
-- Indexes for table `staff_leave_mapping`
--
ALTER TABLE `staff_leave_mapping`
  ADD PRIMARY KEY (`staff_leave_id`),
  ADD KEY `staff_leave_mapping_ibfk_1` (`leave_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `staff_registration_master`
--
ALTER TABLE `staff_registration_master`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `student_master`
--
ALTER TABLE `student_master`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`stud_sub_id`);

--
-- Indexes for table `subject_master`
--
ALTER TABLE `subject_master`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `task_assign`
--
ALTER TABLE `task_assign`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `test` (`user_id`);

--
-- Indexes for table `teacher_student_map`
--
ALTER TABLE `teacher_student_map`
  ADD PRIMARY KEY (`tch_student_id`);

--
-- Indexes for table `teacher_subject_map`
--
ALTER TABLE `teacher_subject_map`
  ADD PRIMARY KEY (`ts_id`);

--
-- Indexes for table `user_description`
--
ALTER TABLE `user_description`
  ADD PRIMARY KEY (`user_description_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `a_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `class_master`
--
ALTER TABLE `class_master`
  MODIFY `class_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `expense_master`
--
ALTER TABLE `expense_master`
  MODIFY `expense_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leave_master`
--
ALTER TABLE `leave_master`
  MODIFY `leave_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `leave_request`
--
ALTER TABLE `leave_request`
  MODIFY `leave_request_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `staff_leave_mapping`
--
ALTER TABLE `staff_leave_mapping`
  MODIFY `staff_leave_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `staff_registration_master`
--
ALTER TABLE `staff_registration_master`
  MODIFY `user_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `student_master`
--
ALTER TABLE `student_master`
  MODIFY `student_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `student_subject`
--
ALTER TABLE `student_subject`
  MODIFY `stud_sub_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `subject_master`
--
ALTER TABLE `subject_master`
  MODIFY `subject_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `task_assign`
--
ALTER TABLE `task_assign`
  MODIFY `task_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `teacher_student_map`
--
ALTER TABLE `teacher_student_map`
  MODIFY `tch_student_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `teacher_subject_map`
--
ALTER TABLE `teacher_subject_map`
  MODIFY `ts_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `user_description`
--
ALTER TABLE `user_description`
  MODIFY `user_description_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `staff_leave_mapping`
--
ALTER TABLE `staff_leave_mapping`
  ADD CONSTRAINT `staff_leave_mapping_ibfk_1` FOREIGN KEY (`leave_id`) REFERENCES `leave_master` (`leave_id`),
  ADD CONSTRAINT `staff_leave_mapping_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `staff_registration_master` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
