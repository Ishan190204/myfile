<?php 
    include("conn.php");
    session_start();
    $name=$_SESSION["name"];
    $userid=$_SESSION["user_id"];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name) || empty($userid))
    {
       @header("Location: index.php");
       exit();
    }
    $leave_table1=mysqli_query($conn,"SELECT * FROM `leave_request`  INNER JOIN `leave_master` on `leave_request`.`leave_id`= `leave_master`.`leave_id` where `user_id`='$userid' order by `leave_start_date`");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Status</title>
    <link rel="stylesheet" href="leave-user-status.css">
    <link rel="stylesheet" href="leave.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
<div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
</div>
        <div class="nav">
                <div class="subNavs"><a href="user_dashboard.php">Home</a></div>
                <div class="subNavs"><a href="u_change_pass.php">Change Password</a></div>
                <div class="subNavs"><a href="task-list.php">Task List</a></div>
                <div class="subNavs"><a href="leave.php">Request Leave</a></div>
                <div class="subNavs"><a href="leave-user-status.php">Leave Status</a></div>
           
        </div>
        <div class="welcome">
        <div><h2>Welcome <?php echo $name ?></h2></div> 
         <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
            
        </div>
        
        </div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="user_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="u_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="task-list.php">Task List</a></div>
        <div class="dropbtn"><a href="leave.php">Request Leave</a></div>
        <div class="dropbtn"><a href="leave-user-status.php">Leave Status</a></div>
    </div>
</div>
    <div class="container">
        <p align="center">Leave Status</p>
        <div>
            <div class="top">
                <div>
                    Show
                    <select>
                        <option value="">1</option>
                        <option value="">2</option>
                        <option value="">3</option>
                        <option value="">4</option>
                        <option value="">5</option>
                        <option value="">6</option>
                        <option value="">7</option>
                        <option value="">8</option>
                        <option value="">9</option>
                        <option value="">10</option>
                    </select>
                    entries
                </div>
                <div>
                    Search <input type="search" id="srch">
                </div>
            </div>
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>Leave Type</th>
                    <th>Leave Start Date</th>
                    <th>Leave End Date</th>
                    <th>Duration</th>
                    <th>Reason</th>
                    <th>Status</th>
                    
                </tr> 
                <?php  while($arr=mysqli_fetch_array($leave_table1)){?> 
                <tr>
                    <td><?php echo $arr['leave_type'];  ?></td>
                    <td><?php echo $arr['leave_start_date'];  ?></td>
                    <td><?php echo $arr['leave_end_date'];  ?></td>
                    <td><?php echo $arr['duration'];  ?></td>
                    <td><?php echo $arr['reason'] ;  ?></td>
                    <td <?php 
                    if($arr['status'] === 'Approved') {?>style="color: green"<?php } else { ?>style="color: red" <?php }
                    ?>>
                        <?php echo $arr['status'] ;  ?>  </td>
                    </tr>
                <?php } ?>     
            </table>
            </div>
        </div>
    </div>
    <script src="leave-approve.js"></script>
</body>
</html>