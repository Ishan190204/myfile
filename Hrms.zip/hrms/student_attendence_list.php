<?php 
    include("conn.php");
    session_start();
    $sid=$_SESSION["student_id"] ;
    $sname=$_SESSION['student_name'];
    $subj_id=$_SESSION['sub_id'];
    $subj=$_SESSION['subj'];
   $k=0;
   $cur_mon=date("m",strtotime(date("Y-m-d")));
   $pre_mon=$cur_mon - 1;
   $cur_month_str= date("F", mktime(0, 0, 0,$cur_mon, 1));
   $pre_month_str= date("F", mktime(0, 0, 0,$pre_mon, 1));
   $cur_year=date("Y");
if(!empty($_REQUEST['subj_id']))
{
    $subj_id=$_REQUEST['subj_id'];
    $fetch_sub=mysqli_query($conn,"SELECT `subject_name` from `subject_master` where `subject_id`='$subj_id'");
    $sub_arr=mysqli_fetch_array($fetch_sub);
    $fetch_at=mysqli_query($conn,"SELECT * from `attendence` where `student_id`='$sid' and `subject_id`='$subj_id' and `month` between '$cur_month_str' and '$pre_month_str' order by `date` desc");
    $subj=$sub_arr['subject_name'];
    $_SESSION['subj']=$subj;
    $_SESSION['stud_id']=$sid;
    $_SESSION['sub_id']=$subj_id;

}
if(isset($_REQUEST['search'])){
    $search=$_REQUEST['search'];
    $sid1=$_SESSION['stud_id'];
    $sub_id=$_SESSION['sub_id'];
    $subj=$_SESSION['subj'];
    
    $fetch_at=mysqli_query($conn,"SELECT * from `attendence` where `student_id`='$sid1' and `subject_id`='$sub_id' and `month`='$search' and `year`='$cur_year' order by `date` desc");
    
}
else{
    $search="";

        
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendence</title>
    <link rel="stylesheet" href="Task-status.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
        <div class="dash">Dashboard</div>
        <div class="nav">
            <div class="subNavs"><a href="student_dashboard.php">Home</a></div>
            <div class="subNavs"><a href="subject_list.php">Subject-List</a></div>
        </div>
        <div class="welcome">
            <div><h2>Welcome <?php echo $sname ?></h2></div> 
            <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
        </div>
</div>    

    <div class="container">
        <p align="center">Attendence</p>
         <p align="center"><?php echo $subj;?></p>
         <div align="center">
         <a href="student_attendence_list.php"><i class="fa-solid fa-list"></i></a><span><h3>Attendence list</h3></span>
        </div>
            <div class="top">
                <div>
                    Show
                    <select>
                        <option value="">1</option>
                        <option value="">2</option>
                        <option value="">3</option>
                        <option value="">4</option>
                        <option value="">5</option>
                        <option value="">6</option>
                        <option value="">7</option>
                        <option value="">8</option>
                        <option value="">9</option>
                        <option value="">10</option>
                    </select>
                    entries
                </div>
                <div >
                    Search:
                    
                </div>
            </div>
            
            <table border="1" align="center">
                <tr>
                    <th> <?php echo $sname ?></th>
                    <th>Attendence</th>
                    <th>Month</th>
                    <th>Topic Covered</th>
                </tr>
                <?php  while($arr=mysqli_fetch_array($fetch_at)){?> 
                <tr>
                    <td><?php echo ++$k ;  ?></td>
                    <td><?php if($arr['present']==='Y') { ?><h2 style="color: green;">Present</h2><?php } else { ?><h2 style="color: red;">Absent</h2> <?php }  ?></td>
                    <td><?php echo $sname  ?></td>
                    <td><?php echo $subj  ?></td>
                    <td><?php echo $arr['topic_covered'];  ?></td>
                    </tr>
                <?php } ?>
                
            </table>
        </div>
    </div>
    <script>
        function filter(val){
            window.location.href="student_attendence.php?search="+val;
        }
    </script>
</body>
</html>
