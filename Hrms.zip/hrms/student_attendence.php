<?php 
    include("conn.php");
    session_start();
    $sid=$_SESSION["student_id"] ;
    $sname=$_SESSION['student_name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($sname) || empty($sid))
    {
       @header("Location: index.php");
       exit();
    }
   $k=0;
   $cur_mon=date("m",strtotime(date("Y-m-d")));
   $pre_mon=$cur_mon - 1;
   $cur_month_str= date("F", mktime(0, 0, 0,$cur_mon, 1));
   $pre_month_str= date("F", mktime(0, 0, 0,$pre_mon, 1));
   $cur_year=date("Y");
if(!empty($_REQUEST['subj_id']))
{
    $t=$_REQUEST['tid'];
    $subj_id=$_REQUEST['subj_id'];
    $fetch_sub=mysqli_query($conn,"SELECT `subject_name` from `subject_master` where `subject_id`='$subj_id'");
    $sub_arr=mysqli_fetch_array($fetch_sub);
    $subj=$sub_arr['subject_name'];
    $fetch_at=mysqli_query($conn,"SELECT * from `attendence` where `student_id`='$sid' and `subject_id`='$subj_id' and `teacher_id`='$t' and `month` between '$cur_month_str' and '$pre_month_str' order by `date` desc");
    $_SESSION['sub']=$subj;
    $_SESSION['teacher']=$t;
    $_SESSION['stud_id']=$sid;
    $_SESSION['sub_id']=$subj_id;

}
if(isset($_REQUEST['search'])){
    $search=$_REQUEST['search'];
    $subj=$_SESSION['sub'];
    $sid1=$_SESSION['stud_id'];
    $sub_id=$_SESSION['sub_id'];
    $t1=$_SESSION['teacher'];
    
    $fetch_at=mysqli_query($conn,"SELECT * from `attendence` where `student_id`='$sid1' and `subject_id`='$sub_id' and `teacher_id`='$t1' and `month`='$search' and `year`='$cur_year' order by `date` desc");
    
}
else{
    $search="";

        
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Attendence</title>
    <link rel="stylesheet" href="student_attendence.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
        <div class="nav">
            <div class="subNavs"><a href="student_dashboard.php">Home</a></div>
            <div class="subNavs"><a href="s_change_pass.php">Change Password</a></div>
            <div class="subNavs"><a href="s_timetable.php">Time table</a></div>
            <div class="subNavs"><a href="subject_list.php">Subject-List</a></div>
        </div>
        <div class="welcome">
            <div><h2>Welcome <?php echo $sname ?></h2></div> 
            <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
        </div>
</div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="student_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="s_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="s_timetable.php">Timetable</a></div>
        <div class="dropbtn"><a href="subject_list.php">Subject List</a></div>
    </div>
</div>

    <div class="container">
        <p align="center">Attendence Record</p>
        <p align="center"><?php echo $subj;?></p>
         <div align="center" style="display: flex; justify-content:center; align-items:center;gap:10px; flex-direction:row-reverse;">
        <!--<a href="student_attendence_list.php"><i class="fa-solid fa-list"></i></a><span><h3>Attendence list</h3></span>-->
        </div>
            <div class="top">
                
                <div >
                    Search:
                    <select id="sel"  onchange="filter(this.value)">
                        <option value="January" <?php if(!empty($search) && $search==='January'){ ?> selected <?php } if(empty($search) && $cur_month_str=='January') { echo "selected"; } ?>>January</option>
                        <option value="February" <?php if(!empty($search) && $search==='February'){ ?> selected <?php } if(empty($search) && $cur_month_str=='February') { echo "selected"; } ?>>February</option>
                        <option value="March" <?php if(!empty($search) && $search==='March'){ ?> selected <?php } if(empty($search) && $cur_month_str=='March') { echo "selected"; } ?>>March</option>
                        <option value="April" <?php if(!empty($search) && $search==='April'){ ?> selected <?php } if(empty($search) && $cur_month_str=='April') { echo "selected"; } ?>>April</option>
                        <option value="May" <?php if(!empty($search) && $search==='May'){ ?> selected <?php } if(empty($search) && $cur_month_str=='May') { echo "selected"; } ?>>May</option>
                        <option value="June" <?php if(!empty($search) && $search==='June'){ ?> selected <?php } if(empty($search) && $cur_month_str=='June') { echo "selected"; } ?>>June</option>
                        <option value="July" <?php if(!empty($search) && $search==='July'){ ?> selected <?php } if(empty($search) && $cur_month_str=='July') { echo "selected"; } ?>>July</option>
                        <option value="August" <?php if(!empty($search) && $search==='August'){ ?> selected <?php } if(empty($search) && $cur_month_str=='August') { echo "selected"; } ?> >August</option>
                        <option value="September" <?php if(!empty($search) && $search==='September') { ?> selected <?php } if(empty($search) && $cur_month_str=='September') { echo "selected"; } ?>>September</option>
                        <option value="October" <?php if(!empty($search) && $search==='October'){ ?> selected <?php } if(empty($search) && $cur_month_str=='October') { echo "selected"; } ?>>October</option>
                        <option value="November" <?php if(!empty($search) && $search==='November'){ ?> selected <?php } if(empty($search) && $cur_month_str=='November') { echo "selected"; } ?>>November</option>
                        <option value="December" <?php if(!empty($search) && $search==='December'){ ?> selected <?php } if(empty($search) && $cur_month_str=='December') { echo "selected"; } ?>>December</option>
                    </select>
                </div>
            </div>
            <br>
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>ID</th>
                    <th>Attendence</th>
                    <th>Date</th>
                    <th>Slot</th>
                    <th>Remarks</th>
                    <th>Topic Covered</th>
                </tr>
                <?php  while($arr=mysqli_fetch_array($fetch_at)){?> 
                <tr>
                    <td><?php echo ++$k ;  ?></td>
                    <td><?php if($arr['present']==='Y') { ?><h2 style="color: green;">Present</h2><?php } else { ?><h2 style="color: red;">Absent</h2> <?php }  ?></td>
                    <td><?php echo $arr['date'];  ?></td>
                    <td><?php echo $arr['slot'];  ?></td>
                    <td><?php echo $arr['remarks'];  ?></td>
                    <td><?php echo $arr['topic_covered'];  ?></td>
                    </tr>
                <?php } ?>
            </table>
            </div>
        </div>
    </div>
    <script>
        function filter(val)
        {
            window.location.href="student_attendence.php?search="+val;
        }
        function show()
        {
            console.log("!!!");
            document.getElementById('dropLinks').style.visibility="visible";
        }
        function hide()
        {
            document.getElementById('dropLinks').style.visibility="hidden"; 
        }
    </script>
</body>
</html>
