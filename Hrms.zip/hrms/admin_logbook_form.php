<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    $id1=$_SESSION["usid"];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name1))
    {
       @header("Location: index.php");
       exit();
    }   
      if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
      else
        {   
          $mspg  = ""; 
        } 
        $query="SELECT count(`task_id`) as `count` from `log_book_table` where `user_id`='$id1' group by `user_id`,`task_date` ORDER BY `task_date` DESC;";
        $result=mysqli_query($conn,$query);
        $row=mysqli_fetch_array($result);
        if(!empty($row)){
        $total_task=$row['count'];
        $task_id="TASK"." ".$total_task+1;
        }
        else
        {
            $task_id="TASK"." 1";
        }

        $sql_user="SELECT `user_description` FROM `staff_registration_master` WHERE `user_id`='$id1'";
        $user_result=mysqli_query($conn,$sql_user);
        $user_row=mysqli_fetch_array($user_result);
        $desc=$user_row['user_description'];
        if(!empty($_REQUEST['id']))
        {
            $id=$_REQUEST['id'];
            $task_edit=mysqli_query($conn,"SELECT * from `log_book_table` where `log_book_id`='$id' ");
            $edit_row=mysqli_fetch_array($task_edit);
            $task=$edit_row['task_id'];
        }
    if(!empty($_REQUEST['mode']))
    {  
        $t_id=$_REQUEST['task_id'];
        $t_desc=$_REQUEST['task_description'];
        $t_date=$_REQUEST['task_date'];
      
      $sql_task="INSERT INTO `log_book_table` SET 
                `user_id`= '$id1',
                `user_type`= '$desc',
                `task_description`= '$t_desc',
                `task_date`= '$t_date',
                `task_id`= '$t_id'  ";  
      $task=mysqli_query($conn, $sql_task);
      
      if($task)
        {
          @header("Location: admin_logbook_form.php?msg=Task Submitted");
		      exit(); 

        }
    }
    elseif(!empty($_REQUEST['editmode']))
    {
        $desc_edit=$_REQUEST['task_description'];
        $edit_insrt=mysqli_query($conn,"UPDATE `log_book_table` SET `task_description`='$desc_edit' where `log_book_id`='$id'");
        if($edit_insrt)
        {
            @header("Location: admin_logbook_table.php");
            exit();
        }
    }
    $cur_date=date("Y-m-d");
?> 

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Log Book Form</title>
        <link rel="stylesheet" href="admin_logbook_form.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
       
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Log-Book-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="admin_logbook_form.php">Log Book Form</a>
            <a href="admin_logbook_table.php">Log Book Table</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div> 

  <div style="height:20px"></div>
  <h4 align="center" style="color:red;font-weight:bold;"><?php echo $mspg ?></h4>  
  <div style="height:40px"></div>
       <div class="superContainer">
            <div class="container">
                <div class="heading">Log-Book<br>Form</div>
                <form class="form" enctype="multipart/form-data" method="post" name="task_assn_form" id="task_assn_form" onSubmit="return checking();">
                    <input type="hidden" name="<?php if(empty($id)){?>mode<?php } else{ ?>editmode<?php } ?>" value="1">
                    <div class="inputContainer">
                        <label>Task Number(This cannot be edited)</label><input type="text" class="inputField" placeholder="Enter The Task Id" value="<?php if(!empty($id)){ echo $task; } ?>" name="task_id" id="task_id" <?php if(!empty($id)){?>readonly<?php } ?>>
                    </div> 
                    <div class="inputContainer">
                        <label>Task Description(This can be edited)</label>
                        <textarea name="task_description" id="task_description" rows="10" cols="38" ><?php if(!empty($id)){ echo $edit_row['task_description']; }?></textarea>
                    </div>
                    <div class="inputContainer">
                        <label>Date(This cannot be edited)</label><input type="date" class="inputField" name="task_date" id="task_date" value="<?php if(empty($id)) {echo $cur_date;} else { echo $edit_row['task_date']; } ?>"  <?php if(!empty($id)){?> readonly <?php } ?>>
                    </div>
                    
                    <div class="gap"></div> 
                <input type="submit" class="assign-btn" value="<?php if(empty($id)){?>Submit<?php } else {?>Edit<?php } ?>">
                </form>
            </div>
        </div>
        <script src="task-assign.js"></script>

    </body>
</html>