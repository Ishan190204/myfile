var class_id = document.getElementById("class");
var sub_id = document.getElementById("subject");

function cls_chk(){
    window.location.href="student_status.php?sub="+sub_id.value+"&class="+class_id.value;
}
function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}