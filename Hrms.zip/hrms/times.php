<?php
    //To do admin check
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
    if(isset($_REQUEST['submit']))
    {
        if(isset($_REQUEST['start-time']) && isset($_REQUEST['end-time']))
        {
            $startTime = $_REQUEST['start-time'];
            $endTime = $_REQUEST['end-time'];
            $query = "INSERT INTO `time_master` SET `start_time` = '$startTime',
                                                    `end_time` = '$endTime'";
            $res = mysqli_query($conn, $query);
            if($res)
            {
                header("Location: times.php");
            }
        }
    }
    if(isset($_REQUEST['update']))
    {
        if(isset($_REQUEST['start-time']) && isset($_REQUEST['end-time']))
        {
            $startTime = $_REQUEST['start-time'];
            $endTime = $_REQUEST['end-time'];
            $timeID = (int) $_REQUEST['time-id'];
            $query = "UPDATE `time_master` SET `start_time` = '$startTime',
                                               `end_time` = '$endTime'
                                               WHERE `time_id` = '$timeID'";
            $res = mysqli_query($conn, $query);
            if($res)
            {
                header("Location: times.php");
            }
            else
            {
                echo $res;
            }
        }
    }
    if(isset($_REQUEST['delete']))
    {
        $timeID = (int) $_REQUEST['time-id'];
        $query = "DELETE FROM `time_master` WHERE `time_id` = '$timeID'";
        try
        {
            $res = mysqli_query($conn, $query);
            header("Location: times.php");
        }
        catch(Exception $e)
        {
            echo("Cannot delete time since it is used by a slot. Delete all slots related to this time first to delete this time");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include("title.php"); ?>
        <link rel="stylesheet" href="style.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>

        


        <div class="container">
            <h2>Your times</h2>
            <p>Add or modify your times here</p>
            <br>

            <div>
                <form method="POST">
                    <h3>Add time</h3>
                    <div style="height: 8px;"></div>
                    <div class="flex gap-8">
                        <div>
                            <label for="start-time">Start Time:</label>
                            <br>
                            <input class="font-12" type="time" name="start-time">
                        </div>
                        <div>
                            <label for="end-time">End Time:</label>
                            <br>
                            <input class="font-12" type="time" name="end-time">
                        </div>
                    </div>
                    <div style="height: 4px;"></div>
                    <input class="font-12" type="submit" name="submit">
                </form>
            </div>

            <br><br>

            <div class="tableDiv">
                <h3>Available times</h3>
                <div style="height: 8px;"></div>
                <table width="25%">
                    <thead>
                        <tr>
                            <td class="font-18">Time</td>
                            <td class="font-18">Operations</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $query = "SELECT * FROM `time_master`";
                            $res = mysqli_query($conn, $query);
                            while($ar = mysqli_fetch_array($res))
                            {
                        ?>
                        <tr>
                            <form method="POST">
                                <td>
                                    <input class="pseudo-input font-16" type="hidden" value="<?php echo $ar['time_id']; ?>" name="time-id">
                                    <div class="flex gap-8">
                                        <div>
                                            <input class="pseudo-input font-16" type="time" value="<?php echo $ar['start_time']; ?>" name="start-time">
                                        </div>
                                        —
                                        <div>
                                            <input class="pseudo-input font-16" type="time" value="<?php echo $ar['end_time']; ?>" name="end-time">
                                        </div>
                                    </div>
                                </td>
                                <td class="flex gap-8">
                                    <input type="submit" name="update" value="Update">
                                    <input type="submit" name="delete" value="Delete">
                                </td>
                            </form>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script src="admin_dashboard.js"></script>
    </body>
</html>