<?php
include("conn.php");
session_start();   
$sid=$_REQUEST['st_id'];
$cid=$_REQUEST['cl_id'];
$sbid=$_REQUEST['sb_id'];
$st=$_REQUEST['s'];
if($st === 'Active'){
    $sql=mysqli_query($conn,"UPDATE `student_subject` set status='Inactive'  where 
                            `stud_id`='$sid' and
                            `class_id`='$cid' and
                            `subject_id`='$sbid' ");
    

    $sql1=mysqli_query($conn,"UPDATE `teacher_student_map` set status='Inactive'  where 
                             `student_id`='$sid' and
                            `class_id`='$cid' and
                            `subject_id`='$sbid' ");  
     
}
else{
    $sql=mysqli_query($conn,"UPDATE `student_subject` set status='Active'  where 
                             `stud_id`='$sid' and
                            `class_id`='$cid' and
                            `subject_id`='$sbid' ");
    

    $sql1=mysqli_query($conn,"UPDATE `teacher_student_map` set status='Active'  where 
                             `student_id`='$sid' and
                            `class_id`='$cid' and
                            `subject_id`='$sbid'  "); 
}
if($sql && $sql){
    @header("Location: ".$_SERVER['HTTP_REFERER']);
}
?>