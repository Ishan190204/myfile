function pres_chk(){
    
    if(document.getElementById("pres").checked == true)
       {
       var ele=document.getElementsByName('present[]');  
       var ele1=document.getElementsByName('absent[]');  
       for(var i=0; i<ele.length; i++){  
           if(ele[i].type=='checkbox')  
               ele[i].checked=true;  
           if(ele1[i].type=='checkbox')
               ele1[i].checked=false; 
       }  
       document.getElementById("abs").checked=false;
       
   }
   else{
       var ele=document.getElementsByName('present[]');  
       for(var i=0; i<ele.length; i++){  
           if(ele[i].type=='checkbox')  
               ele[i].checked=false;  
            
       }  
   }      

}
function abs_chk(){
   /*if( document.getElementById("allcheck").checked == true)
   {
    window.location.href="attendence_form.php?all="+1;
   }
   else{
    window.location.href="attendence_form.php?all="+2;
   }*/
    if(document.getElementById("abs").checked == true)
       {
       var ele=document.getElementsByName('absent[]');
       var ele1=document.getElementsByName('present[]');  
       for(var i=0; i<ele.length; i++){  
           if(ele[i].type=='checkbox')  
               ele[i].checked=true;  
           if(ele1[i].type=='checkbox')
               ele1[i].checked=false; 
       }  
       document.getElementById("pres").checked=false;
   }
   else{
       var ele=document.getElementsByName('absent[]');  
       for(var i=0; i<ele.length; i++){  
           if(ele[i].type=='checkbox')  
               ele[i].checked=false;  
             
       }  
   }      

}
function topic_chk(){
   /*if( document.getElementById("allcheck").checked == true)
   {
    window.location.href="attendence_form.php?all="+1;
   }
   else{
    window.location.href="attendence_form.php?all="+2;
   }*/
    if(document.getElementById("tpcheck").checked == true)
       {
           var index=0;
           var ele=document.getElementsByName('topic_covered[]');  
           for(var j=0; j<ele.length; j++){  
               if(ele[j].value!=='') { 
               index=j;
                   break;
               }  
           }  
           for(var i=0; i<ele.length; i++){    
                   ele[i].value=ele[index].value;  
           }  
   }
   else{
       var ele=document.getElementsByName('topic_covered[]');  
       for(var i=0; i<ele.length; i++){  
           if(ele[i].type=='checkbox')  
               ele[i].checked=false;  
             
       }  
   }      

}


function date_chk(value)
{
   window.location.href="t_attendence_table.php?date1="+value;
}

function pres_Individual_chk(indx){
   indx=indx-1;
   var indv=document.getElementsByName('present[]');  
   var indv1=document.getElementsByName('absent[]');
   if(indv[indx].type=='checkbox' && indv[indx].checked==true)  
       indv1[indx].checked=false;  

}
function abs_Individual_chk(indx){
   indx=indx-1;
   var indv=document.getElementsByName('absent[]');
   var indv1=document.getElementsByName('present[]');  
   
   if(indv[indx].type=='checkbox' && indv[indx].checked==true)  
       indv1[indx].checked=false;  

}
function show()
{
   console.log("!!!");
   document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
   document.getElementById('dropLinks').style.visibility="hidden"; 
}

        var class_id = document.getElementById("class");
        var sub_id = document.getElementById("subject");
        var date = document.getElementById("date");
        function chk(){
            window.location.href="t_attendence_table.php?class="+class_id.value+"&sub="+sub_id.value+"&date="+date.value;
        }
    