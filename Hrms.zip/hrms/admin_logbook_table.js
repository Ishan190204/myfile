var tch_id = document.getElementById("teacher");
function teacher_chk(){
    window.location.href="admin_logbook_table.php?tch="+tch_id.value;
}
function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}

function edit()
{
    
    window.location.href="admin_logbook_form.php";
}

var from=document.getElementById('from_date');
var to=document.getElementById('to_date');
function fromdate()
{
    window.location.href="admin_logbook_table.php?from="+from.value+"&to="+to.value;
}