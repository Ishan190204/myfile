<?php 
include("conn.php");
session_start();
$name1=$_SESSION["usname"] ;
if(mysqli_connect_errno()){
  echo "failed to connect to mysql" . mysqli_connect_error();
}
if(empty($name1))
{
 @header("Location: index.php");
 exit();
}
if(isset($_REQUEST['search'])){
  $search=$_REQUEST['search'];
  $sql=mysqli_query($conn,"SELECT `user_id`,`name`,`user_description`,`user_type`,`user_status`,`phone_no` FROM `staff_registration_master`  where `name` like '%$search%'or`user_description` like '%$search%'or`user_type` like '%$search%'or `phone_no` like '%$search%'or `user_status` like '%$search%'or `user_id` like '%$search%' order by `user_id`");

}
else{
  $search="";
  
$sql=mysqli_query($conn,"SELECT `user_id`,`name`,`user_description`,`user_type`,`user_status`,`phone_no`FROM `staff_registration_master` order by `user_id`");

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Details</title>
    <link rel="stylesheet" href="staff-details.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>    


    <div class="container">
        <p align="center">Staff Details</p>
        <div>
            <div class="top">
                <div></div>
                <div>
                    Search: <input type="text" id="srch" onchange="filter()" >
                </div>
            </div>
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>ID</th>
                    <th>Staff Name</th>
                    <th>Description</th>
                    <th>User-Type</th>
                    <th>Phone NO.</th>
                    <th>Status</th>
                </tr>
                <?php  while($arr=mysqli_fetch_array($sql)){?> 
                <tr>
                    <td><?php echo $arr['user_id'];  ?></td>
                    <td><?php echo $arr['name'];  ?></td>
                    <td><?php echo $arr['user_description'];  ?></td>
                    <td><?php echo $arr['user_type'];  ?></td>
                    <td><?php echo $arr['phone_no'];  ?></td>
                    <td><a href="active-inactive-staffdtls.php?userid=<?php echo $arr['user_id'] ?>" <?php if($arr['user_status']=='Yes') { ?> style="color: grey;text-decoration: none; cursor: default;" <?php } ?>>Active</a> | <a href="active-inactive-staffdtls.php?userid=<?php echo $arr['user_id'] ?>" <?php if($arr['user_status']=='No') { ?> style="color: grey;text-decoration: none; cursor: default;" onclick="return false;"<?php } ?>>Inactive</td>
                </tr>
                <?php } ?>
            </table>
            </div>
        </div>
    </div>
    <script src="admin_dashboard.js"></script>
    <script>
        function filter(){
          var val=document.getElementById("srch").value;
            window.location.href="staff-details.php?search="+val;
        }
    </script>
</body>
</html>