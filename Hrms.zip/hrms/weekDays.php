<?php
    //To do admin check
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
    if(isset($_REQUEST['submit']))
    {
        if(isset($_REQUEST['day-name']) && $_REQUEST['day-name'] != "")
        {
            $dayName = $_REQUEST['day-name'];
            $query = "INSERT INTO `day_master` SET `day_name` = '$dayName'";
            $res = mysqli_query($conn, $query);
            if($res)
            {
                header("Location: weekDays.php");
            }
        }
    }
    if(isset($_REQUEST['update']))
    {
        if(isset($_REQUEST['day-name']) && $_REQUEST['day-name'] != "")
        {
            $dayName = $_REQUEST['day-name'];
            $dayID = (int) $_REQUEST['day-id'];
            $query = "UPDATE `day_master` SET `day_name` = '$dayName' WHERE `day_id` = '$dayID'";
            $res = mysqli_query($conn, $query);
            if($res)
            {
                header("Location: weekDays.php");
            }
        }
    }
    if(isset($_REQUEST['delete']))
    {
        $dayID = (int) $_REQUEST['day-id'];
        $query = "DELETE FROM `day_master` WHERE `day_id` = '$dayID'";
        try
        {
            $res = mysqli_query($conn, $query);
            header("Location: weekDays.php");
        }
        catch(Exception $e)
        {
            echo("Cannot delete day since it is used by a slot. Delete all slots related to this day first to delete this day");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include("title.php"); ?>
        <link rel="stylesheet" href="style.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>


        <div class="container">
            <h2>Your Days</h2>
            <p>Add or modify your week days here</p>
            <br>

            <div>
                <form method="POST">
                    <h3>Add Day</h3>
                    <div style="height: 8px;"></div>
                    <input class="font-12" type="text" placeholder="Enter day name" name="day-name">
                    <input class="font-12" type="submit" name="submit">
                </form>
            </div>

            <br><br>

            <div class="tableDiv">
                <h3>Available Days</h3>
                <div style="height: 8px;"></div>
                <table width="25%">
                    <thead>
                        <tr>
                            <td class="font-18">Day Name</td>
                            <td class="font-18">Operations</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $query = "SELECT * FROM `day_master`";
                            $res = mysqli_query($conn, $query);
                            while($ar = mysqli_fetch_array($res))
                            {
                        ?>
                        <tr>
                            <form method="POST">
                                <td>
                                    <input class="pseudo-input font-16" type="hidden" value="<?php echo $ar['day_id']; ?>" name="day-id">
                                    <input class="pseudo-input font-16" type="text" value="<?php echo $ar['day_name']; ?>" name="day-name">
                                </td>
                                <td class="flex gap-8">
                                    <input type="submit" name="update" value="Update">
                                    <input type="submit" name="delete" value="Delete">
                                </td>
                            </form>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
          function show()
          {
              console.log("!!!");
              document.getElementById('dropLinks').style.visibility="visible";
          }
          function hide()
          {
              document.getElementById('dropLinks').style.visibility="hidden"; 
          }
        </script>
    </body>
</html>