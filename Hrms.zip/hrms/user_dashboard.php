<?php 
    include("conn.php");
    session_start();
    $userid=$_SESSION["user_id"];
    $name=$_SESSION['name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name) || empty($userid))
    {
       @header("Location: index.php");
       exit();
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="user_dashboard.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>User Dashboard</title>
</head>
<body>
<div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
        <div class="nav">
            <div class="subNavs"><a href="user_dashboard.php">Home</a></div>
            <div class="subNavs"><a href="u_change_pass.php">Change Password</a></div>
            <div class="subNavs"><a href="task-list.php">Task List</a></div>
            <div class="subNavs"><a href="leave.php">Request Leave</a></div>
            <div class="subNavs"><a href="leave-user-status.php">Leave Status</a></div>
        </div>
    <div class="welcome">
        <div><h2>Welcome <?php echo $name ?></h2> </div>
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>  
    </div>    
</div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="user_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="u_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="task-list.php">Task List</a></div>
        <div class="dropbtn"><a href="leave.php">Request Leave</a></div>
        <div class="dropbtn"><a href="leave-user-status.php">Leave Status</a></div>
    </div>
</div>
<script src="teacher_dashboard.js"></script> 
</html>       