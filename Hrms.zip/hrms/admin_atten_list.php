<?php 
    include("conn.php");
    session_start();    
    $name1=$_SESSION["usname"] ;
    $crt=date("Y-m-d");
    $month=substr("$crt",5,2);
            $month_int=(int)$month;
            $month_str= date("F", mktime(0, 0, 0,$month_int, 1));
            $year=substr("$crt",0,4);
        if(!empty($_REQUEST['tid'])){
            $tid=$_REQUEST['tid'];
            $class_id=$_REQUEST['cl'];
            $subject_id=$_REQUEST['sb'];
            $_SESSION['tid']=$tid;
            $_SESSION['cid']=$class_id;
            $_SESSION['sid']=$subject_id;
        }   
   
    if(!empty($_REQUEST['search'])){
        $search=$_REQUEST['search'];
        $tid= $_SESSION['tid'];
        $class_id=$_SESSION['cid'];
        $subject_id=$_SESSION['sid'];
        // attendence selected month wise
        $atten_sql=mysqli_query($conn,"SELECT *  from attendence where `teacher_id`='$tid' and `class_id`='$class_id' and `subject_id`='$subject_id' and `month`='$search' group by `date`,`slot` ");
    }
    else{
        $search="";
        
        $tid= $_SESSION['tid'];
        $class_id=$_SESSION['cid'];
        $subject_id=$_SESSION['sid'];
        // attendence current month wise
        $atten_sql=mysqli_query($conn,"SELECT * from attendence where `teacher_id`='$tid' and `class_id`='$class_id' and `subject_id`='$subject_id' and `month`='$month_str' group by `date`,`slot` ");
    }
    
$k=0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Attendence List</title>
    <link rel="stylesheet" href="admin_atten_list.css">
    
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>

        
    

    </div>
    <div class="container">
        <p align="center">Attendence</p>
        
            <div class="top">
                <div>
                    Show
                    <select>
                        <option value="">1</option>
                        <option value="">2</option>
                        <option value="">3</option>
                        <option value="">4</option>
                        <option value="">5</option>
                        <option value="">6</option>
                        <option value="">7</option>
                        <option value="">8</option>
                        <option value="">9</option>
                        <option value="">10</option>
                    </select>
                    entries
                </div>
                <div >
                <select id="sel"  onchange="filter(this.value)">
                        <option value="January" <?php if(!empty($search) && $search==='January'){ echo "selected" ;} elseif($month_str=='January' && empty($search)) { echo "selected" ;} ?>>January</option>
                        <option value="February" <?php if(!empty($search) && $search==='February'){ echo "selected" ;} elseif($month_str=='February' && empty($search)) { echo "selected" ;}  ?>>February</option>
                        <option value="March" <?php if(!empty($search) && $search==='March'){ echo "selected" ;} elseif($month_str=='March' && empty($search)) { echo "selected" ;}  ?>>March</option>
                        <option value="April" <?php if(!empty($search) && $search==='April'){ echo "selected" ;} elseif($month_str=='April' && empty($search)) { echo "selected" ;} ?>>April</option>
                        <option value="May" <?php if(!empty($search) && $search==='May'){ echo "selected" ;} elseif($month_str=='May' && empty($search)) { echo "selected" ;} ?>>May</option>
                        <option value="June" <?php if(!empty($search) && $search==='June'){ echo "selected" ;} elseif($month_str=='June' && empty($search)) { echo "selected" ;} ?>>June</option>
                        <option value="July" <?php if(!empty($search) && $search==='July'){ echo "selected" ;} elseif($month_str=='July' && empty($search)) { echo "selected" ;} ?>>July</option>
                        <option value="August" <?php if(!empty($search) && $search==='August'){ echo "selected" ;} elseif($month_str=='August' && empty($search)) { echo "selected" ;} ?>>August</option>
                        <option value="September" <?php if(!empty($search) && $search==='September'){ echo "selected" ;} elseif($month_str=='September' && empty($search)) { echo "selected" ;} ?>>September</option>
                        <option value="October" <?php if(!empty($search) && $search==='October'){ echo "selected" ;} elseif($month_str=='October' && empty($search)) { echo "selected" ;} ?>>October</option>
                        <option value="November" <?php if(!empty($search) && $search==='November'){ echo "selected" ;} elseif($month_str=='November' && empty($search)) { echo "selected" ;} ?>>November</option>
                        <option value="December" <?php if(!empty($search) && $search==='December'){ echo "selected" ;} elseif($month_str=='December' && empty($search))  { echo "selected" ;} ?>>December</option>
                    </select>
                </div>
            </div>
            <form class="subform"  action="" name="attendenceform" id="attendenceform" method="post" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1" />
            <div class="tableDiv">  
            <table border="1" align="center">
                <tr>
                    
                    <th>Id</th>
                    <th>Date</th>
                    <th>Slot</th>
                    
                </tr>
                <?php  while($atten_arr=mysqli_fetch_array($atten_sql)){?> 
                <tr>
                    <td><?php echo ++$k ?></td>
                    <td><a href="admin_monthwise_atten.php?date=<?php echo $atten_arr['date']; ?>&slot=<?php echo $atten_arr['slot']; ?>"><?php echo $atten_arr['date'];  ?></a></td>   
                    <td><?php echo $atten_arr['slot']; ?></td>             
                </tr>
                <?php } ?>
                
            </table>
            </div>
            </form>
        </div>
    </div>
    <script>
        function filter(val){
            window.location.href="admin_atten_list.php?search="+val;
        }
        function show()
            {
                console.log("!!!");
                document.getElementById('dropLinks').style.visibility="visible";
            }
            function hide()
            {
                document.getElementById('dropLinks').style.visibility="hidden"; 
            }
    </script>
    <!-- <script src="admin_dashboard.js"></script> -->
</body>
</html>
