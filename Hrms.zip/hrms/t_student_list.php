<?php 
    include("conn.php");
    session_start();
    $tid=$_SESSION["user_id"];
    $name2=$_SESSION['name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name2) || empty($tid))
    {
       @header(header: "Location: index.php");
       exit();
    }
    $fetch_class="SELECT * from `teacher_student_map` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` where `teacher_student_map`.`teacher_id`='$tid' group by `class_master`.`class_id`";
    $ft_class=mysqli_query($conn,$fetch_class);
    $fetch_sub="SELECT * from `teacher_student_map`  inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' group by `subject_master`.`subject_id`";
    $ft_sub=mysqli_query($conn,$fetch_sub);
   $fetch_student="SELECT `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active'";
$ft_res=mysqli_query($conn,$fetch_student);
$k=0;
$flag=0;
if(!empty($_REQUEST['class']) || !empty($_REQUEST['sub']))  {
    $class_id=$_REQUEST['class'];
    $sub_id=$_REQUEST['sub'];
    if(empty($sub_id)){
        $ft_res=mysqli_query($conn ,"SELECT * FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id' ");
        $arr=mysqli_fetch_array($ft_res);
        if(!empty($arr)){
            $flag=1;
            $ft_res=mysqli_query($conn ,"SELECT * FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id'  ");

        }  
    }
    elseif(empty($class_id)&& !empty($sub_id)){
        $ft_res=mysqli_query($conn ,"SELECT * FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id' ");
        $arr=mysqli_fetch_array($ft_res);
        if(!empty($arr)){
            $flag=1;
            $ft_res=mysqli_query($conn ,"SELECT * FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id'  ");
    
        }
    }
    else{
        $ft_res=mysqli_query($conn ,"SELECT * FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id' and `subject_master`.`subject_id`='$sub_id' ");
        $arr=mysqli_fetch_array($ft_res);
        if(!empty($arr)){
            $flag=1;
            $ft_res=mysqli_query($conn ,"SELECT * FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id'  and `subject_master`.`subject_id`='$sub_id' ");

        }
    }
}
/*if(!empty($_REQUEST['class']) && !empty($_REQUEST['sub'])){
    $class_id=$_REQUEST['class'];
    $sub_id=_REQUEST['sub'];


    $ft_res=mysqli_query($conn ,"SELECT `student_master`.`student_name`,`class_master`.`class_name`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id' and `subject_master`.`subject_id`='$sub_id'");
    $arr=mysqli_fetch_array($ft_res);
    if(!empty($arr)){
        $flag=1;
        $ft_res=mysqli_query($conn ,"SELECT `student_master`.`student_name`,`class_master`.`class_name`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id' and `subject_master`.`subject_id`='$sub_id' ");

    }
    
    
    
}*/
else{
    $class_id="";
    $fetch_student="SELECT `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`subject_master`.`subject_name`,`subject_master`.`subject_id` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active'";
    $ft_res=mysqli_query($conn,$fetch_student);
}
if(!empty($_REQUEST['mode']) && $_REQUEST['submit']=='invite')
        {
            $link=$_REQUEST['link'];
            $date=date("Y-m-d");
            $month=substr("$date",5,2);
            $month_int=(int)$month;
            $month_str= date("F", mktime(0, 0, 0,$month_int, 1));
            $year=date("Y");
            $sql_link= "INSERT INTO `link` SET 
                            `link`= '$link',
                            `date`= '$date',
                            `month`= '$month_str',
                            `year`= '$year'  ";  
            $ts_insrt=mysqli_query($conn, $sql_link);
            if($ts_insrt){
                $sql_link=mysqli_query($conn,"SELECT max(`link_id`) as `link_id` from `link` ");
                $link_id_ar=mysqli_fetch_array($sql_link);
                $link_id=$link_id_ar['link_id'];
            }


            $student_id=$_REQUEST['student_id'];
            $subject_id=$_REQUEST['subject_id'];
           //$tid
            if(!empty($_REQUEST['invite'])){
                $invite=$_REQUEST['invite'];
            }
            
        
            $index=0;
            
              foreach( $student_id as $key => $n ) {
                $pres="N";
                if(isset($invite[$index])&&($invite[$index])==($key+1)){
                    $pres="Y";
                    $index++;
                }    
                if($pres==='Y'){
                
                $sql_tc_st= "INSERT INTO `link_teacher_student` SET 
                            `teacher_id`='$tid',
                            `student_id`= '$student_id[$key]',
                            `link_id`='$link_id',
                            `subject_id`='$subject_id[$key]' ";  
                $ts_insrt1=mysqli_query($conn, $sql_tc_st);
                }
        }
        if($ts_insrt1){
            @header("Location:t_student_list.php");
          exit();  		
        }   
    }
               
         
    
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List</title>
    <link rel="stylesheet" href="t_student_list.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
<div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Teacher Dashboard</div>
</div>
    <div class="nav">
        <div class="subNavs"><a href="teacher_dashboard.php">Home</a></div>
        <div class="subNavs"><a href="t_change_pass.php">Change Password</a></div>
        <div class="subNavs"><a href="t_timetable.php">Time table</a></div>
        <!-- <div class="subNavs"><a href="t_task_list.php">Task List</a></div> -->
        <!-- <div class="subNavs"><a href="t_student_list.php">Student List</a></div> -->
        <!-- <div class="subNavs"><a href="t_attendence_table.php">Attendence Table</a></div> -->
        <!-- <div class="subNavs"><a href="attendence_list.php">Attendence List</a></div> -->
        <div class="dropdown" style="width: 14.8vw;padding-top:8px;">
            <button class="dropbtn" id="list">Attendence-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_attendence_table.php">Attendence Table</a>
                <a href="attendence_list.php">Attendence List</a>
            </div>
        </div>
        <div class="dropdown" style="width: 14vw;padding-top:8px;">
            <button class="dropbtn" id="list">List-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_task_list.php">Task List</a>
                <a href="t_student_list.php">Student List</a>
            </div>
        </div>
    </div>
    <div class="welcome">
        <div><h2>Welcome <?php echo $name2 ?></h2></div> 
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>    
</div>


<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="teacher_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="t_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="t_task_list.php">Task List</a></div>
        <div class="dropbtn"><a href="t_student_list.php">Student List</a></div>
        <div class="dropbtn"><a href="t_attendence_table.php">Attendence Table</a></div>
        <div class="dropbtn"><a href="attendence_list.php">Attendence List</a></div>
        <div class="dropbtn"><a href="t_timetable.php">Time table</a></div>
    </div>
</div> 

<div class="container">
        <p align="center">Student List</p>
        <div style="gap:10px" align="center">      
                        <select class="inputSelect" name="class" id="class" onchange="chk()">
                            <option value="">Select Class</option>
                            <?php while($class_row=mysqli_fetch_array($ft_class)){ ?>
                                <option value="<?php echo $class_row['class_id'] ?>" <?php if(!empty($class_id) && $class_id==$class_row['class_id']) echo "selected" ;?>><?php echo $class_row['class_name'] ?></option>
                                    <?php } ?>
                        </select>
        
        <select class="inputSelect" name="subject" id="subject" onchange="chk()">
                            <option value="">Select Subject</option>
                            <?php while($class_row1=mysqli_fetch_array($ft_sub)){ ?>
                                <option value="<?php echo $class_row1['subject_id'] ?>" <?php if(!empty($sub_id) && $sub_id==$class_row1['subject_id']) echo "selected" ;?>><?php echo $class_row1['subject_name'] ?></option>
                                    <?php } ?>
                        </select>
        </div>
        
        <form class="subform"  action="" name="attendenceform" id="attendenceform" method="post" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1" />
                
        <div style="gap:10px;margin:auto;margin-top:10px;" align="center">
           <h2>Meet-Link</h2>
        <textarea name="link" class="areatext"style="width:350px"></textarea>
        </div>
                    
            
                    
                     
                
            <div class="tableDiv" style="margint-top;10px;">
            <table border="1" align="center">
                <tr>
                    <th>ID</th>
                    <th>Student Name</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Select All<input type="checkbox" id="pres"  name="present" onclick="pres_chk(this)" ></th>
                   
                </tr>
                <?php  while($arr=mysqli_fetch_array($ft_res)){?> 
                <tr>
                    <td><?php echo ++$k ;  ?></td>
                    <td><?php echo $arr['student_name'];  ?></td>
                    <td><?php echo $arr['class_name'];  ?></td>
                    <td><input type="hidden" name="subject_id[]" value="<?php echo $arr['subject_id']; ?>" ><input type="text" name="subject_name[]" value="<?php echo $arr['subject_name'];  ?>"></td>
                    <td><input type="hidden" name="student_id[]" value="<?php echo $arr['student_id']; ?>"><input type="checkbox" name="invite[]" value="<?php echo $k; ?>"  onclick="pres_Individual_chk(<?php echo $k ?>)" ></td>

                    </tr>
                <?php } ?>
            </table>
            </div>
            <button style="margin:auto;margin-top:10px;" class="srch-btn" value="invite" name="submit">Invite for joining</button>
            </form>
        
    </div>
    <script>
        var class_id = document.getElementById("class");
        var sub_id = document.getElementById("subject");
        function chk(){
            window.location.href="t_student_list.php?class="+class_id.value+"&sub="+sub_id.value;
        }

        function show()
        {
            console.log("!!!");
            document.getElementById('dropLinks').style.visibility="visible";
        }
        function hide()
        {
            document.getElementById('dropLinks').style.visibility="hidden"; 
        }
    </script>
    
</body>
</html>
