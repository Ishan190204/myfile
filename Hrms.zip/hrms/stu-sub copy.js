    
  const elem=document.getElementById('student_id').cloneNode(true);
  const ogg=elem.options;
  console.log(ogg);
  document.getElementById('student_id').innerHTML='<option value=""> Please Select a Class</option>';
  function class_check(vall){
    document.getElementById('student_id').innerHTML='<option value=""> Please Select a student </option>';
    
    for(let j of ogg)
    {
      if(j.dataset)
       console.log(j.dataset.value);
       if(j.dataset.value===vall) {
          document.getElementById('student_id').innerHTML+=`<option value="${j.value}"> ${j.dataset.subb}</option>`; 
       }
    }
  }
  
  
  

  const el=document.getElementById('teacher_id').cloneNode(true);
  const ogg1=el.options;
  console.log(ogg1);
  
  document.getElementById('teacher_id').innerHTML='<option value=""> Please Select a Class and subject</option>';
  function teac_chk(val){
    document.getElementById('teacher_id').innerHTML='<option value=""> Please Select a teacher </option>';
    var cid1=document.getElementById('class_id').value;
    console.log(cid1);
    if(document.getElementById('cl_id').value!=""){
      cid1=document.getElementById('cl_id').value;
    }
    
    for(let i of ogg1)
    {
      if(i.dataset){

      console.log(i.dataset.value);
      console.log(i.dataset.cid);
      }
       if(i.dataset.value===val && i.dataset.cid===cid1) {
          document.getElementById('teacher_id').innerHTML+=`<option value="${i.value}"> ${i.dataset.subb}</option>`; 
       }
    }
  }

function date_chk(val)
{
  for(let j of ogg)
    {
      if(j.value===val){
       console.log(j.dataset.date);
      let dt=j.dataset.date;
      console.log(dt);
      const d = new Date(dt);
      let date = d.toISOString().substring(0,10);
      console.log(date);
      document.getElementById("date").min = date;
      }
    }
}

function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}