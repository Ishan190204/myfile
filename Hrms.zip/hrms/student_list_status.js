var class_id = document.getElementById("class");

function cls_chk(){
    window.location.href="student_list_status.php?class="+class_id.value;
}

function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}