<?php 
    include("conn.php");
    session_start();
    $name2=$_SESSION['name'];
    
    $tid=$_SESSION['user_id'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name2) || empty($tid))
    {
       @header("Location: index.php");
       exit();
    }
    
    if(!empty('date') && !empty('slot'))
    {
        $slot=$_REQUEST['slot'];

        $date=$_REQUEST['date'];
        $attn_edit=mysqli_query($conn,"SELECT * from `attendence` inner join `student_master` on `attendence`.`student_id`=`student_master`.`student_id` inner join `class_master` on `attendence`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `attendence`.`subject_id`=`subject_master`.`subject_id` where `attendence`.`date`='$date' and `attendence`.`slot`='$slot' and `student_master`.`status`='Active' and `attendence`.`teacher_id`='$tid'");
        
    }
   
   
    if(!empty($_REQUEST['mode'])){       
            $student_name=$_REQUEST['student_name'];
            $class_name=$_REQUEST['class_name'];
            $subject_name=$_REQUEST['subject_name'];
            $class_id=$_REQUEST['class_id'];
            $subject_id=$_REQUEST['subject_id'];
            $remarks=$_REQUEST['remarks'];
            $topic_covered=$_REQUEST['topic_covered'];
            $stud_id=$_REQUEST['student_id'];
            if(!empty($_REQUEST['present'])){
                $present=$_REQUEST['present'];
            }
            if(!empty($_REQUEST['absent'])){
                $absent=$_REQUEST['absent'];
            }
            
        
            $index=0;
            $ind=0;
              foreach( $student_name as $key => $n ) {
                $pres="N";
                if(isset($present[$index])&&($present[$index])==($key+1)){
                    $pres="Y";
                    $index++;
                }    
                $abs="N";
                if(isset($absent[$ind])&&($absent[$ind])==($key+1)){
                    $abs="Y";
                    $ind++;
                }
                if($pres==='N' && $abs==='N')
                {
                   continue;
                }
                else
                {                      
                $sql_edit= "UPDATE  `attendence` SET 
                            `remarks`= '$remarks[$key]',
                            `topic_covered`= '$topic_covered[$key]',
                            `present`='$pres',
                             `absent`='$abs',
                             `month`='$month_str',
                             `year`='$year'  
                             where `student_id`= '$stud_id[$key]' and `teacher_id`= '$tid' and `class_id`='$class_id[$key]' and `subject_id`='$subject_id[$key]'";  
                $ts_edit=mysqli_query($conn, $sql_edit);
            }
          }
            if($ts_edit){
                @header(header: "Location:attendence_list.php");
		      exit();  		
            }      

   
}
$k=0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendence Edit</title>
    
    <link rel="stylesheet" href="t_student_list.css">
    <link rel="stylesheet" href="attendence_form.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
<div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Teacher Dashboard</div>
</div>
    <div class="nav">
        <div class="subNavs"><a href="teacher_dashboard.php">Home</a></div>
        <div class="subNavs"><a href="t_change_pass.php">Change Password</a></div>
        <div class="subNavs"><a href="t_timetable.php">Time table</a></div>
        <!-- <div class="subNavs"><a href="t_task_list.php">Task List</a></div> -->
        <!-- <div class="subNavs"><a href="t_student_list.php">Student List</a></div> -->
        <!-- <div class="subNavs"><a href="t_attendence_table.php">Attendence Table</a></div> -->
        <!-- <div class="subNavs"><a href="attendence_list.php">Attendence List</a></div> -->
        <div class="dropdown" style="width: 14.8vw;padding-top:8px;">
            <button class="dropbtn" id="list">Attendence-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_attendence_table.php">Attendence Table</a>
                <a href="attendence_list.php">Attendence List</a>
            </div>
        </div>
        <div class="dropdown" style="width: 14vw;padding-top:8px;">
            <button class="dropbtn" id="list">List-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_task_list.php">Task List</a>
                <a href="t_student_list.php">Student List</a>
            </div>
        </div>
    </div>
    <div class="welcome">
        <div><h2>Welcome <?php echo $name2 ?></h2></div> 
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
        
</div>
 
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="teacher_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="t_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="t_task_list.php">Task List</a></div>
        <div class="dropbtn"><a href="t_student_list.php">Student List</a></div>
        <div class="dropbtn"><a href="t_attendence_table.php">Attendence Table</a></div>
        <div class="dropbtn"><a href="attendence_list.php">Attendence List</a></div>
        <div class="dropbtn"><a href="t_timetable.php">Time table</a></div>
    </div>
</div>     <div class="container">
        <p align="center">Attendence Edit</p>
        
       
            <form class="subform"  action="" name="attendenceform" id="attendenceform" method="post" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1" />                    
                <div align="center" style="margin-bottom:40px;">
                <h2>Date:<?php echo $date; ?> </h2>
                <h2>Slot No.-<?php echo $slot; ?></h2>                       
        </div>
            <table border="1" align="center">
                <tr>
                    
                    <th>Id</th>
                    <th>Present<input type="checkbox" id="pres"  name="present" onclick="pres_chk(this)" ></th>
                    <th>Absent<input type="checkbox" id="abs"  name="absent" onclick="abs_chk(this)" ></th>
                    <th>Student Name</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Remarks</th>
                    <th>Topic Covered<input type="checkbox" id="tpcheck" name="tpcheck" onclick="topic_chk(this)" ></th>
                    
                </tr>
                <?php  while($arr=mysqli_fetch_array($attn_edit)){?> 
                <tr>
                    
                    <td><?php echo ++$k ?></td>
                     <td><input type="checkbox" name="present[]" value="<?php echo $k; ?>" <?php if(!empty($arr['present']) && $arr['present']==='Y'){ ?> checked <?php } ?> onclick="pres_Individual_chk(<?php echo $k ?>)" ></td>
                    <td><input type="checkbox" name="absent[]" value="<?php echo $k; ?>" <?php if(!empty($arr['absent']) && $arr['absent']==='Y'){ ?> checked <?php } ?> onclick="abs_Individual_chk(<?php echo $k ?>)" ></td>
                    <td><input type="hidden" name="student_id[]" value="<?php echo $arr['student_id']; ?>" ><input type="text" name="student_name[]" value="<?php echo $arr['student_name']; ?>"  readonly></td>
                    <td><input type="hidden" name="class_id[]" value="<?php echo $arr['class_id']; ?>" ><input type="text" name="class_name[]" value="<?php echo $arr['class_name'];  ?>"  readonly></td>
                    <td><input type="hidden" name="subject_id[]" value="<?php echo $arr['subject_id']; ?>" ><input type="text" name="subject_name[]" value="<?php echo $arr['subject_name'];  ?>"  readonly></td>
                    <td><textarea name="remarks[]" class="areatext"><?php if(!empty($arr['remarks'])){ echo $arr['remarks'];} ?></textarea></td>
                    <td><textarea name="topic_covered[]" class="areatext"><?php if(!empty($arr['topic_covered'])){ echo $arr['topic_covered'];} ?></textarea></td>
                    
                </tr>
                
                <?php } ?>
                
            </table>
            <input type="submit" style="margin:auto;margin-top:10px;" value="Edit" class="srch-btn" >
                        </form>
        </div>
    </div>
    <script src="t_attendence_table.js"></script>
</body>
</html>
