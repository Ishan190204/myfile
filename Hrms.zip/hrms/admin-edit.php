<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION['usname'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name1))
    {
      @header("Location: index.php");
      exit();
    }
    $tskid=$_REQUEST['taskid'];
   
    $fetch_userdesctype ="SELECT * FROM `task_assign` INNER JOIN `staff_registration_master` on `task_assign`.`user_id`= `staff_registration_master`.`user_id` where `task_id`='$tskid'"  ;
    $user_desct1=mysqli_query($conn,$fetch_userdesctype);
    $row=mysqli_fetch_array($user_desct1);

   
    
    if(!empty($_REQUEST['mode']))
    {  
        $res_task_description = $_REQUEST['task_description'] ;
        $res_task_assign_date = $_REQUEST['task_assign_date'] ;
        $res_start_date = $_REQUEST['start_date'] ;
        $res_end_date = $_REQUEST['end_date'] ;
        $res_priority = $_REQUEST['priority'] ;
        $res_actualstart_date = $_REQUEST['actual_start_date'] ;
        $res_actualend_date = $_REQUEST['actual_end_date'] ;
        
        $date1=date_create($res_end_date);
            $date2=date_create($res_actualend_date);
            $diff=date_diff($date1,$date2);
            $delay= $diff->format("%R%a");
    
        if($delay < 0){
            $delay="0";
        }
      
      $sql_task="UPDATE  `task_assign` SET `actual_start_date`='$res_actualstart_date',
                                           `actual_end_date`='$res_actualend_date',
                                           `task_description`='$res_task_description',
                                           `task_assign_date`='$res_task_assign_date',
                                           `start_date`='$res_start_date',
                                           `end_date`='$res_end_date',
                                           `priority`='$res_priority' ,
                                           `delay`=$delay    
                                            where `task_id`='$tskid'"  ;
    $user_desct1=mysqli_query($conn,$fetch_userdesctype);
      $task_assn=mysqli_query($conn, $sql_task);
      
      if($task_assn)
        {
          @header("Location: Task-status.php?msg=Successfull edited");
		      exit(); 

        }
    }

?> 

<!DOCTYPE html>
<html>
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Task-Assignment</title>
        <link rel="stylesheet" href="admin-edit.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>    


        <div style="height: 200px;"></div>
        <div class="superContainer">
            <div class="container">
                <div class="heading">Task-Assigned <br>Form</div>
                <form class="form" enctype="multipart/form-data" method="post" name="loginform" id="loginform" onSubmit="return checking();">
                    <input type="hidden" name="mode" value="1">
                    <div class="inputContainer">
                        <label>User-Description</label>
                        <input type="text" class="inputSelect" name="user_type" id="user_type" value="<?php  echo $row['user_type'] ?>" readonly>
                    </div> 
                    <div class="inputContainer">
                        <label for="user_id">Name</label>
                        <input type="text" class="inputSelect" name="user_id" id="user_id" value="<?php echo $row['name'] ?>" readonly >
                    </div> 
                    <div class="inputContainer">
                        <label>Task-Description</label><input type="text" class="inputField" placeholder="Task-Description" name="task_description" id="task_description" value="<?php echo $row['task_description'] ?>" <?php if($row['task_status']=='Completed'|| $row['status']==='Inactive'){ ?> readonly  <?php } ?>>
                    </div>
                    <div class="inputContainer">
                        <label>Task-Assign Date</label><input type="date" class="inputField" name="task_assign_date" id="task_assign_date" min="<?php echo $row['task_assign_date'] ?>" value="<?php echo $row['task_assign_date'] ?>"<?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> readonly  <?php } ?> >
                    </div>
                    <div class="inputContainer">
                        <label>Start Date</label><input type="date" class="inputField" name="start_date" id="start_date" min="<?php echo $row['task_assign_date'] ?>" value="<?php echo $row['start_date'] ?>"<?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> readonly  <?php } ?> >
                    </div>
                    <div class="inputContainer">
                        <label>End Date</label><input type="date" class="inputField" name="end_date" id="end_date" min="<?php echo $row['task_assign_date'] ?>" value="<?php echo $row['end_date'] ?>" <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> readonly  <?php } ?>>
                    </div>
                    <div class="inputContainer">
                        <label>Actual Start Date *</label><input type="date" class="inputField" name="actual_start_date" id="actual_start_date" min="<?php echo $row['task_assign_date'] ?>" value="<?php  echo $row['actual_start_date'] ?>" <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> readonly  <?php } ?>>
                    </div>
                    <div class="inputContainer">
                        <label>Actual End Date *</label><input type="date" class="inputField" name="actual_end_date" id="actual_end_date" min="<?php echo $row['task_assign_date'] ?>" value="<?php echo $row['actual_end_date'] ?>" <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> readonly <?php } ?>>
                    </div>
                    <div class="inputContainer">
                        <label>Priority</label>
                        <select class="inputSelect" name="priority" id="priority" >
                        <option value="1" <?php if($row['priority']==='1') echo "selected" ?> <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> disabled <?php } ?>>High</option>
                        <option value="2" <?php if($row['priority']==='2') echo "selected" ?> <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> disabled <?php } ?>>Medium</option>
                        <option value="3" <?php if($row['priority']==='3') echo "selected" ?> <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> disabled <?php } ?>>Low</option>
                        </select>   
                                            </div>
                    <div class="inputContainer" <?php if($row['pdf']==''){ ?> style=" display: none;"  <?php } ?>>
                        <label>Attachment</label>
                     <a href="pdf_file/<?php echo $row['pdf']?>" id="link" style="text-decoration: none; color: black;font-weight: bold;"><i class="fa-solid fa-paperclip"></i></a>                
                    </div> 
                    <div class="gap"></div> 
                <input type="submit" class="assign-btn" value="Edit" <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> style="display: none;" <?php } ?>>
                </form>
            </div>
        </div>
        <script src="task-assign.js"></script>
        <script>
            
            </script>
    </body>
</html>