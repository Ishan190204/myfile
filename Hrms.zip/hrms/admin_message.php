<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
    if(empty($name1))
    {
       @header("Location: index.php");
       exit();
    }
    $cur_mon=date("m",strtotime(date("Y-m-d")));
    $pre_mon=$cur_mon - 1;
    $cur_month_str= date("F", mktime(0, 0, 0,$cur_mon, 1));
    $pre_month_str= date("F", mktime(0, 0, 0,$pre_mon, 1));
    $cur_year=date("Y");
   
    $fetch_teacher="SELECT * from `staff_registration_master` where `user_type`='Te' and `user_status`='Yes' ";
    $ft_res=mysqli_query($conn,$fetch_teacher);
$k=0;
if(isset($_REQUEST['tch']))
    {
        $tch_id = $_REQUEST['tch'];
        $search=$_REQUEST['search']; 
        if(empty($search)) {
            $fetch_teacher1="SELECT `staff_registration_master`.`name`,`class_master`.`class_name`,`subject_master`.`subject_name`,`student_master`.`student_name`,`link`.`link`,`link`.`date` FROM `link_teacher_student` inner join `link` on `link_teacher_student`.`link_id`=`link`.`link_id` inner join `staff_registration_master` on `link_teacher_student`.`teacher_id`=`staff_registration_master`.`user_id` inner join `student_master` on `link_teacher_student`.`student_id`=`student_master`.`student_id` inner join `subject_master` on `link_teacher_student`.`subject_id`=`subject_master`.`subject_id` inner join `class_master` on `student_master`.`student_class`=`class_master`.`class_id` where `link_teacher_student`.`teacher_id`='$tch_id' and `link`.`month`='$cur_month_str' ";
            $ft_res1=mysqli_query($conn,$fetch_teacher1);
        } 
        else
        {
             
            $fetch_teacher1="SELECT `staff_registration_master`.`name`,`class_master`.`class_name`,`subject_master`.`subject_name`,`student_master`.`student_name`,`link`.`link`,`link`.`date` FROM `link_teacher_student` inner join `link` on `link_teacher_student`.`link_id`=`link`.`link_id` inner join `staff_registration_master` on `link_teacher_student`.`teacher_id`=`staff_registration_master`.`user_id` inner join `student_master` on `link_teacher_student`.`student_id`=`student_master`.`student_id` inner join `subject_master` on `link_teacher_student`.`subject_id`=`subject_master`.`subject_id` inner join `class_master` on `student_master`.`student_class`=`class_master`.`class_id` where `link_teacher_student`.`teacher_id`='$tch_id' and `link`.`month`='$search' ";
        $ft_res1=mysqli_query($conn,$fetch_teacher1);
        }
         }
    else
    {
        
       $fetch_teacher1="SELECT `staff_registration_master`.`name`,`class_master`.`class_name`,`subject_master`.`subject_name`,`student_master`.`student_name`,`link`.`link`,`link`.`date` FROM `link_teacher_student` inner join `link` on `link_teacher_student`.`link_id`=`link`.`link_id` inner join `staff_registration_master` on `link_teacher_student`.`teacher_id`=`staff_registration_master`.`user_id` inner join `student_master` on `link_teacher_student`.`student_id`=`student_master`.`student_id` inner join `subject_master` on `link_teacher_student`.`subject_id`=`subject_master`.`subject_id` inner join `class_master` on `student_master`.`student_class`=`class_master`.`class_id` where `link`.`month`='$cur_month_str'";
       $ft_res1=mysqli_query($conn,$fetch_teacher1);
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Message</title>
    <link rel="stylesheet" href="admin_attendence.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>  

<div class="container">
        <p align="center">Message/Link</p>
        <div style="gap:10px" align="center">      
        <select class="inputSelect" name="teacher" id="teacher" onchange="teacher_chk()">
                            <option value="">Select Teacher</option>
                            <?php while($row=mysqli_fetch_array($ft_res)){ ?>
                                <option value="<?php echo $row['user_id'] ?>" <?php if(!empty($tch_id) && $tch_id==$row['user_id']) echo "selected" ;?>><?php echo $row['name'] ?></option>
                                    <?php } ?>
                        </select>
        
            
            
               
                   <label>Filter By:</label>
                    <select id="sel" class="inputSelect"  onchange="teacher_chk()">
                        <option value="January" <?php if(!empty($search) && $search==='January'){ ?> selected <?php } if(empty($search) && $cur_month_str=='January') { echo "selected"; } ?>>January</option>
                        <option value="February" <?php if(!empty($search) && $search==='February'){ ?> selected <?php } if(empty($search) && $cur_month_str=='February') { echo "selected"; } ?>>February</option>
                        <option value="March" <?php if(!empty($search) && $search==='March'){ ?> selected <?php } if(empty($search) && $cur_month_str=='March') { echo "selected"; } ?>>March</option>
                        <option value="April" <?php if(!empty($search) && $search==='April'){ ?> selected <?php } if(empty($search) && $cur_month_str=='April') { echo "selected"; } ?>>April</option>
                        <option value="May" <?php if(!empty($search) && $search==='May'){ ?> selected <?php } if(empty($search) && $cur_month_str=='May') { echo "selected"; } ?>>May</option>
                        <option value="June" <?php if(!empty($search) && $search==='June'){ ?> selected <?php } if(empty($search) && $cur_month_str=='June') { echo "selected"; } ?>>June</option>
                        <option value="July" <?php if(!empty($search) && $search==='July'){ ?> selected <?php } if(empty($search) && $cur_month_str=='July') { echo "selected"; } ?>>July</option>
                        <option value="August" <?php if(!empty($search) && $search==='August'){ ?> selected <?php } if(empty($search) && $cur_month_str=='August') { echo "selected"; } ?> >August</option>
                        <option value="September" <?php if(!empty($search) && $search==='September') { ?> selected <?php } if(empty($search) && $cur_month_str=='September') { echo "selected"; } ?>>September</option>
                        <option value="October" <?php if(!empty($search) && $search==='October'){ ?> selected <?php } if(empty($search) && $cur_month_str=='October') { echo "selected"; } ?>>October</option>
                        <option value="November" <?php if(!empty($search) && $search==='November'){ ?> selected <?php } if(empty($search) && $cur_month_str=='November') { echo "selected"; } ?>>November</option>
                        <option value="December" <?php if(!empty($search) && $search==='December'){ ?> selected <?php } if(empty($search) && $cur_month_str=='December') { echo "selected"; } ?>>December</option>
                    </select>
                    <br> <br>          
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>Sl No.</th>
                    <th>Teacher Name</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Student Name</th>
                    <th>Date</th>
                    <th>Message/Link</th>
                </tr>
                <?php while($arr=mysqli_fetch_array($ft_res1)){?> 
                <tr>
                    <td><?php echo ++$k ;  ?></td>
                    <td><?php echo $arr['name'];  ?></td>
                    <td><?php echo $arr['class_name'];  ?></td>
                    <td><?php echo $arr['subject_name'];  ?></td>
                    <td><?php echo $arr['student_name'];  ?></td>
                    <td><?php echo $arr['date'];  ?></td>
                    <td><a href="<?php echo $arr['link'];  ?>"><?php echo $arr['link'];  ?></a></td>
                </tr>
                <?php } ?>
                
            </table>
            </div>
        </div>
    </div>
    <script  src="admin_message.js">
    </script>
</body>
</html>
