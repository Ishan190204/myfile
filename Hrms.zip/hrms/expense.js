const elem=document.getElementById('user_id').cloneNode(true);
const ogg=elem.options;
document.getElementById('user_id').innerHTML='<option value="">Select a usertype</option>';
function user_typechk(vall){
    document.getElementById('user_id').innerHTML='<option value="">Select user</option>';

    for(let j of ogg)
    {
    if(j.dataset)
    console.log(j.dataset.value)
    if(j.dataset.value===vall)
    document.getElementById('user_id').innerHTML+=`<option value="${j.value}"> ${j.dataset.subb}</option>`; 
    }
}

function exp_cat(val){
    if(val === "others"){
        document.getElementById("remove").style.display= "none";
        document.getElementById("remove1").style.display= "none";
        document.getElementById("remove2").style.display= "";
    }
    else{
        document.getElementById("remove").style.display= "";
        document.getElementById("remove1").style.display= "";
        document.getElementById("remove2").style.display= "none";

    }
}
function payment(value){
    if(value === "upi" || value === "neft" || value === "cheque"){
        document.getElementById("transac_id").style.display= "";
    }
    else{
        document.getElementById("transac_id").style.display= "none";
    }
}
function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}