<?php 
    include("conn.php");
    session_start();
    $name=$_SESSION['name'];
    $leave_request_id=$_REQUEST['leave_request_id'];
    $approve_table=mysqli_query($conn,"UPDATE `leave_request` SET `status`='Approved' where `leave_request_id`='$leave_request_id'");
   
    $leave_table=mysqli_query($conn,"SELECT * FROM `leave_request`  INNER JOIN `leave_master` on `leave_request`.`leave_id`= `leave_master`.`leave_id` where `leave_request_id`='$leave_request_id'");
    $row=mysqli_fetch_array($leave_table);
    $leave_id=$row['leave_id'];
    $user_id=$row['user_id'];
    $map_table=mysqli_query($conn,"SELECT * FROM `staff_leave_mapping` where `leave_id`='$leave_id' and `user_id`='$user_id' ");
    $row1=mysqli_fetch_array($map_table);
   
    if(!empty($row1)){
        $staff_leave_id =$row1['staff_leave_id'];
        $left_leave_balance=$row1['left_leave_balance']-$row['duration'];
        $update="UPDATE `staff_leave_mapping` SET `left_leave_balance`='$left_leave_balance' where `staff_leave_id`='$staff_leave_id' ";
        $res=mysqli_query($conn,$update);
      if($res)
        {
          @header("Location:leave-approve.php?msg=Approved edited ");
		      exit(); 

        }
    }
    else{
    $total_leave_balance=$row['no_of_leaves'];
    $left_leave_balance=$total_leave_balance-$row['duration'];

    $insert="INSERT INTO `staff_leave_mapping` SET
                `leave_id`='$leave_id' ,
                `user_id`= '$user_id',
                `total_leave_balance`= '$total_leave_balance',
                `left_leave_balance`= '$left_leave_balance'";  
      $lev=mysqli_query($conn, $insert);
      
      if($lev)
        {
          @header("Location:leave-approve.php?msg=Approved ");
		      exit(); 

        }
    }
    ?>