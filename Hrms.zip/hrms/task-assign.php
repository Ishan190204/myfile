<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name1))
    {
       @header("Location: index.php");
       exit();
    }   
      if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
      else
        {   
          $mspg  = ""; 
        } 
      
    $fetch_userdesctype ="SELECT `user_type` from `staff_registration_master`  group by `user_type`"  ;
    $user_desct1=mysqli_query($conn,$fetch_userdesctype);

    $fetch_userdescr="SELECT `name`,`user_id`,`user_type` from `staff_registration_master` where `user_status`='Yes' order by `user_id`";
    $user_descrp=mysqli_query($conn,$fetch_userdescr);
    if(!empty($_REQUEST['mode']))
    {  
        $res_userid = $_REQUEST['user_id'];
        $res_user_desc = $_REQUEST['user_type'];
        $res_task_description = $_REQUEST['task_description'];
        $res_task_assign_date = $_REQUEST['task_assign_date'];
        $res_start_date = $_REQUEST['start_date'];
        $res_end_date = $_REQUEST['end_date'];
        $res_actualstart_date = $res_start_date ;
        $res_actualend_date = $res_end_date ;
        $res_priority = $_REQUEST['priority'];
        $uploadpdf="pdf_file/";
        if (isset($_FILES['pdf']['name']))
            {
            $file_name = $_FILES['pdf']['name'];
            $file_tmp = $_FILES['pdf']['tmp_name'];
            @move_uploaded_file($file_tmp,$uploadpdf.$file_name);
            }
      
      $sql_task="INSERT INTO `task_assign` SET 
                `user_id`= '$res_userid',
                `user_type`= '$res_user_desc',
                `task_description`= '$res_task_description',
                `task_assign_date`= '$res_task_assign_date',
                `start_date`= '$res_start_date',
                `end_date`= '$res_end_date',
                `actual_start_date`= '$res_start_date',
                `actual_end_date`= '$res_end_date',
                `delay`= '0',
                `priority`= '$res_priority',
                `pdf`= '$file_name',
                `status`='Active',
                `task_status`='Assigned' ";  
      $task_assn=mysqli_query($conn, $sql_task);
      
      if($task_assn)
        {
          @header("Location: task-assign.php?msg=Task Assigned ");
		      exit(); 

        }
    }

?> 

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Task-Assignment</title>
        <link rel="stylesheet" href="task-assign.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
       
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div> 
  <div style="height:110px;"></div>
  <h4 align="center" style="color:red;font-weight:bold;"><?php echo $mspg ?></h4>  
       <div class="superContainer">
            <div class="container">
                <div class="heading">Task-Assignment <br>Form</div>
                <form class="form" enctype="multipart/form-data" method="post" name="task_assn_form" id="task_assn_form" onSubmit="return checking();">
                    <input type="hidden" name="mode" value="1">
                    <div class="inputContainer">
                        <label>User-Description</label>
                        <select class="inputSelect" name="user_type" id="user_type" onchange="user_typechk(this.value)">
                            <option value="">Select User-Description type</option>
                            <?php while($row1=mysqli_fetch_array($user_desct1)){ ?>
                                <option value="<?php echo $row1['user_type'] ?>"><?php echo $row1['user_type'] ?></option>
                                    <?php } ?>
                        </select>
                    </div> 
                    <div class="inputContainer">
                        <label for="user_id">Name</label>
                        <select class="inputSelect" name="user_id" id="user_id" >
                            <option value="">Name</option>
                            <?php while($row2=mysqli_fetch_array($user_descrp)){ ?>
                            <option value="<?php echo $row2['user_id'] ?>" data-value="<?php echo $row2['user_type'] ?>" data-subb="<?php echo $row2['name'] ?>" ><?php echo $row2['name'] ;?></option>
                                    <?php } ?>
                        </select>
                    </div> 
                    <div class="inputContainer">
                        <label>Task-Description</label><input type="text" class="inputField" placeholder="Task-Description" name="task_description" id="task_description">
                    </div>
                    <div class="inputContainer">
                        <label>Task-Assign Date</label><input type="date" class="inputField" name="task_assign_date" id="task_assign_date" value="<?php echo date("Y-m-d")?>" min="<?php echo date("Y-m-d")?>">
                    </div>
                    <div class="inputContainer">
                        <label>Start Date</label><input type="date" class="inputField" name="start_date" id="start_date" value="<?php echo date("Y-m-d")?>" min="<?php echo date("Y-m-d")?>">
                    </div>
                    <div class="inputContainer">
                        <label>End Date</label><input type="date" class="inputField" name="end_date" id="end_date" min="<?php echo date("Y-m-d")?>">
                    </div>
                    <div class="inputContainer">
                        <label>Priority</label>
                        <select class="inputSelect" name="priority" id="priority">
                            <option value="">Priority</option>
                            <option value="1" >High</option>
                            <option value="2">Medium</option>
                            <option value="3">Low</option>
                        </select>
                    </div> 
                    <div class="inputContainer">
                        <label>Task Upload</label>
                        <input type="file" id="getfile" name="pdf"  class="inputField">
                    </div>
                 
                    <div class="gap"></div> 
                <input type="submit" class="assign-btn" value="Assign">
                </form>
            </div>
        </div>
        <script src="task-assign.js"></script>

    </body>
</html>