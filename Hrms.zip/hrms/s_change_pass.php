<?php 
    include("conn.php");
    session_start();
    $sid=$_SESSION["student_id"] ;
    $sname=$_SESSION['student_name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($sname) || empty($sid))
    {
       @header("Location: index.php");
       exit();
    }
    if(!empty($_REQUEST['msg']))
    {  
      $mspg = $_REQUEST['msg'];  
    } 
else
    {   
      $mspg  = ""; 
    }     
    $result = mysqli_query($conn, "SELECT * FROM `student_master` WHERE `student_id` = '$sid'");
    $row=mysqli_fetch_array($result);
    $pass = $row['password'];
    if(!empty($_REQUEST['mode']))
    {
        $newpass = $_REQUEST['change_pass'];
        if($newpass!== $pass)
        {
            mysqli_query($conn, "UPDATE `student_master` SET `password` = '$newpass' WHERE `student_id` = '$sid'");
            $mspg = "Password Changed Successfully!";
            @header("Location: s_change_pass.php?msg=Password Changed Successfully!");
            exit();
        }
        else
        {
            $mspg = "Please Give New Password";
            @header("Location: s_change_pass.php?msg=Please Give New Password!");
            exit();
        }
 
    }
    ?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="s_change_pass.css">
    <link rel="stylesheet" href="user_dashboard.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Student Change Password</title>
</head>
<body>
<div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
    <div class="nav">
        <div class="subNavs"><a href="student_dashboard.php">Home</a></div>
        <div class="subNavs"><a href="s_change_pass.php">Change Password</a></div>
        <div class="subNavs"><a href="s_timetable.php">Time table</a></div>
        <div class="subNavs"><a href="subject_list.php">Subject List</a></div>
    </div>
    <div class="welcome">
        <div><h2>Welcome <?php echo $sname ?></h2> </div>
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
</div> 
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="student_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="s_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="s_timetable.php">Time table</a></div>
        <div class="dropbtn"><a href="subject_list.php">Subject List</a></div>
    </div>
</div>
<div class="field">
            <div class="subfield">
                <form action="" class="field-form" name="changeform" id="changeform" method="post" onSubmit="return passchecking();">
                <input type="hidden" name="mode" value="1" />
                    <div><p align="center">Change Password</p></div>
                    <div class="Inputs"><label>New Password:</label>
                    <input type="text" class="inputField" name="change_pass" id="change_pass" ></div>
                    <div class="sub-btn"><input type="submit"></div>
                    <div><p align="center"><?php echo $mspg;?></p></div> 
                </form>
            </div>
       </div>

</body>
<script src="s_change_pass.js"></script>
 </html>       