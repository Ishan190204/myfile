var tch_id = document.getElementById("teacher");
var sel=document.getElementById("sel");
function teacher_chk(){
    window.location.href="admin_message.php?tch="+tch_id.value+"&search="+sel.value;
}


function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}