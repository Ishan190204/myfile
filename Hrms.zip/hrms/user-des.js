function userdescchecking()
{
    
if(document.getElementById('user_description_name').value=='')
        {
            alert('please enter username!');
            document.user_description_name.user_description_name.focus();
            return false;
        }	


}
function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}

function userdescname_chk(vall) {
    let val=vall.substring(0, 2);
    let val1=val[0].toUpperCase() + val.slice(1)
    document.getElementById("demo").innerHTML =val1;
}