<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
    
      if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
      else
        {   
          $mspg  = ""; 
        } 
      
    $fetch_userdesctype ="SELECT `user_description` from `staff_registration_master`  group by `user_description`"  ;
    $user_desct1=mysqli_query($conn,$fetch_userdesctype);

    $fetch_userdescr="SELECT `name`,`user_id`,`user_description` from `staff_registration_master` where `user_status`='Yes' order by `user_id`";
    $user_descrp=mysqli_query($conn,$fetch_userdescr);
    if(!empty($_REQUEST['mode']))
    {  
        $res_expense_category = $_REQUEST['expense_category'];
        if($res_expense_category==='others'){
            $res_user_description = 'others';
            $res_user_id = '';
        }
        else{
            $res_user_description = $_REQUEST['user_description'];
            $res_user_id = $_REQUEST['user_id'];
        }
        $res_expense_amount = $_REQUEST['expense_amount'];
        $res_expense_month = $_REQUEST['expense_month'];
        $res_expense_date = $_REQUEST['expense_date'];
        $res_mode_of_payment = $_REQUEST['mode_of_payment'];
        if($res_mode_of_payment==='cash'){
            $res_transaction_id='NA';
        }
        else{
        $res_transaction_id = $_REQUEST['transaction_id'];
        }
        $res_payment_type = $_REQUEST['payment_type'];
        $res_note = $_REQUEST['note'];
      
      $sql_task="INSERT INTO `expense_master` SET 
                `expense_category`= '$res_expense_category',
                `user_description`= '$res_user_description',
                `user_id`= '$res_user_id',
                `expense_amount`= '$res_expense_amount',
                `expense_month`= '$res_expense_month',
                `expense_date`= '$res_expense_date',
                `mode_of_payment`= '$res_mode_of_payment',
                `payment_type`= '$res_payment_type',
                `transaction_id`='$res_transaction_id',
                `amount_left`= '0',
                `note`= '$res_note'";  
      $task_assn=mysqli_query($conn, $sql_task);
      
      if($task_assn)
        {
          @header("Location: expense.php?msg=Successfully inserted ");
		      exit(); 

        }
    }

?> 

<!DOCTYPE html>
<html>
    <head>
        <title>Expense</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="expense.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>

        



<div style="height: 130px;"></div>
        <div class="expense-form">
            <!-- <div class="heading"><div class="sub-div"><p align="center">Request-Leave</p></div></div> -->
                <form action="" class="main-form" method="post" name="expense_form" id="expense_form" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1">
                    <p align="center">EXPENSE</p>                    
                    <div class="field">
                        <select class="ex-fields" name="expense_category" onchange="exp_cat(this.value)">
                            <option value="">Expense Category</option>
                            <option value="staff">Staff</option>
                            <option value="others" >Others</option>
                        </select>
                    </div>
                    <div class="field" id="remove">
                        <select class="ex-fields" name="user_description" id="user_description" onchange="user_typechk(this.value)">
                            <option value="">User-Description</option>
                            <?php while($row1=mysqli_fetch_array($user_desct1)){ ?>
                                <option value="<?php echo $row1['user_description'] ?>"><?php echo $row1['user_description'] ?></option>
                                    <?php } ?>
                        </select>
                    </div>
                    <div class="field" id="remove1">
                        <select class="ex-fields" name="user_id" id="user_id">
                            <option value="">Name</option>
                            <?php while($row2=mysqli_fetch_array($user_descrp)){ ?>
                            <option value="<?php echo $row2['user_id'] ?>" data-value="<?php echo $row2['user_description'] ?>" data-subb="<?php echo $row2['name'] ?>" ><?php echo $row2['name'] ;?></option>
                                    <?php } ?>
                        </select>
                    </div>
                    <div class="field" id="remove2" style="display:none;">
                        <input type="text" class="ex-fields" placeholder="Enter Org name" name="user_id_1" id="user_id_1">
                    </div>
                    <div class="field">
                        <input type="number" class="ex-fields" placeholder="Amount paid" name="expense_amount">
                    </div>
                    <div class="field">
                        <label class="labels">Expense-Month</label>
                        <div class="gap"></div><input type="month" value="2024-07" class="ex-fields" name="expense_month">
                    </div>
                    <div class="field">
                        <label class="labels">Expense-Date</label>
                        <div class="gap"></div><input type="date" class="ex-fields" name="expense_date">
                    </div>
                    <div class="field" >
                     <select class="ex-fields" name="mode_of_payment" onchange="payment(this.value)">
                            <option value="">Mode Of Payment</option>
                            <option value="cash">Cash</option>
                            <option value="upi">UPI</option>
                            <option value="neft">NEFT</option>
                            <option value="cheque">Cheque</option>
                        </select>
                    </div>
                    <div class="field" id="transac_id">
                        <input type="text" class="ex-fields" placeholder="Transaction ID" name="transaction_id" id="transaction_id">
                    </div>
                    <div class="field">
                        <label class=labels>Amount paid</label><div class="gap"></div>
                        <span>Fully paid</span><input type="radio" name="payment_type" class="pay-check" value="Fully Paid">
                        <span>Partially paid</span><input type="radio" name="payment_type" class="pay-check" value="Partially Paid">
                    </div>
                    <div class="field">
                        <fieldset class="text-field">
                            <legend>:Note:</legend>
                            <textarea rows="3" cols="25" class="text-area" name="note"></textarea>
                        </fieldset>
                    </div>
                    <div class="field"><input type="submit" class="submit-btn"></div>
                </form>
        </div>
        <br><br>
        <script src="expense.js"></script>
    </body>
</html>