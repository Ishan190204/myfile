<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION['usname'];
    if(!empty($_REQUEST['tid'])){
    $tid=$_REQUEST['tid'];
    $class_id=$_REQUEST['cl'];
    $subject_id=$_REQUEST['sb'];
    }
    $stud_qry=mysqli_query($conn,"SELECT * FROM `teacher_student_map` INNER JOIN `student_master` on `teacher_student_map`.`student_id`= `student_master`.`student_id`  where `teacher_student_map`.`teacher_id`='$tid' and  `teacher_student_map`.`subject_id`='$subject_id' and `teacher_student_map`.`class_id`='$class_id' and `student_master`.`status`='Active' and `teacher_student_map`.`status`='Active' ");
 
$k=0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Student List</title>
    
    <link rel="stylesheet" href="admin_student.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>
    
    </div>
    <div class="container">
        <p align="center">Student List</p>
        
            <div class="top">
                <div>
                    Show
                    <select>
                        <option value="">1</option>
                        <option value="">2</option>
                        <option value="">3</option>
                        <option value="">4</option>
                        <option value="">5</option>
                        <option value="">6</option>
                        <option value="">7</option>
                        <option value="">8</option>
                        <option value="">9</option>
                        <option value="">10</option>
                    </select>
                    entries
                </div>
                <div >
                    Search <input type="search"  id="srch" onchange="filter(this.value)" >
                </div>
            </div>
            <form class="subform"  action="" name="attendenceform" id="attendenceform" method="post" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1" />
              
            <div style="overflow-x: scroll;">
            <table border="1" align="center">
                <tr>
                    
                    <th>Id</th>
                    <th>Student Name</th>            
                </tr>
                <?php  while($arr=mysqli_fetch_array($stud_qry)){?> 
                <tr>
                    
                <td><?php echo ++$k; ?></td>
                    <td><?php echo $arr['student_name']; ?></td>
                    
                    
                </tr>
                
                <?php } ?>
                
            </table>
            </div>
              </form>
        </div>
    </div>
    <script src="attendence_form.js"></script>
    <script>
            function show()
            {
                console.log("!!!");
                document.getElementById('dropLinks').style.visibility="visible";
            }
            function hide()
            {
                document.getElementById('dropLinks').style.visibility="hidden"; 
            }
        </script>
</body>
</html>
