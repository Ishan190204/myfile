<?php
include("conn.php");
session_start();   
$st_id=$_REQUEST['st_id'];

    $sql=mysqli_query($conn,"UPDATE `student_master` set status='Inactive'  where 
        `student_id`='$st_id' ");

    $sql1=mysqli_query($conn,"UPDATE `student_subject` set status='Inactive'  where 
                            `stud_id`='$st_id'  ");
    

    $sql2=mysqli_query($conn,"UPDATE `teacher_student_map` set status='Inactive'  where 
                             `student_id`='$st_id' ");  
     

if($sql && $sql && $sql2){
    @header("Location: ".$_SERVER['HTTP_REFERER']);
}
?>