<?php 
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
    if(isset($_REQUEST['search'])){
        $search=$_REQUEST['search'];
        $task_table=mysqli_query($conn,"SELECT `task_id`,`name`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`delay`,`priority`,`task_status`,`status` FROM `task_assign` INNER JOIN `staff_registration_master` on `task_assign`.`user_id`= `staff_registration_master`.`user_id` where `name` like '%$search%'or`task_description` like '%$search%'or`task_assign_date` like '%$search%'or `start_date` like '%$search%'or `end_date` like '%$search%'or `delay` like '%$search%'or `priority` like '%$search%'or `task_status` like '%$search%'or `status`like '%$search%' order by `start_date`,`priority`");
 
    }
    else{
        $search="";
    
    if(isset($_REQUEST['status'])){
        $status=$_REQUEST['status'];
        if($status==='Assigned'){
            $task_table=mysqli_query($conn,"SELECT `task_id`,`name`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`delay`,`priority`,`task_status`,`status` FROM `task_assign` INNER JOIN `staff_registration_master` on `task_assign`.`user_id`= `staff_registration_master`.`user_id` where `task_status`='$status' order by `start_date`,`priority`");

        }
        elseif($status==='Completed'){
            $task_table=mysqli_query($conn,"SELECT `task_id`,`name`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`delay`,`priority`,`task_status`,`status` FROM `task_assign` INNER JOIN `staff_registration_master` on `task_assign`.`user_id`= `staff_registration_master`.`user_id` where `task_status`='$status' order by `start_date`,`priority`");

        }
        elseif($status==='In progress'){
            $task_table=mysqli_query($conn,"SELECT `task_id`,`name`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`delay`,`priority`,`task_status`,`status` FROM `task_assign` INNER JOIN `staff_registration_master` on `task_assign`.`user_id`= `staff_registration_master`.`user_id` where `task_status`='$status' order by `start_date`,`priority`");
        }
    }
    else{
        $task_table=mysqli_query($conn,"SELECT `task_id`,`name`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`delay`,`priority`,`task_status`,`status` FROM `task_assign` INNER JOIN `staff_registration_master` on `task_assign`.`user_id`= `staff_registration_master`.`user_id` order by `start_date`,`priority`");
    }
}
$k=0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Status</title>
    <link rel="stylesheet" href="Task-status.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>

    <div class="container">
        <p align="center">Task Status</p>
        <div style="display:flex;justify-content:center;gap:10px">
            <span  style="cursor:pointer;"><a href="Task-status.php">All</a></span>
            <span  style="cursor:pointer;"><a href="Task-status.php?status=Assigned">Assigned</a></span>
            <span  style="cursor:pointer;"><a href="Task-status.php?status=Completed">Completed</a></span>
            <span  style="cursor:pointer;"><a href="Task-status.php?status=In progress">In progress</a></span>
        </div>
        <div>
            <div class="top">
                <div>
                   
                </div>
                <div >
                    Search <input type="search"  id="srch" onchange="filter(this.value)" >
                </div>
            </div>
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>Sl No.</th>
                    <th>Staff Name</th>
                    <th>Task Description</th>
                    <th>Assign Date</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Delay</th>
                    <th>Priority</th>
                    <th>Task Status</th>
                    <th>Status</th>
                    <th>Active/Inactive</th>
                    <th> </th>
                </tr>
                <?php  while($arr=mysqli_fetch_array($task_table)){?> 
                <tr>
                    <td><?php echo ++$k; ?></td>
                    <td><?php echo $arr['name'];  ?></td>
                    <td><?php echo $arr['task_description'];  ?></td>
                    <td><?php echo $arr['task_assign_date'];  ?></td>
                    <td><?php echo $arr['start_date'];  ?></td>
                    <td><?php echo $arr['end_date'];  ?></td>
                    <td><?php echo $arr['delay'];  ?></td>
                    <td><?php if($arr['priority']=== "1") {echo "High";} elseif($arr['priority']=== "2"){echo "Medium";} else {echo "Low";}?></td>
                    <td><?php echo $arr['task_status'] ;  ?></td>
                    <td><?php echo $arr['status'];  ?></td>
                    <td><a href="active-inactive.php?tskid=<?php echo $arr['task_id'] ?>" <?php if($arr['status']=='Active') { ?> style="color: grey;text-decoration: none; cursor: default;" onclick="return false;" <?php } ?>>Active</a> | <a href="active-inactive.php?tskid=<?php echo $arr['task_id'] ?>" <?php if($arr['status']=='Inactive') { ?> style="color: grey;text-decoration: none; cursor: default;" onclick="return false;"<?php } ?>>Inactive</td>
                    <td><?php if( $arr['task_status']==='Completed' || $arr['status']==='Inactive') { ?><button class="srch-btn"><a href="admin-edit.php?taskid=<?php echo $arr['task_id'] ?>"><i class="fa-solid fa-clipboard-check"></i></button><?php } else {?><button class="srch-btn"><a href="admin-edit.php?taskid=<?php echo $arr['task_id'] ?>"><i class="fa-solid fa-pen-to-square"></i></a></button><?php } ?></td>
                </tr>
                <?php } ?>   
            </table>
            </div>
        </div>
    </div>
    <br><br>
    <script src="admin_dashboard.js"></script>
    <script>
        function filter(val){
            window.location.href="Task-status.php?search="+val;
        }
    </script>
</body>
</html>
