<?php
    //To do admin check
    include("conn.php");
    session_start();
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
    if(isset($_REQUEST['submit']))
    {
        if(isset($_REQUEST['room-name']) && $_REQUEST['room-name'] != "")
        {
            $roomName = $_REQUEST['room-name'];
            $query = "INSERT INTO `room_master` SET `room_name` = '$roomName'";
            $res = mysqli_query($conn, $query);
            if($res)
            {
                header("Location: rooms.php");
            }
        }
    }
    if(isset($_REQUEST['update']))
    {
        if(isset($_REQUEST['room-name']) && $_REQUEST['room-name'] != "")
        {
            $roomName = $_REQUEST['room-name'];
            $roomID = (int) $_REQUEST['room-id'];
            $query = "UPDATE `room_master` SET `room_name` = '$roomName' WHERE `room_id` = '$roomID'";
            $res = mysqli_query($conn, $query);
            if($res)
            {
                header("Location: rooms.php");
            }
        }
    }
    if(isset($_REQUEST['delete']))
    {
        $roomID = (int) $_REQUEST['room-id'];
        $query = "DELETE FROM `room_master` WHERE `room_id` = '$roomID'";
        try
        {
            $res = mysqli_query($conn, $query);
            header("Location: rooms.php");
        }
        catch(Exception $e)
        {
            echo("Cannot delete room since it is used by a slot. Delete all slots related to this room first to delete this room");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <?php include("title.php"); ?>
        <link rel="stylesheet" href="style.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    

    </head>
    <body>
    <div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>
       


        <div class="container">
            <h2>Your Rooms</h2>
            <p>Add or modify your rooms here</p>
            <br>

            <div>
                <form method="POST">
                    <h3>Add Room</h3>
                    <div style="height: 8px;"></div>
                    <input class="font-12" type="text" placeholder="Enter room name" name="room-name">
                    <input class="font-12" type="submit" name="submit">
                </form>
            </div>

            <br><br>

            <div class="tableDiv">
                <h3>Available Rooms</h3>
                <div style="height: 8px;"></div>
                <table width="25%">
                    <thead>
                        <tr>
                            <td class="font-18">Room Name</td>
                            <td class="font-18">Operations</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $query = "SELECT * FROM `room_master`";
                            $res = mysqli_query($conn, $query);
                            while($ar = mysqli_fetch_array($res))
                            {
                        ?>
                        <tr>
                            <form method="POST">
                                <td>
                                    <input class="pseudo-input font-16" type="hidden" value="<?php echo $ar['room_id']; ?>" name="room-id">
                                    <input class="pseudo-input font-16" type="text" value="<?php echo $ar['room_name']; ?>" name="room-name">
                                </td>
                                <td class="flex gap-8">
                                    <input type="submit" class="srch-btn" name="update" value="Update">
                                    <input type="submit" class="srch-btn" name="delete" value="Delete">
                                </td>
                            </form>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
    <script src="admin_dashboard.js"></script>
</html>