<?php 
    include("conn.php");
    session_start();   
    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
  if(empty($name1))
  {
     @header("Location: index.php");
     exit();
  }
    $k=0;
    $flag=0;
    if(isset($_REQUEST['class']) && isset($_REQUEST['sub'])){
        $class_id=$_REQUEST['class'];
        $sub=$_REQUEST['sub'];

        $st_table=mysqli_query($conn ,"SELECT `student_master`.`student_name`,`student_master`.`student_id`,`staff_registration_master`.`name`,`teacher_student_map`.`date`,`teacher_student_map`.`status`,`teacher_student_map`.`class_id`,`teacher_student_map`.`subject_id`from   `student_master` inner join `teacher_student_map` on `student_master`.`student_id`=`teacher_student_map`.`student_id` inner join `staff_registration_master` on `staff_registration_master`.`user_id`=`teacher_student_map`.`teacher_id` where `student_master`.`status`= 'Active' and `teacher_student_map`.`status`='Active' and `teacher_student_map`.`class_id`='$class_id' and `teacher_student_map`.`subject_id`='$sub' ");
        $arr=mysqli_fetch_array($st_table);
        if(!empty($arr)){
            $flag=1;
            $st_table=mysqli_query($conn ,"SELECT `student_master`.`student_name`,`student_master`.`student_id`,`staff_registration_master`.`name`,`teacher_student_map`.`date`,`teacher_student_map`.`status`,`teacher_student_map`.`class_id`,`teacher_student_map`.`subject_id`from   `student_master` inner join `teacher_student_map` on `student_master`.`student_id`=`teacher_student_map`.`student_id` inner join `staff_registration_master` on `staff_registration_master`.`user_id`=`teacher_student_map`.`teacher_id` where `student_master`.`status`= 'Active' and `teacher_student_map`.`status`='Active' and `teacher_student_map`.`class_id`='$class_id' and `teacher_student_map`.`subject_id`='$sub' ");
 
        }
        
    }
    else{
        $class_id="";
        $sub="";
    }


$class_sql=mysqli_query($conn,"SELECT * from `class_master` where `status`='Active'");
$sub_sql=mysqli_query($conn,"SELECT * from `subject_master` where `status`='Active'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Student List</title>
    <link rel="stylesheet" href="student_status.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>


    <div class="container">
        <p align="center">Student Status</p>
        
        <div style="gap:10px" align="center">      
                        <select class="inputSelect" name="class" id="class" onchange="cls_chk()">
                            <option value="">Select Class</option>
                            <?php while($class_row=mysqli_fetch_array($class_sql)){ ?>
                                <option value="<?php echo $class_row['class_id'] ?>" <?php if(!empty($class_id) && $class_id==$class_row['class_id']) echo "selected" ;?>><?php echo $class_row['class_name'] ?></option>
                                    <?php } ?>
                        </select>
                    
                        <select class="inputSelect" name="subject" id="subject" onchange="cls_chk()">
                            <option value="">Select Subject</option>
                            <?php while($sub_row=mysqli_fetch_array($sub_sql)){ ?>
                                <option value="<?php echo $sub_row['subject_id'] ?>" <?php if(!empty($sub) && $sub==$sub_row['subject_id']) echo "selected" ;?>><?php echo $sub_row['subject_name'] ?></option>
                                    <?php } ?>
                            
                        </select>               
        </div>
        <div>
            <br>
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>Sl.No.</th>
                    <th>Student Name</th>
                    <th>Admission Date</th>
                    <th>Teacher Name</th>
                    <th>Status</th>
                    <th>Active/Inactive</th>
                </tr>
                <?php if($flag!==0){ while($arr=mysqli_fetch_array($st_table)){ ?> 
                <tr>
                    <td><?php echo ++$k;  ?></td>
                    <td><?php echo $arr['student_name'];  ?></td>
                    <td><?php echo $arr['date'];  ?></td>
                    <td><?php echo $arr['name'];  ?></td>
                    <td><?php echo $arr['status'];  ?></td>
                    <td><a href="stud_active_inactive.php?st_id=<?php echo $arr['student_id'] ?>&cl_id=<?php echo $arr['class_id'] ?>&sb_id=<?php echo $arr['subject_id'] ?>&s=<?php echo $arr['status'] ?>" <?php if($arr['status']=='Active') { ?> style="color: grey;text-decoration: none; cursor: default;" onclick="return false;" <?php } ?>>Active</a> | <a href="stud_active_inactive.php?st_id=<?php echo $arr['student_id'] ?>&cl_id=<?php echo $arr['class_id'] ?>&sb_id=<?php echo $arr['subject_id'] ?>&s=<?php echo $arr['status'] ?>" <?php if($arr['status']=='Yes') { ?>style="color: grey;text-decoration: none; cursor: default;" onclick="return false;" <?php } ?>>Inactive</td>
                    </tr>
                <?php } }
                    ?>
            </table>
            </div>
        </div>
    </div>
    <script src="student_status.js"></script>
</body>
</html>
