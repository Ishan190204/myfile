<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Home</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.css">
        <link rel="stylesheet" href="home.css">
    </head>
    <body>
        <div class="navbar">
            <div class="dashboard">
                <div class="dashlogo"><img src="images/NEW_LOGO__1___1_.png" class="logo"></div>
                <div class="dash">Shikhshaneer</div>
            </div>
            <div class="nav">
                <div class="subNavs"><a href="index.php">Home</a></div>
                <div class="subNavs"><a href="log-reg.php">Login/ Register</a></div>
                <div class="subNavs"><a href="student-log-reg.php">Student Login/Register</a></div>
            </div>  
        </div>
        <div class="drops">
            <img src="images/side-lines.svg" height="35" width="30" onclick="show()">
        </div> 
        <div id="dropLinks">
            <div class="closebtn">
                <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
            </div> 
            <div class="dropdown">
                <div class="dropbtn"><a href="index.php">Home</a></div>
                <div class="dropbtn"><a href="log-reg.php">Login/ Register</a></div>
                <div class="dropbtn"><a href="student-log-reg.php">Student Login/Register</a></div>
            </div>
        </div> 

        <div class="mainDiv">
            <div class="layout">
                <div class="semicircle"></div>
                <div class="vector">
                    <!-- <img src="images/vector_file (15).png" class="st_vect">  -->
                </div>
            </div>
            <div>
                <div class="cirlce" id="cir1"></div>
                <div class="cirlce" id="cir2"></div>
                <div class="cirlce" id="cir3"></div>
                <div class="cirlce" id="cir4"></div>
                <div class="cirlce" id="cir5"></div>
            </div>
            <div class="topText">
                <div class="para1"><div>Take the time to </div> <div align="center" style="margin-left: 100px;"> look on the bright side</div></div><br>
                <div class="para2">~Let your education expand beyond the classroom~</div>
            </div>
            <div class="space" style="height: 100px;"></div>
            <div class="footer">
                <p>&copy; 2024 DASHBOARD</p>
            </div>
        </div>
        <script src="home.js"></script>
    </body>
</html>