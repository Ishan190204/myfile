<?php 
    include("conn.php");
    session_start();
    $userid=$_SESSION["user_id"];
    $name=$_SESSION["name"];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name))
    {
       @header("Location: index.php");
       exit();
    }
    
    $tskid=$_REQUEST['taskid'];
    
    $fetch_userdesctype ="SELECT * FROM `task_assign` INNER JOIN `staff_registration_master` on `task_assign`.`user_id`= `staff_registration_master`.`user_id` where `task_id`='$tskid'"  ;
    $user_desct1=mysqli_query($conn,$fetch_userdesctype);
    $row=mysqli_fetch_array($user_desct1);

   if(isset($res_actualstart_date)){
    echo $res_actualstart_date;
   }
    
    if(!empty($_REQUEST['mode']))
    {  
       
        $res_actualstart_date = $_REQUEST['actual_start_date'] ;
        $res_actualend_date = $_REQUEST['actual_end_date'] ;
        
        $res_taststatus=$_REQUEST['task_status'];
        $end_date=$row['end_date'];
        
            $date1=date_create($end_date);
            $date2=date_create($res_actualend_date);
            $diff=date_diff($date1,$date2);
            $delay= $diff->format("%R%a");
    
        if($delay < 0){
            $delay="0";
        }
      $sql_task="UPDATE  `task_assign` SET `actual_start_date`='$res_actualstart_date',`actual_end_date`='$res_actualend_date',`task_status`='$res_taststatus',`delay`=$delay where `task_id`='$tskid'"  ; 
      $task_assn=mysqli_query($conn, $sql_task);
      
      if($task_assn)
        {
          @header("Location: task-list.php?msg= Successfull edited");
		      exit(); 

        }
    }

?> 

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Edit</title>
        <link rel="stylesheet" href="user-edit.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    </head>
<body>
<div class="navbar">
    <div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Dashboard</div>
    </div>
        <div class="nav">
            <div class="subNavs"><a href="user_dashboard.php">Home</a></div>
            <div class="subNavs"><a href="u_change_pass.php">Change Password</a></div>
            <div class="subNavs"><a href="task-list.php">Task List</a></div>
            <div class="subNavs"><a href="leave.php">Request Leave</a></div>
            <div class="subNavs"><a href="leave-user-status.php">Leave Status</a></div>
        </div>
    <div class="welcome">
    <div><h2>Welcome <?php echo $name ?></h2> </div>
    <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>  
    </div>    
</div>
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="user_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="u_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="task-list.php">Task List</a></div>
        <div class="dropbtn"><a href="leave.php">Request Leave</a></div>
        <div class="dropbtn"><a href="leave-user-status.php">Leave Status</a></div>
    </div>
</div>

    <div style="height: 110px;"></div>
        <div class="superContainer">
            <div class="container">
                <div class="heading">Task-Assigned <br>Form</div>
                <form class="form" enctype="multipart/form-data" method="post" name="loginform" id="loginform" onSubmit="return checking();">
                    <input type="hidden" name="mode" value="1">
                    <div class="inputContainer">
                        <label>Task-Description</label><input type="text" class="inputField" placeholder="Task-Description" name="task_description" id="task_description" value="<?php echo $row['task_description'] ?>" readonly>
                    </div>
                    <div class="inputContainer">
                        <label>Task-Assign Date</label><input type="date" class="inputField" name="task_assign_date" id="task_assign_date" value="<?php echo $row['task_assign_date'] ?>" readonly>
                    </div>
                    <div class="inputContainer">
                        <label>Start Date</label><input type="date" class="inputField" name="start_date" id="start_date" value="<?php echo $row['start_date'] ?>" readonly>
                    </div>
                    <div class="inputContainer">
                        <label>End Date</label><input type="date" class="inputField" name="end_date" id="end_date" value="<?php echo $row['end_date'] ?>" readonly>
                    </div>
                    <div class="inputContainer">
                        <label>Actual Start Date *</label><input type="date" class="inputField" name="actual_start_date" id="actual_start_date" min="<?php echo $row['start_date'] ?>" value="<?php echo $row['actual_start_date'] ?>" <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> readonly <?php } ?>>
                    </div>
                    <div class="inputContainer">
                        <label>Actual End Date *</label><input type="date" class="inputField" name="actual_end_date" id="actual_end_date" min="<?php echo $row['start_date'] ?>" value="<?php echo $row['actual_end_date'] ?>" <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> readonly <?php } ?>>
                    </div>
                    <div class="inputContainer">
                        <label>Priority</label>
                        <input type="text" class="inputSelect" name="priority" id="priority" value="<?php if($row['priority']=== "1") {echo "High";} elseif($row['priority']=== "2"){echo "Medium";} else {echo "Low";}?>" readonly>
                    </div> 
                    <div class="inputContainer">
                        <label for="task_status">Task Status</label>
                        <select class="inputSelect" name="task_status" id="task_status" >
                        <option value="Assigned" <?php if($row['task_status']=='Assigned') echo "selected" ?> <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> disabled <?php } ?>>Assigned</option>
                        <option value="In progress" <?php if($row['task_status']=='In progress') echo "selected" ?> <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> disabled <?php } ?>>In progress</option>
                        <option value="Completed" <?php if($row['task_status']=='Completed') echo "selected" ?> <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> disabled <?php } ?>>Completed</option>
                        </select>   
                    </div> 
                    <div class="inputContainer" <?php if($row['pdf']==''){ ?> style=" display: none;"  <?php } ?>>
                        <label>Attachment</label>
                     <a href="pdf_file/<?php echo $row['pdf']?>" id="link" style="text-decoration: none; color: black;font-weight: bold;"><i class="fa-solid fa-paperclip"></i></a>                
                    </div> 

                    <div class="gap" ></div> 
                <input type="submit" class="assign-btn" value="Edit" <?php if($row['task_status']=='Completed' || $row['status']==='Inactive'){ ?> style="display: none;" <?php } ?>>
                </form>
            </div>
        </div>
        <script src="task-assign.js"></script>
        <script>
          function show()
            {
                console.log("!!!");
                document.getElementById('dropLinks').style.visibility="visible";
            }
            function hide()
            {
                document.getElementById('dropLinks').style.visibility="hidden"; 
            }  
        </script>
    </body>
</html>