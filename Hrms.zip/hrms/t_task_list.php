<?php 
include("conn.php");
session_start();
$tid=$_SESSION["user_id"];
$name2=$_SESSION["name"];
if(mysqli_connect_errno()){
    echo "failed to connect to mysql" . mysqli_connect_error();
}
if(empty($name2) || empty($tid))
{
   @header("Location: index.php");
   exit();
}
/*$name=mysqli_query($conn,"SELECT `name` from `staff_registration_master` where `user_id`='$userid'");
$namearr=mysqli_fetch_array($conn,$name);*/
$username=mysqli_query($conn,"SELECT `name` FROM `staff_registration_master` where `user_id`='$tid'");
$usr=mysqli_fetch_array($username);
if(isset($_REQUEST['status'])){
    $status=$_REQUEST['status'];
    if($status==='Assigned'){
        $task_list=mysqli_query($conn,"SELECT `task_id`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`actual_start_date`,`actual_end_date`,`delay`,`priority`,`status`,`task_status` FROM `task_assign` where `user_id`='$tid' and `task_status`='$status' order by `start_date`,`priority`");

    }
    elseif($status==='Completed'){
        $task_list=mysqli_query($conn,"SELECT `task_id`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`actual_start_date`,`actual_end_date`,`delay`,`priority`,`status`,`task_status` FROM `task_assign` where `user_id`='$tid' and `task_status`='$status' order by `start_date`,`priority`");

    }
    elseif($status==='In progress'){
        $task_list=mysqli_query($conn,"SELECT `task_id`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`actual_start_date`,`actual_end_date`,`delay`,`priority`,`status`,`task_status` FROM `task_assign` where `user_id`='$tid' and `task_status`='$status' order by `start_date`,`priority`");
    }
}
else{
    $task_list=mysqli_query($conn,"SELECT `task_id`,`task_description`,`task_assign_date`,`start_date`,`end_date`,`actual_start_date`,`actual_end_date`,`delay`,`priority`,`status`,`task_status` FROM `task_assign` where `user_id`='$tid'  order by `start_date`,`priority`");
}
$k=0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Task List</title>
    <link rel="stylesheet" href="t_task_list.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<div class="navbar">
<div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Teacher Dashboard</div>
</div>
    <div class="nav">
        <div class="subNavs"><a href="teacher_dashboard.php">Home</a></div>
        <div class="subNavs"><a href="t_change_pass.php">Change Password</a></div>
        <div class="subNavs"><a href="t_timetable.php">Time table</a></div>
        <!-- <div class="subNavs"><a href="t_task_list.php">Task List</a></div> -->
        <!-- <div class="subNavs"><a href="t_student_list.php">Student List</a></div> -->
        <!-- <div class="subNavs"><a href="t_attendence_table.php">Attendence Table</a></div> -->
        <!-- <div class="subNavs"><a href="attendence_list.php">Attendence List</a></div> -->
        <div class="dropdown" style="width: 14.8vw;padding-top:8px;">
            <button class="dropbtn" id="list">Attendence-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_attendence_table.php">Attendence Table</a>
                <a href="attendence_list.php">Attendence List</a>
            </div>
        </div>
        <div class="dropdown" style="width: 14vw;padding-top:8px;">
            <button class="dropbtn" id="list">List-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_task_list.php">Task List</a>
                <a href="t_student_list.php">Student List</a>
            </div>
        </div>
    </div>
    <div class="welcome">
        <div><h2>Welcome <?php echo $name2 ?></h2></div> 
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>     
</div>


<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="teacher_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="t_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="t_task_list.php">Task List</a></div>
        <div class="dropbtn"><a href="t_student_list.php">Student List</a></div>
        <div class="dropbtn"><a href="t_attendence_table.php">Attendence Table</a></div>
        <div class="dropbtn"><a href="attendence_list.php">Attendence List</a></div>
        <div class="dropbtn"><a href="t_timetable.php">Time table</a></div>
    </div>
</div> 

    <div class="container">
        <p align="center">Task List</p>
        <div style="display:flex;justify-content:center;gap:10px">
            <span  style="cursor:pointer;"><a href="t_task_list.php">All</a></span>
            <span  style="cursor:pointer;"><a href="t_task_list.php?status=Assigned">Assigned</a></span>
            <span  style="cursor:pointer;"><a href="t_task_list.php?status=Completed">Completed</a></span>
            <span  style="cursor:pointer;"><a href="t_task_list.php?status=In progress">In progress</a></span>
        </div>
        <div>
            <br>
            
            <div class="tableDiv">
            <table border="1" align="center">
                <tr>
                    <th>Sl No.</th>
                        <th>Task-Description</th> 
                        <th>Assign date</th> 
                        <th>start date</th> 
                        <th>end date</th> 
                        <th>Actual start date</th> 
                        <th>Actual end date</th>
                        <th>Delay</th>  
                        <th>priority</th> 
                        <th>status</th>
                        <th>Task status</th>
                        <th></th>
                </tr>
                <?php  while($arr=mysqli_fetch_array($task_list)){?> 
        <tr>
            <td><?php echo ++$k; ?></td>
            <td><?php echo $arr['task_description'];  ?></td>
            <td><?php echo $arr['task_assign_date'];  ?></td>
            <td><?php echo $arr['start_date'];  ?></td>
            <td><?php echo $arr['end_date'];  ?></td>
            <td><?php echo $arr['actual_start_date'];  ?></td>
            <td><?php echo $arr['actual_end_date'];  ?></td>
            <td><?php echo $arr['delay'];  ?></td>
            <td><?php if($arr['priority']=== "1") {echo "High";} elseif($arr['priority']=== "2"){echo "Medium";} else {echo "Low";}?></td>
			<td><?php echo $arr['status'];  ?></td>  
            <td><?php echo $arr['task_status'];  ?></td>  
            <td><?php if( $arr['task_status']==='Completed' || $arr['status']==='Inactive') { ?><button class="srch-btn"><a href="t_edit.php?taskid=<?php echo $arr['task_id'] ?>"  ><i class="fa-solid fa-clipboard-check"></i></button><?php } else {?><button class="srch-btn"><a href="t_edit.php?taskid=<?php echo $arr['task_id'] ?>"><i class="fa-solid fa-pen-to-square"></i></a></button><?php } ?></td>
 
            
        </tr>
        <?php } ?>
        
            </table>
            </div>
        </div>
    </div>
    <script src="teacher_dashboard.js"></script> 
</body>
</html>