
?>
<?php
include("conn.php");
$tskid=$_REQUEST['tskid'];
$fetch1=mysqli_query($conn,"SELECT  `status` FROM `task_assign` WHERE `task_id`='$tskid'");
$row=mysqli_fetch_array($fetch1);
if($row['status']==='Inactive'){
$data=mysqli_query($conn,"UPDATE  `task_assign` SET `status`='Active' WHERE `task_id`='$tskid'");
@header("Location: Task-status.php");
}
else{
$data=mysqli_query($conn,"UPDATE  `task_assign` SET `status`='Inactive' WHERE `task_id`='$tskid'");
@header("Location: Task-status.php");
}

?>