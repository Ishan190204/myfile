<?php
include("conn.php");
session_start();   
$tid=$_REQUEST['tid'];
$cid=$_REQUEST['cl'];
$sid=$_REQUEST['sb'];



    $sql1=mysqli_query($conn,"UPDATE `teacher_subject_map` set status='Inactive'  where 
                            `teacher_id`='$tid' and `class_id`='$cid' and `subject_id`='$sid' ");
    

    $sql2=mysqli_query($conn,"UPDATE `teacher_student_map` set status='Inactive'  where 
                             `teacher_id`='$tid' and `class_id`='$cid' and `subject_id`='$sid'  ");  
     

if( $sql1 && $sql2){
    @header("Location: ".$_SERVER['HTTP_REFERER']);
}
?>