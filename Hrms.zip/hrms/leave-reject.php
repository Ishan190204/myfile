<?php 
    include("conn.php");
    session_start();
    $name=$_SESSION['name'];
    $request_id=$_REQUEST['leave_request_id'];
    $reject_table=mysqli_query($conn,"UPDATE `leave_request` SET `status`='Rejected' where `leave_request_id`='$request_id'");
      if($reject_table)
        {
          @header("Location:leave-approve.php?msg=rejected ");
		      exit(); 

        }
   ?>