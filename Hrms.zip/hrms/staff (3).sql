-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2024 at 01:00 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `staff`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `a_id` int(255) NOT NULL,
  `student_id` int(255) NOT NULL,
  `teacher_id` int(200) NOT NULL,
  `class_id` int(200) NOT NULL,
  `subject_id` int(200) NOT NULL,
  `present` varchar(50) NOT NULL,
  `absent` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `remarks` varchar(5000) NOT NULL,
  `topic_covered` varchar(5000) NOT NULL,
  `month` varchar(50) NOT NULL,
  `year` varchar(10) NOT NULL,
  `slot` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`a_id`, `student_id`, `teacher_id`, `class_id`, `subject_id`, `present`, `absent`, `date`, `remarks`, `topic_covered`, `month`, `year`, `slot`) VALUES
(102, 17, 23, 7, 7, 'Y', 'N', '2024-07-17', '', '', 'July', '2024', ''),
(103, 8, 23, 7, 7, 'Y', 'N', '2024-08-17', '', '', 'August', '2024', ''),
(104, 18, 23, 7, 7, 'N', 'Y', '2024-08-17', '', '', 'August', '2024', ''),
(105, 17, 23, 7, 7, 'Y', 'N', '2024-08-17', '', '', 'August', '2024', ''),
(106, 11, 24, 8, 7, 'Y', 'N', '2024-09-19', 'good', 'python', 'September', '2024', ''),
(107, 8, 24, 7, 10, 'Y', 'N', '2024-09-19', '', 'physical change', 'September', '2024', ''),
(108, 18, 24, 7, 10, 'Y', 'N', '2024-09-19', '', 'chemical change', 'September', '2024', '');

-- --------------------------------------------------------

--
-- Table structure for table `class_master`
--

CREATE TABLE `class_master` (
  `class_id` int(255) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_master`
--

INSERT INTO `class_master` (`class_id`, `class_name`, `status`) VALUES
(7, 'Class-1', 'Active'),
(8, 'Class-2', 'Active'),
(9, 'Class-3', 'Active'),
(10, 'Class-4', 'Active'),
(11, 'Class-5', 'Active'),
(12, 'Class-6', 'Active'),
(13, 'Class-7', 'Active'),
(14, 'Class-8', 'Active'),
(15, 'Class-9', 'Active'),
(16, 'Class-10', 'Active'),
(17, 'Class-11', 'Active'),
(18, 'Class-12', 'Active'),
(19, 'Eng-1', 'Active'),
(20, 'Eng-2', 'Active'),
(21, 'Eng-3', 'Active'),
(22, 'Eng-4', 'Active'),
(23, 'Bca-1', 'Active'),
(24, 'Bca-2', 'Active'),
(25, 'Bca-3', 'Active'),
(26, 'Mca-1', 'Active'),
(27, 'Mca-2', 'Active'),
(28, 'Mba-1', 'Active'),
(29, 'Mba-2', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `day_master`
--

CREATE TABLE `day_master` (
  `day_id` int(11) NOT NULL,
  `day_name` varchar(32) NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `day_master`
--

INSERT INTO `day_master` (`day_id`, `day_name`, `activity`) VALUES
(2, 'Tuesday', 1),
(3, 'Wednesday', 1),
(4, 'Thursday', 1),
(5, 'Friday', 1),
(6, 'Saturday', 1),
(10, 'Sunday', 1),
(11, 'Monday', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expense_master`
--

CREATE TABLE `expense_master` (
  `expense_id` int(255) NOT NULL,
  `expense_category` varchar(50) NOT NULL,
  `user_id` int(255) NOT NULL,
  `user_description` varchar(255) NOT NULL,
  `expense_amount` bigint(100) NOT NULL,
  `expense_month` int(25) NOT NULL,
  `expense_date` date NOT NULL,
  `mode_of_payment` varchar(25) NOT NULL,
  `transaction_id` varchar(200) NOT NULL,
  `payment_type` varchar(25) NOT NULL,
  `amount_left` bigint(100) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `leave_master`
--

CREATE TABLE `leave_master` (
  `leave_id` int(255) NOT NULL,
  `leave_type` varchar(100) NOT NULL,
  `no_of_leaves` int(255) NOT NULL,
  `carry_forward` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_master`
--

INSERT INTO `leave_master` (`leave_id`, `leave_type`, `no_of_leaves`, `carry_forward`) VALUES
(6, 'Medical Leave', 5, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `leave_request`
--

CREATE TABLE `leave_request` (
  `leave_request_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `leave_id` int(255) NOT NULL,
  `leave_start_date` date NOT NULL,
  `leave_end_date` date NOT NULL,
  `duration` int(200) NOT NULL,
  `reason` varchar(2000) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `room_master`
--

CREATE TABLE `room_master` (
  `room_id` int(11) NOT NULL,
  `room_name` tinytext NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_master`
--

INSERT INTO `room_master` (`room_id`, `room_name`, `activity`) VALUES
(1, 'LT-306', 1),
(76, 'LT-301', 1),
(77, 'LT-302', 1);

-- --------------------------------------------------------

--
-- Table structure for table `slot_master`
--

CREATE TABLE `slot_master` (
  `slot_id` int(11) NOT NULL,
  `slot_name` varchar(256) NOT NULL,
  `room_id` int(11) NOT NULL,
  `day_id` int(11) NOT NULL,
  `time_id` int(11) NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slot_master`
--

INSERT INTO `slot_master` (`slot_id`, `slot_name`, `room_id`, `day_id`, `time_id`, `activity`) VALUES
(16, 'Computer', 1, 3, 2, 1),
(17, 'Computer', 76, 6, 1, 1),
(18, 'Biology', 1, 5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `staff_leave_mapping`
--

CREATE TABLE `staff_leave_mapping` (
  `staff_leave_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `leave_id` int(255) NOT NULL,
  `total_leave_balance` int(200) NOT NULL,
  `left_leave_balance` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff_registration_master`
--

CREATE TABLE `staff_registration_master` (
  `user_id` int(200) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_description` varchar(5000) NOT NULL,
  `user_type` varchar(12) NOT NULL,
  `phone_no` bigint(10) NOT NULL,
  `user_status` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_registration_master`
--

INSERT INTO `staff_registration_master` (`user_id`, `user_name`, `name`, `password`, `user_description`, `user_type`, `phone_no`, `user_status`) VALUES
(22, 'ar123', 'Arka', 'ar123', 'Admin', 'Ad', 9765432180, 'Yes'),
(23, 'is123', 'ishan', 'is123', 'Teacher', 'Te', 7980453888, 'Yes'),
(24, 'su123', 'suman jha', 'su123', 'Teacher', 'Te', 8798822200, 'Yes'),
(26, 'tr12', 'trideep', 'tr12', 'Teacher', 'Te', 9038210245, 'Yes'),
(27, 'sh123', 'shibam', 'sh123', 'Teacher', 'Te', 7890777456, 'Yes'),
(28, 'kushal', 'Kushal Ghosh', '321k', 'Teacher', 'Te', 9830342864, 'Yes'),
(29, 'ra', 'rahul', 'ra', 'Teacher', 'Te', 1236547890, 'No'),
(30, 'j123', 'Jeet', 'j123', 'Coordinator', 'Co', 1236547980, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `student_master`
--

CREATE TABLE `student_master` (
  `student_id` int(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `student_class` int(100) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `board` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `age` int(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `admission_date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_master`
--

INSERT INTO `student_master` (`student_id`, `student_name`, `student_class`, `phone`, `address`, `board`, `email`, `age`, `gender`, `admission_date`, `status`, `password`) VALUES
(8, 'subham', 22, 1236547890, 'BE-1/15,Deshbandhu Nagar,Block-B,1st Floor ,Baguiati', 'WBSSE', 'subhampatra085@gmail.com', 21, 'male', '2024-08-12', 'Active', '1236547890'),
(10, 'ritwick', 10, 1234567890, '', 'ICSE', '', 0, 'male', '2024-08-17', 'Active', '1234567890'),
(11, 'pritam', 8, 9876543210, '', 'ISC', '', 0, 'male', '2024-08-16', 'Active', '9876543210'),
(12, 'nilu', 9, 1231239898, '', 'WBSSE', '', 0, 'male', '2024-08-17', 'Active', '1231239898'),
(13, 'rahul', 8, 7980340912, '', 'WBSSE', '', 23, 'male', '2024-08-17', 'Active', '7980340912'),
(14, 'shyam', 10, 7980340944, '', 'WBSSE', '', 22, 'male', '2024-08-17', 'Active', '7980340944'),
(15, 'deb', 7, 9080340947, '', 'ICSE', '', 12, 'male', '2024-08-17', 'Inactive', '9080340947'),
(16, 'arghya', 10, 7980340940, '', 'ISC', '', 0, 'male', '2024-08-17', 'Active', '7980340940'),
(17, 'sambit', 9, 6767190909, '', 'CBSE', '', 12, 'male', '2024-06-13', 'Active', '6767190909'),
(18, 'soumya', 7, 7980340976, '', 'ISC', '', 0, 'male', '2024-08-17', 'Active', '7980340976');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `stud_sub_id` int(255) NOT NULL,
  `stud_id` int(100) NOT NULL,
  `subject_id` int(200) NOT NULL,
  `class_id` int(20) NOT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `sub_end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_subject`
--

INSERT INTO `student_subject` (`stud_sub_id`, `stud_id`, `subject_id`, `class_id`, `date`, `status`, `sub_end_date`) VALUES
(131, 9, 7, 8, '2024-08-13', 'Active', '0000-00-00'),
(132, 9, 8, 8, '2024-08-13', 'Active', '0000-00-00'),
(133, 8, 10, 7, '2024-08-13', 'Active', '0000-00-00'),
(134, 8, 7, 7, '2024-08-13', 'Inactive', '0000-00-00'),
(135, 15, 7, 7, '2024-08-17', 'Inactive', '0000-00-00'),
(136, 15, 8, 7, '2024-08-17', 'Inactive', '0000-00-00'),
(137, 15, 9, 7, '2024-08-17', 'Inactive', '0000-00-00'),
(138, 15, 10, 7, '2024-08-17', 'Inactive', '0000-00-00'),
(139, 11, 7, 8, '2024-08-17', 'Active', '0000-00-00'),
(140, 11, 9, 8, '2024-08-17', 'Active', '0000-00-00'),
(141, 11, 10, 8, '2024-08-17', 'Active', '0000-00-00'),
(142, 18, 7, 7, '2024-08-17', 'Active', '0000-00-00'),
(143, 18, 10, 7, '2024-08-17', 'Active', '0000-00-00'),
(144, 17, 7, 7, '2024-07-17', 'Inactive', '0000-00-00'),
(145, 18, 9, 7, '2024-09-19', 'Active', '0000-00-00'),
(146, 18, 8, 7, '2024-09-19', 'Active', '0000-00-00'),
(147, 13, 7, 8, '2024-09-19', 'Active', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `subject_master`
--

CREATE TABLE `subject_master` (
  `subject_id` int(255) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject_master`
--

INSERT INTO `subject_master` (`subject_id`, `subject_name`, `status`) VALUES
(7, 'Computer', 'Active'),
(8, 'Physics', 'Active'),
(9, 'Maths', 'Active'),
(10, 'Chemistry', 'Active'),
(11, 'Biology', 'Active'),
(12, 'History', 'Active'),
(13, 'Geography', 'Active'),
(14, 'English', 'Active'),
(15, 'Bengali', 'Active'),
(16, 'Economics', 'Active'),
(17, 'Statistics', 'Active'),
(18, 'Accountancy', 'Active'),
(19, 'Commerce', 'Active'),
(20, 'Hindi', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `task_assign`
--

CREATE TABLE `task_assign` (
  `task_id` int(200) NOT NULL,
  `user_type` varchar(200) NOT NULL,
  `user_id` int(200) NOT NULL,
  `task_description` varchar(5000) NOT NULL,
  `task_assign_date` date NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `actual_start_date` date NOT NULL,
  `actual_end_date` date NOT NULL,
  `delay` varchar(200) NOT NULL,
  `priority` varchar(200) NOT NULL,
  `task_status` char(20) NOT NULL,
  `pdf` varchar(255) NOT NULL,
  `status` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `task_assign`
--

INSERT INTO `task_assign` (`task_id`, `user_type`, `user_id`, `task_description`, `task_assign_date`, `start_date`, `end_date`, `actual_start_date`, `actual_end_date`, `delay`, `priority`, `task_status`, `pdf`, `status`) VALUES
(40, 'Te', 24, 'task', '2024-09-19', '2024-09-19', '2024-09-20', '2024-09-19', '2024-09-26', '6', '1', 'Assigned', 'id_subham.pdf', 'Active'),
(41, 'Te', 23, 'fees system', '2024-09-19', '2024-09-19', '2024-09-19', '2024-09-19', '2024-09-19', '0', '3', 'Assigned', '', 'Active'),
(42, 'Co', 30, 'fees system', '2024-09-19', '2024-09-19', '2024-09-20', '2024-09-20', '2024-09-21', '1', '3', 'Completed', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_student_map`
--

CREATE TABLE `teacher_student_map` (
  `tch_student_id` int(255) NOT NULL,
  `teacher_id` int(100) NOT NULL,
  `student_id` int(200) NOT NULL,
  `subject_id` int(200) NOT NULL,
  `class_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_student_map`
--

INSERT INTO `teacher_student_map` (`tch_student_id`, `teacher_id`, `student_id`, `subject_id`, `class_id`, `status`, `date`) VALUES
(67, 23, 9, 7, 8, 'Active', '2024-08-13'),
(68, 23, 9, 8, 8, 'Inactive', '2024-08-13'),
(69, 24, 8, 10, 7, 'Active', '2024-08-13'),
(70, 23, 8, 7, 7, 'Inactive', '2024-08-13'),
(71, 23, 15, 7, 7, 'Inactive', '2024-08-17'),
(72, 23, 15, 8, 7, 'Inactive', '2024-08-17'),
(73, 27, 15, 9, 7, 'Inactive', '2024-08-17'),
(74, 24, 15, 10, 7, 'Inactive', '2024-08-17'),
(75, 24, 11, 7, 8, 'Active', '2024-08-17'),
(76, 27, 11, 9, 8, 'Active', '2024-08-17'),
(77, 27, 11, 10, 8, 'Active', '2024-08-17'),
(78, 23, 18, 7, 7, 'Active', '2024-08-17'),
(79, 24, 18, 10, 7, 'Active', '2024-08-17'),
(80, 23, 17, 7, 7, 'Inactive', '2024-07-17'),
(81, 27, 18, 9, 7, 'Active', '2024-09-19'),
(82, 23, 18, 8, 7, 'Active', '2024-09-19'),
(83, 24, 13, 7, 8, 'Active', '2024-09-19');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subject_map`
--

CREATE TABLE `teacher_subject_map` (
  `ts_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(100) NOT NULL,
  `class_id` int(200) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_subject_map`
--

INSERT INTO `teacher_subject_map` (`ts_id`, `teacher_id`, `subject_id`, `class_id`, `status`) VALUES
(50, 23, 7, 7, 'Active'),
(51, 23, 8, 7, 'Active'),
(52, 23, 7, 8, 'Active'),
(53, 23, 8, 8, 'Inactive'),
(54, 24, 7, 8, 'Active'),
(55, 24, 9, 7, 'Active'),
(56, 24, 10, 7, 'Active'),
(57, 25, 7, 7, 'Active'),
(58, 25, 7, 8, 'Active'),
(59, 25, 7, 9, 'Active'),
(60, 25, 7, 10, 'Active'),
(61, 25, 9, 8, 'Active'),
(62, 26, 8, 9, 'Active'),
(63, 26, 10, 9, 'Active'),
(64, 26, 9, 9, 'Active'),
(65, 26, 7, 9, 'Active'),
(66, 27, 8, 8, 'Active'),
(67, 27, 10, 8, 'Active'),
(68, 27, 8, 10, 'Active'),
(69, 27, 10, 10, 'Active'),
(70, 27, 9, 8, 'Active'),
(71, 27, 7, 9, 'Active'),
(72, 27, 9, 7, 'Active'),
(73, 24, 9, 8, 'Active'),
(74, 24, 9, 9, 'Active'),
(75, 24, 10, 9, 'Active'),
(76, 24, 7, 10, 'Active'),
(77, 24, 8, 10, 'Active'),
(78, 24, 9, 7, 'Active'),
(79, 28, 7, 15, 'Active'),
(80, 28, 7, 16, 'Active'),
(81, 28, 7, 17, 'Active'),
(83, 28, 7, 18, 'Active'),
(84, 28, 7, 19, 'Active'),
(85, 28, 7, 20, 'Active'),
(86, 28, 7, 21, 'Active'),
(87, 28, 7, 22, 'Active'),
(88, 28, 7, 23, 'Active'),
(89, 28, 7, 24, 'Active'),
(90, 28, 7, 25, 'Active'),
(91, 28, 7, 26, 'Active'),
(92, 28, 7, 27, 'Active'),
(93, 23, 18, 8, ''),
(94, 24, 8, 9, ''),
(95, 28, 8, 9, ''),
(96, 28, 9, 8, '');

-- --------------------------------------------------------

--
-- Table structure for table `time_master`
--

CREATE TABLE `time_master` (
  `time_id` int(11) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `activity` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `time_master`
--

INSERT INTO `time_master` (`time_id`, `start_time`, `end_time`, `activity`) VALUES
(1, '11:00:00', '13:30:00', 1),
(2, '12:00:00', '14:30:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_description`
--

CREATE TABLE `user_description` (
  `user_description_id` int(200) NOT NULL,
  `user_description_name` varchar(5000) NOT NULL,
  `user_description_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_description`
--

INSERT INTO `user_description` (`user_description_id`, `user_description_name`, `user_description_type`) VALUES
(19, 'Admin', 'Ad'),
(20, 'Teacher', 'Te'),
(21, 'Coordinator', 'Co');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `class_master`
--
ALTER TABLE `class_master`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `day_master`
--
ALTER TABLE `day_master`
  ADD PRIMARY KEY (`day_id`);

--
-- Indexes for table `expense_master`
--
ALTER TABLE `expense_master`
  ADD PRIMARY KEY (`expense_id`);

--
-- Indexes for table `leave_master`
--
ALTER TABLE `leave_master`
  ADD PRIMARY KEY (`leave_id`);

--
-- Indexes for table `leave_request`
--
ALTER TABLE `leave_request`
  ADD PRIMARY KEY (`leave_request_id`),
  ADD KEY `leave_request_ibfk_1` (`leave_id`),
  ADD KEY `leave_request_ibfk_2` (`user_id`);

--
-- Indexes for table `room_master`
--
ALTER TABLE `room_master`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `slot_master`
--
ALTER TABLE `slot_master`
  ADD PRIMARY KEY (`slot_id`),
  ADD KEY `fk_day_id` (`day_id`),
  ADD KEY `fk_time_id` (`time_id`),
  ADD KEY `fk_room_id` (`room_id`);

--
-- Indexes for table `staff_leave_mapping`
--
ALTER TABLE `staff_leave_mapping`
  ADD PRIMARY KEY (`staff_leave_id`),
  ADD KEY `staff_leave_mapping_ibfk_1` (`leave_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `staff_registration_master`
--
ALTER TABLE `staff_registration_master`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `student_master`
--
ALTER TABLE `student_master`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`stud_sub_id`);

--
-- Indexes for table `subject_master`
--
ALTER TABLE `subject_master`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `task_assign`
--
ALTER TABLE `task_assign`
  ADD PRIMARY KEY (`task_id`),
  ADD KEY `test` (`user_id`);

--
-- Indexes for table `teacher_student_map`
--
ALTER TABLE `teacher_student_map`
  ADD PRIMARY KEY (`tch_student_id`);

--
-- Indexes for table `teacher_subject_map`
--
ALTER TABLE `teacher_subject_map`
  ADD PRIMARY KEY (`ts_id`);

--
-- Indexes for table `time_master`
--
ALTER TABLE `time_master`
  ADD PRIMARY KEY (`time_id`);

--
-- Indexes for table `user_description`
--
ALTER TABLE `user_description`
  ADD PRIMARY KEY (`user_description_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `a_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `class_master`
--
ALTER TABLE `class_master`
  MODIFY `class_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `day_master`
--
ALTER TABLE `day_master`
  MODIFY `day_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `expense_master`
--
ALTER TABLE `expense_master`
  MODIFY `expense_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `leave_master`
--
ALTER TABLE `leave_master`
  MODIFY `leave_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `leave_request`
--
ALTER TABLE `leave_request`
  MODIFY `leave_request_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `room_master`
--
ALTER TABLE `room_master`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `slot_master`
--
ALTER TABLE `slot_master`
  MODIFY `slot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `staff_leave_mapping`
--
ALTER TABLE `staff_leave_mapping`
  MODIFY `staff_leave_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `staff_registration_master`
--
ALTER TABLE `staff_registration_master`
  MODIFY `user_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `student_master`
--
ALTER TABLE `student_master`
  MODIFY `student_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `student_subject`
--
ALTER TABLE `student_subject`
  MODIFY `stud_sub_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `subject_master`
--
ALTER TABLE `subject_master`
  MODIFY `subject_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `task_assign`
--
ALTER TABLE `task_assign`
  MODIFY `task_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `teacher_student_map`
--
ALTER TABLE `teacher_student_map`
  MODIFY `tch_student_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `teacher_subject_map`
--
ALTER TABLE `teacher_subject_map`
  MODIFY `ts_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `time_master`
--
ALTER TABLE `time_master`
  MODIFY `time_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_description`
--
ALTER TABLE `user_description`
  MODIFY `user_description_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `slot_master`
--
ALTER TABLE `slot_master`
  ADD CONSTRAINT `fk_day_id` FOREIGN KEY (`day_id`) REFERENCES `day_master` (`day_id`),
  ADD CONSTRAINT `fk_room_id` FOREIGN KEY (`room_id`) REFERENCES `room_master` (`room_id`),
  ADD CONSTRAINT `fk_time_id` FOREIGN KEY (`time_id`) REFERENCES `time_master` (`time_id`);

--
-- Constraints for table `staff_leave_mapping`
--
ALTER TABLE `staff_leave_mapping`
  ADD CONSTRAINT `staff_leave_mapping_ibfk_1` FOREIGN KEY (`leave_id`) REFERENCES `leave_master` (`leave_id`),
  ADD CONSTRAINT `staff_leave_mapping_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `staff_registration_master` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
