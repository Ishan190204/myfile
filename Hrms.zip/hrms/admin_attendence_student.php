<?php 
    include("conn.php");
    session_start();

    $name1=$_SESSION["usname"] ;
    if(mysqli_connect_errno()){
      echo "failed to connect to mysql" . mysqli_connect_error();
  }
    if(empty($name1))
    {
       @header("Location: index.php");
       exit();
    }
   
    if(!empty($_REQUEST["tid"])){
        $tid=$_REQUEST["tid"];
        $_SESSION["tid"]=$tid;
    }
    else{
        $tid=$_SESSION["tid"];
    }

    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if( empty($tid))
    {
       @header("Location: index.php");
       exit();
    }
    $tqry=mysqli_query($conn,"SELECT `name` from `staff_registration_master` where `user_id`='$tid'");
    $tname=mysqli_fetch_array($tqry);
    $teacher=$tname['name'];
    $fetch_class="SELECT * from `teacher_student_map` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` where `teacher_student_map`.`teacher_id`='$tid' group by `class_master`.`class_id`";
    $ft_class=mysqli_query($conn,$fetch_class);
    $fetch_sub="SELECT * from `teacher_student_map`  inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' group by `subject_master`.`subject_id`";
    $ft_sub=mysqli_query($conn,$fetch_sub);
    
    $crt=date("Y-m-d");

     if(!empty($_REQUEST['date']))
    {
        $date=$_REQUEST['date'];
        if(!empty($_REQUEST['class']) || !empty($_REQUEST['sub']))  {
            $class_id=$_REQUEST['class'];
            $sub_id=$_REQUEST['sub'];
            if(empty($sub_id)){
                $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id' and  `teacher_student_map`.`date`<='$date'");
                $arr=mysqli_fetch_array($stud_qry);
                if(!empty($arr)){
                    $flag=1;
                    $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id' and  `teacher_student_map`.`date`<='$date'");
     
                }  
            }
            elseif(empty($class_id)&& !empty($sub_id)){
                $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id' and  `teacher_student_map`.`date`<='$date'");
                $arr=mysqli_fetch_array($stud_qry);
                if(!empty($arr)){
                    $flag=1;
                    $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id' and  `teacher_student_map`.`date`<='$date'");
     
                }
            }
            else{
                $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id' and `class_master`.`class_id`='$class_id' and  `teacher_student_map`.`date`<='$date'");
                $arr=mysqli_fetch_array($stud_qry);
                if(!empty($arr)){
                    $flag=1;
                    $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id' and `class_master`.`class_id`='$class_id' and  `teacher_student_map`.`date`<='$date'");
     
                }
            }
        }
        else{
            $class_id="";
            $sub_id="";
            $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and  `teacher_student_map`.`date`<='$date'");

        }
       
    }
    else
    {
        $date="";
        if(!empty($_REQUEST['class']) || !empty($_REQUEST['sub']))  {
            $class_id=$_REQUEST['class'];
            $sub_id=$_REQUEST['sub'];
            if(empty($sub_id)){
                $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id' ");
                $arr=mysqli_fetch_array($stud_qry);
                if(!empty($arr)){
                    $flag=1;
                    $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `class_master`.`class_id`='$class_id'");
     
                }  
            }
            elseif(empty($class_id)&& !empty($sub_id)){
                $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id'");
                $arr=mysqli_fetch_array($stud_qry);
                if(!empty($arr)){
                    $flag=1;
                    $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id'");
     
                }
            }
            else{
                $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id' and `class_master`.`class_id`='$class_id'");
                $arr=mysqli_fetch_array($stud_qry);
                if(!empty($arr)){
                    $flag=1;
                    $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active' and `subject_master`.`subject_id`='$sub_id' and `class_master`.`class_id`='$class_id'");
     
                }
            }
        }
        else{
            $class_id="";
            $sub_id="";
            $stud_qry=mysqli_query($conn,"SELECT  `student_master`.`student_id`,`student_master`.`student_name`,`class_master`.`class_name`,`class_master`.`class_id`,`subject_master`.`subject_id`,`subject_master`.`subject_name` FROM `teacher_student_map` inner join `student_master` on `teacher_student_map`.`student_id`=`student_master`.`student_id` inner join `class_master` on `teacher_student_map`.`class_id`=`class_master`.`class_id` inner join `subject_master` on `teacher_student_map`.`subject_id`=`subject_master`.`subject_id` where `teacher_student_map`.`teacher_id`='$tid' and `teacher_student_map`.`status`='Active' and `student_master`.`status`='Active'");

        }
       
        
    }
    
    if(!empty($_REQUEST['mode']) && $_REQUEST['submit']=='Submit')
        {
            
            $student_name=$_REQUEST['student_name'];
            $remarks=$_REQUEST['remarks'];
            $topic_covered=$_REQUEST['topic_covered'];
            $stud_id=$_REQUEST['student_id'];
            $class_name=$_REQUEST['class_name'];
            $subject_name=$_REQUEST['subject_name'];
            $class_id=$_REQUEST['class_id'];
            $subject_id=$_REQUEST['subject_id'];
            $date2=$_REQUEST['date'];
            $month=substr("$date2",5,2);
            $month_int=(int)$month;
            $month_str= date("F", mktime(0, 0, 0,$month_int, 1));
            $year=substr("$date2",0,4);
            $slotName=$_REQUEST['slot'];
            if(!empty($_REQUEST['present'])){
                $present=$_REQUEST['present'];
            }
            if(!empty($_REQUEST['absent'])){
                $absent=$_REQUEST['absent'];
            }
        
            $index=0;
            $ind=0;
              foreach( $student_name as $key => $n ) {
                $pres="N";
                if(isset($present[$index])&&($present[$index])==($key+1)){
                    $pres="Y";
                    $index++;
                }    
                $abs="N";
                if(isset($absent[$ind])&&($absent[$ind])==($key+1)){
                    $abs="Y";
                    $ind++;
                } 
                if($pres==='N' && $abs==='N')
                {
                   continue;
                }
                else
                {
                $sql_tc_st= "INSERT INTO `attendence` SET 
                            `student_id`= '$stud_id[$key]',
                            `remarks`= '$remarks[$key]',
                            `topic_covered`= '$topic_covered[$key]',
                            `teacher_id`= '$tid',
                            `class_id`='$class_id[$key]',
                            `subject_id`='$subject_id[$key]',
                             `present`='$pres',
                             `absent`='$abs',
                             `date`='$date2',
                             `month`='$month_str',
                             `year`='$year' ,
                             `slot`='$slotName'";  
                $ts_insrt=mysqli_query($conn, $sql_tc_st);
                }
        }
        if($ts_insrt){
            @header("Location:admin_attendence_student.php");
          exit();  		
        }   
               
         
    }
    /* if(!empty($_REQUEST['mode']) && $_REQUEST['submit']=='Edit'){       
            $student_name=$_REQUEST['student_name'];
            $remarks=$_REQUEST['remarks'];
            $topic_covered=$_REQUEST['topic_covered'];
            $stud_id=$_REQUEST['student_id'];
            $date1=$_REQUEST['date'];
            $month=substr("$date1",5,2);
            $month_int=(int)$month;
            $month_str= date("F", mktime(0, 0, 0,$month_int, 1));
            $year=substr("$date1",0,4);
            if(!empty($_REQUEST['present'])){
                $present=$_REQUEST['present'];
            }
            if(!empty($_REQUEST['absent'])){
                $absent=$_REQUEST['absent'];
            }
            
        
            $index=0;
            $ind=0;
              foreach( $student_name as $key => $n ) {
                $pres="N";
                if(isset($present[$index])&&($present[$index])==($key+1)){
                    $pres="Y";
                    $index++;
                }    
                $abs="N";
                if(isset($absent[$ind])&&($absent[$ind])==($key+1)){
                    $abs="Y";
                    $ind++;
                }
                if($pres==='N' && $abs==='N')
                {
                   continue;
                }
                else
                {                      
                $sql_tc_st= "UPDATE  `attendence` SET 
                            `student_id`= '$stud_id[$key]',
                            `remarks`= '$remarks[$key]',
                            `topic_covered`= '$topic_covered[$key]',
                            `teacher_id`= '$tid',
                            `class_id`='$class_id',
                            `subject_id`='$subject_id',
                            `present`='$pres',
                             `absent`='$abs',
                             `date`='$date1',
                             `month`='$month_str',
                             `year`='$year' where `student_id`= '$stud_id[$key]' and `teacher_id`= '$tid' and `class_id`='$class_id' and `subject_id`='$subject_id' and `date`='$date1'";  
                $ts_insrt=mysqli_query($conn, $sql_tc_st);
            }
        }
            if($ts_insrt){
                @header("Location:attendence_table.php");
		      exit();  		
            }      

   
} */
$k=0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Attendence Table</title>
    <link rel="stylesheet" href="admin_attendence_student.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

<div class="navbar">
    <div class="dashboard">
      <div class="drops" onclick="show()">
        <div class="layer"></div>
        <div class="layer"></div>
        <div class="layer"></div>
      </div>
      <div class="dash">Admin <span>Dashboard</span></div>
    </div>
    <div class="nav">
      <div class="subNavs"><a href="admin_dashboard.php">Home</a></div>
      <div class="subNavs"><a href="user-des.php">User Description</a></div>
      <div class="subNavs"><a href="task-assign.php">Task Assignment</a></div>
      <!-- <div class="subNavs"><a href="admin_attendence.php">Attendence</a></div> -->
      <div id="dropLinks">
      <div class="dropbtn"><a href="admin_message.php" style="text-decoration: none;">Message</a></div>
        <div class="dropbtn"><a href="admin_attendence.php" style="text-decoration: none;">Attendence</a></div>
        <div class="dropdown">
          <button class="dropbtn">Leave-Section <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="leave_master.php">Leave Form</a>
            <a href="leave-approve.php">Leave-Approve</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Status-Approval <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="staff-details.php">Staff Status</a>
            <a href="Task-status.php">Task Status</a>
            <a href="student_status.php">Student Status</a>
            <a href="student_list_status.php">Student List</a>
            <a href="teacher_edit.php">Teacher Details</a>  
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Expense <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="expense.php">Expense-form</a>
            <a href="expense_list.php">Expense-List</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Class-Subject-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="subject_master.php">Subject-form</a>
            <a href="class_master.php">Class-form</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Mapping-Form <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="stu-sub.php">Student-Subject-Teacher Map</a>
            <a href="teacher-sub.php">Teacher-Subject Map</a>
          </div>
        </div>
        <div class="dropdown">
          <button class="dropbtn">Time Table <i class="fa fa-caret-down"></i></button>
          <div class="dropdown-content">
            <a href="time_home.php">Index Page</a>
            <a href="rooms.php">Rooms</a>
            <a href="slots.php">Slots</a>
            <a href="times.php">Times</a>
            <a href="weekDays.php">Week Days</a>
          </div>
        </div> 
        <div class="closebtn">
          <button onclick="hide()">CLOSE</button>
        </div> 
      </div>
    </div>
    <div class="welcome">
      <h2>Welcome <?php echo $name1 ?></h2> 
      <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
  </div>  

    <div class="container">
        <p align="center"><a href="admin_attendence.php" style="text-decoration: none !important; color:blue;">ATTENDENCE </a><span>(Under <?php echo $teacher ?>)</span></p> 
           
        <div style="gap:5px" align="center"> 
            <h3>Filter By:</h3>     
                        <select class="inputSelect" name="class" id="class" onchange="chk()">
                            <option value="">Select Class</option>
                            <?php while($class_row=mysqli_fetch_array($ft_class)){ ?>
                                <option value="<?php echo $class_row['class_id'] ?>" <?php if(!empty($class_id) && $class_id==$class_row['class_id']) echo "selected" ;?>><?php echo $class_row['class_name'] ?></option>
                                    <?php } ?>
                        </select>
        
        <select class="inputSelect" name="subject" id="subject" onchange="chk()">
                            <option value="">Select Subject</option>
                            <?php while($class_row1=mysqli_fetch_array($ft_sub)){ ?>
                                <option value="<?php echo $class_row1['subject_id'] ?>" <?php if(!empty($sub_id) && $sub_id==$class_row1['subject_id']) echo "selected" ;?>><?php echo $class_row1['subject_name'] ?></option>
                                    <?php } ?>
                        </select>
                        <h3>Select:</h3>
        </div>
            <form class="subform"  action="" name="attendenceform" id="attendenceform" method="post" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1" /> 
                                  
                <div align="center" style="margin-bottom:40px;">
                <select class="inputSelect" name="slot" id="slot" >
                            <option value="">Select Slots</option>
                            <option value="Slot 1">Slot 1</option>
                            <option value="Slot 2">Slot 2</option>
                            <option value="Slot 3">Slot 3</option>
                            <option value="Slot 4">Slot 4</option>
                            <option value="Slot 5">Slot 5</option>
                        </select>
        <input type="date" name="date" id="date" class="inputSelect"t value="<?php if(empty($date)) { echo date("Y-m-d"); } else{ echo $date ;}?>" max="<?php  echo date("Y-m-d");  ?>" onchange="chk()">
        </div>
            <div class="tableDiv">
            <table border="1" align="center" style="width: 900px;">
                <tr>
                    
                    <th>Id</th>
                    <th>Present<input type="checkbox" id="pres"  name="present" onclick="pres_chk(this)" ></th>
                    <th>Absent<input type="checkbox" id="abs"  name="absent" onclick="abs_chk(this)" ></th>
                    <th>Student Name</th>
                    <th>Class</th>
                    <th>Subject</th>
                    <th>Remarks</th>
                    <th>Topic Covered<input type="checkbox" id="tpcheck" name="tpcheck" onclick="topic_chk(this)" ></th>
                    
                </tr>
                <?php  while($arr=mysqli_fetch_array($stud_qry)){?> 
                <tr>
                    
                    <td><?php echo ++$k ?></td>
                     <td><input type="checkbox" name="present[]" value="<?php echo $k; ?>" <?php if(!empty($arr['present']) && $arr['present']==='Y'){ ?> checked <?php } ?> onclick="pres_Individual_chk(<?php echo $k ?>)" ></td>
                    <td><input type="checkbox" name="absent[]" value="<?php echo $k; ?>" <?php if(!empty($arr['absent']) && $arr['absent']==='Y'){ ?> checked <?php } ?> onclick="abs_Individual_chk(<?php echo $k ?>)" ></td>
                    <td><input type="hidden" name="student_id[]" value="<?php echo $arr['student_id']; ?>" ><input type="text"  style="border:none" name="student_name[]" value="<?php echo $arr['student_name']; ?>"  readonly></td>
                    <td><input type="hidden" name="class_id[]" value="<?php echo $arr['class_id']; ?>" ><input type="text"  style="border:none" name="class_name[]" value="<?php echo $arr['class_name'];  ?>"  readonly></td>
                    <td><input type="hidden" name="subject_id[]" value="<?php echo $arr['subject_id']; ?>" ><input type="text"  style="border:none" name="subject_name[]" value="<?php echo $arr['subject_name'];  ?>"  readonly></td>
                    <td><textarea name="remarks[]"  style="border:none" class="areatext"><?php if(!empty($arr['remarks'])){ echo $arr['remarks'];} ?></textarea></td>
                    <td><textarea name="topic_covered[]"   style="border:none" class="areatext"><?php if(!empty($arr['topic_covered'])){ echo $arr['topic_covered'];} ?></textarea></td>
                    
                </tr>
                
                <?php } ?>  
            </table>
            </div>
            <button style="margin:auto;margin-top:10px;" class="srch-btn" value="<?php if(!empty($edit)) { echo "Edit" ;} else { echo "Submit" ; }?>" name="submit"><?php if(!empty($edit)) { echo "Edit" ;} else { echo "Submit" ; }?></button>
                        </form>
        </div>
    </div>
    <script src="admin_attendence_student.js"></script>
</body>
</html>
