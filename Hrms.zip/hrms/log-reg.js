
function checking()
{
   
        if(document.getElementById('name').value=='')
        {
            alert('Please enter your name!');
            document.staff_register_form.name.focus();
            return false;
        }
if(document.getElementById('user_name').value=='')
        {
            alert('create username!');
            document.staff_register_form.user_name.focus();
            return false;
        }	
if(document.getElementById('password').value=='')
        {
            alert('create password!');
            document.staff_register_form.password.focus();
            return false;
        }	
        if(document.getElementById('user_description_name').value=='')
        {
            alert('Please enter your description !');
            document.staff_register_form.user_description_name.focus();
            return false;
        }
        if(document.getElementById('user_description_type').value=='')
        {
            alert('Please enter description type!');
            document.staff_register_form.user_description_type.focus();
            return false;
        }		
       
}
function loginchecking()
{
    
if(document.getElementById('username').value=='')
        {
            alert('please enter username!');
            document.loginform.username.focus();
            return false;
        }	
if(document.getElementById('password1').value=='')
        {
            alert('Please enter password!');
            document.loginform.password1.focus();
            return false;
        }	

}
/*function changepage(val){
window.location.href='student_activity.php?cid='+val;
}*/

const elem=document.getElementById('user_description_type').cloneNode(true);
            const ogg=elem.options;
            console.log(ogg);
            document.getElementById('user_description_type').innerHTML='<option value=""> Please Select a User Description</option>';
            function userdesc_chk(vall){
                document.getElementById('user_description_type').innerHTML='<option value=""> Please Select a User Type</option>';
            
                for(let j of ogg)
                {
                if(j.dataset)
                console.log(j.dataset.value)
                if(j.dataset.value===vall)
                document.getElementById('user_description_type').innerHTML+=`<option value="${j.value}"> ${j.dataset.subb}</option>`; 
                }
            }

function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}