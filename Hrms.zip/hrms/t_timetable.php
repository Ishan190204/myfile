<?php 
    include("conn.php");
    session_start();
    $tid=$_SESSION["user_id"];
    $name2=$_SESSION['name'];
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(empty($name2) || empty($tid))
    {
       @header("Location: index.php");
       exit();
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="time_table.css">
    <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Teacher Dashboard</title>
</head>
<body>
<div class="navbar">
<div class="dashboard">
        <div class="drops">
            <img src="images/side-lines.svg" height="30" width="25" onclick="show()">
        </div>
        <div class="dash">Teacher Dashboard</div>
</div>
    <div class="nav">
        <div class="subNavs"><a href="teacher_dashboard.php">Home</a></div>
        <div class="subNavs"><a href="t_change_pass.php">Change Password</a></div>
        <div class="subNavs"><a href="t_timetable.php">Time table</a></div>
        <!-- <div class="subNavs"><a href="t_task_list.php">Task List</a></div> -->
        <!-- <div class="subNavs"><a href="t_student_list.php">Student List</a></div> -->
        <!-- <div class="subNavs"><a href="t_attendence_table.php">Attendence Table</a></div> -->
        <!-- <div class="subNavs"><a href="attendence_list.php">Attendence List</a></div> -->
        <div class="dropdown" style="width: 14.8vw;padding-top:8px;">
            <button class="dropbtn" id="list">Attendence-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_attendence_table.php">Attendence Table</a>
                <a href="attendence_list.php">Attendence List</a>
            </div>
        </div>
        <div class="dropdown" style="width: 14vw;padding-top:8px;">
            <button class="dropbtn" id="list">List-Section<i class="fa fa-caret-down"></i></button>
            <div class="dropdown-content">
                <a href="t_task_list.php">Task List</a>
                <a href="t_student_list.php">Student List</a>
            </div>
        </div>
    </div>
    <div class="welcome">
        <div><h2>Welcome <?php echo $name2 ?></h2></div> 
        <button class="srch-btn"><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></button>
    </div>
        
</div>
 
<div id="dropLinks">
    <div class="closebtn">
        <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
    </div> 
    <div class="dropdown">
        <div class="dropbtn"><a href="teacher_dashboard.php">Home</a></div>
        <div class="dropbtn"><a href="t_change_pass.php">Change Password</a></div>
        <div class="dropbtn"><a href="t_task_list.php">Task List</a></div>
        <div class="dropbtn"><a href="t_student_list.php">Student List</a></div>
        <div class="dropbtn"><a href="t_attendence_table.php">Attendence Table</a></div>
        <div class="dropbtn"><a href="attendence_list.php">Attendence List</a></div>
        <div class="dropbtn"><a href="t_timetable.php">Time table</a></div>
    </div>

</div> 
   

<div class="container">
            <div style="height: 8px;"></div>
            <div class="tableDiv">
                <h2>Timetables</h2>
                <?php
                    $query = "SELECT * FROM `room_master`";
                    $resRooms = mysqli_query($conn, $query);
                    while($room = mysqli_fetch_array($resRooms))
                    {
                ?>
                        <div style="margin-top: 16px;">
                            <h3><?php echo $room['room_name']; ?></h3>
                            <table class="timetable" width="100%">
                                <thead>
                                    <tr>
                                        <th>Time Span</th>
                                        <?php
                                            $query = "SELECT * FROM `day_master`";
                                            $resDays = mysqli_query($conn, $query);
                                            $dayColumns = [];
                                            while($day = mysqli_fetch_array($resDays))
                                            {
                                                $dayName = $day['day_name'];
                                                $dayColumns[] = "MAX(CASE WHEN dm.day_name = '$dayName' THEN sm.slot_name ELSE \"\" END) AS `$dayName`";
                                        ?>
                                                <th><?php echo $day['day_name']; ?></th>
                                        <?php
                                            }
                                            $dayColumnsSQL = implode(", ", $dayColumns);
                                            $query = "SELECT
                                                          CONCAT(DATE_FORMAT(tm.`start_time`, '%h:%i %p'), ' - ', DATE_FORMAT(tm.`end_time`, '%h:%i %p')) AS time_span,
                                                        $dayColumnsSQL
                                                      FROM 
                                                          `slot_master` sm
                                                      JOIN 
                                                          `day_master` dm ON sm.`day_id` = dm.`day_id`
                                                      JOIN 
                                                          `time_master` tm ON sm.`time_id` = tm.`time_id`
                                                      WHERE
                                                          sm.`room_id` = '".$room['room_id']."'
                                                      GROUP BY 
                                                          time_span
                                                      ORDER BY 
                                                          tm.`start_time`";
                                            $res = mysqli_query($conn, $query);
                                        ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        while($row = mysqli_fetch_array($res))
                                        {
                                    ?>
                                            <tr>
                                                <td width="256px"><?php echo $row['time_span']; ?></td>
                                                <?php
                                                    mysqli_data_seek($resDays, 0);
                                                    while($day = mysqli_fetch_array($resDays))
                                                    {
                                                ?>
                                                        <td><?php echo $row[$day['day_name']]; ?></td>
                                                <?php
                                                    }
                                                ?>
                                            </tr>
                                    <?php
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                <?php
                    }
                ?>
            </div>
        </div>
        <script src="time_home.js"></script>
</body>
<script src="teacher_dashboard.js"></script> 
 </html>       