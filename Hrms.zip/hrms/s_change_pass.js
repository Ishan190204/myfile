function passchecking()
{
    
if(document.getElementById('change_pass').value=='')
        {
            alert('Please Enter Password!');
            return false;
        }	


}
function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}

function userdescname_chk(vall) {
    let val=vall.substring(0, 2);
    let val1=val[0].toUpperCase() + val.slice(1)
    document.getElementById("demo").innerHTML =val1;
}