window.onscroll = function() {scrollFunction()};
  function scrollFunction() {
    if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
      document.getElementById("ImgTop").style.opacity = "75%";
    } else {
      document.getElementById("ImgTop").style.opacity = "100%";;
      // document.getElementById("homeLink").style.backgroundColor = "#f7f7f800"
    }
  }
function show()
{
    console.log("!!!");
    document.getElementById('dropLinks').style.visibility="visible";
}
function hide()
{
    document.getElementById('dropLinks').style.visibility="hidden"; 
}