<?php 
    include("conn.php");
    session_start();
    if(mysqli_connect_errno()){
        echo "failed to connect to mysql" . mysqli_connect_error();
    }
    if(!empty($_REQUEST['msg']))
        {  
          $mspg = $_REQUEST['msg'];  
        } 
    else
        {   
          $mspg  = ""; 
        } 

    $fetch_userdescadm ="SELECT `user_name`,`password`,`name`,`user_id` from `staff_registration_master` where `user_type`='Ad' order by `user_id`"  ;
    $user_desc_adm=mysqli_query($conn,$fetch_userdescadm);

    if(!empty($_REQUEST['mode']))
    {  
        $res_username = $_REQUEST['user_name'];
        $res_Password = $_REQUEST['password'];
        $res_userid = $_REQUEST['user_id'];
        $flag='0';
        while($arr=mysqli_fetch_array($user_desc_adm)){
            if($res_username===$arr['user_name'] and $res_Password===$arr['password']){
                $flag='1';
                $res_username=$arr['name'];
                $res_id=$arr['user_id'];
        } 
      }
      if($flag==='1'){
        $_SESSION["usname"] = $res_username;
        $_SESSION["usid"]=$res_id;
        @header("Location:admin_dashboard.php?msg= login Successfull");
        exit();  
      }
      else{
        @header("Location:adminLogin.php?msg=Please enter valid username or password !");
        exit(); 
      }
      
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" href="adminLogin.css">
        <link rel = "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
    <div class="mainDiv">
        <div class="navbar">
            <div class="dashboard">
                <div class="dashlogo"><img src="images/NEW_LOGO__1___1_.png" class="logo"></div>
                <div class="dash">Shikhshaneer</div>
            </div>
            <div class="nav">
                <div class="subNavs"><a href="index.php">Home</a></div>
                <div class="subNavs"><a href="log-reg.php">Login/ Register</a></div>
                <div class="subNavs"><a href="student-log-reg.php">Student Login/Register</a></div>
            </div>   
    </div>

    <div class="drops">
            <img src="images/side-lines.svg" height="30" width="28" onclick="show()">
    </div> 
    <div id="dropLinks">
        <div class="closebtn">
            <button onclick="hide()" class="hide-btn"><i class="fa-solid fa-circle-xmark fa-2xl"></i></button>
        </div> 
        <div class="dropdown">
            <div class="dropbtn"><a href="index.php">Home</a></div>
            <div class="dropbtn"><a href="log-reg.php">Login/ Register</a></div>
            <div class="dropbtn"><a href="student-log-reg.php">Student Login/Register</a></div>
        </div>
    </div> 
        <div style="height:70px;"></div>
        <div class="maindiv">
            <form class="formDiv"  action="" name="admloginform" id="admloginform" method="post" onSubmit="return checking();">
                <input type="hidden" name="mode" value="1" />
                <h1 align="center">Admin-Login</h1>
                
                <input type="text" class="type" placeholder="Username" name="user_name" id="user_name"><span class="input-border"></span><br/>
                <input type="password" class="type" placeholder="Password" name="password" id="password" ><br/>
                <input type="submit" value="login" class="submit-btn">
                <h4 style="color:red;"><?php echo $mspg ?></h4>
            </form>
        </div>
        <script>
            function show()
            {
                console.log("!!!");
                document.getElementById('dropLinks').style.visibility="visible";
            }
            function hide()
            {
                document.getElementById('dropLinks').style.visibility="hidden"; 
            }
        </script>
    </body>
</html>